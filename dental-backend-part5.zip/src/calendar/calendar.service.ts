export function generateSlots(){
 const slots=[];const start=9;const end=21;
 for(let h=start;h<end;h++){
   slots.push(`${h}:00`,`${h}:30`);
 }
 return slots;
}