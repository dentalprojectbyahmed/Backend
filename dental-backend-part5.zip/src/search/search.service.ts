export function globalSearch(query,db){
 const q=query.toLowerCase();
 return {
   patients:db.patients.filter(p=>p.name.toLowerCase().includes(q)||p.phone.includes(q)),
   treatments:db.treatments.filter(t=>t.name.toLowerCase().includes(q)||t.code.toLowerCase().includes(q)),
   invoices:db.invoices.filter(i=>i.number.includes(q))
 };
}