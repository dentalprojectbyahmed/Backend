# Next.js Starter
Basic scaffolding for Dental Frontend.