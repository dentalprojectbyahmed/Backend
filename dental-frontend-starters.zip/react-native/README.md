# React Native Starter
Minimal mobile scaffolding.