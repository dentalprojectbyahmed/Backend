CREATE DATABASE IF NOT EXISTS dental_mvp;
USE dental_mvp;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role ENUM('admin', 'dentist', 'receptionist') NOT NULL,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(100),
  date_of_birth DATE,
  gender ENUM('male', 'female', 'other'),
  address TEXT,
  medical_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  dentist_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  status ENUM('scheduled', 'completed', 'cancelled') DEFAULT 'scheduled',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (dentist_id) REFERENCES users(id)
);

CREATE TABLE availability (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dentist_id INT NOT NULL,
  available_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (dentist_id) REFERENCES users(id)
);

CREATE TABLE treatments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  dentist_id INT NOT NULL,
  treatment_date DATE NOT NULL,
  diagnosis TEXT NOT NULL,
  procedure_done TEXT NOT NULL,
  notes TEXT,
  cost DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id),
  FOREIGN KEY (dentist_id) REFERENCES users(id)
);

CREATE TABLE billing (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_status ENUM('pending', 'paid', 'partial') DEFAULT 'pending',
  payment_method ENUM('cash', 'card', 'bank_transfer') DEFAULT 'cash',
  paid_amount DECIMAL(10,2) DEFAULT 0,
  billing_date DATE NOT NULL,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id)
);

CREATE TABLE inventory (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(100) NOT NULL,
  quantity INT DEFAULT 0,
  unit VARCHAR(20),
  reorder_level INT DEFAULT 10,
  notes TEXT
);

INSERT INTO users (username, password, full_name, role) VALUES 
('admin', '$2a$10$YtK0QAzKP.XGGqvFZfZ8/.GKzQJXKj8i5J3yVpYE6OyYJf5xW3z8K', 'Administrator', 'admin'),
('dr_ahmed', '$2a$10$YtK0QAzKP.XGGqvFZfZ8/.GKzQJXKj8i5J3yVpYE6OyYJf5xW3z8K', 'Dr. Ahmed Abdullah Khan', 'dentist'),
('receptionist', '$2a$10$YtK0QAzKP.XGGqvFZfZ8/.GKzQJXKj8i5J3yVpYE6OyYJf5xW3z8K', 'Naveed', 'receptionist');
