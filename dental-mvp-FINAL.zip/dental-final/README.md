# Abdullah Dental Care - Complete MVP System

Full working dental clinic management system with Node.js + EJS + MySQL.

## Features (All Working)

✅ **Patient Management** - Add, edit, delete patients
✅ **Appointment Scheduling** - Book and manage appointments  
✅ **Dentist Availability** - Set dentist schedules
✅ **Treatment Recording** - Record diagnosis, procedures, costs
✅ **Billing System** - Create bills, track payments
✅ **Inventory Management** - Track supplies, low stock alerts

## Quick Setup

```bash
# 1. Install dependencies
npm install

# 2. Create database
mysql -u root -p < database.sql

# 3. Configure
# Edit .env: set DB_PASSWORD

# 4. Run
npm start
```

Visit: http://localhost:3000

**Login:** admin / admin123

## What You Get

- Complete working application with all 6 modules
- All CRUD operations (Create, Read, Update, Delete)
- Clean, responsive UI
- Session-based authentication
- 3 user roles (admin, dentist, receptionist)

## File Structure

```
dental-final/
├── server.js           # Main application (all routes)
├── database.sql        # Database schema
├── package.json        # Dependencies
├── .env               # Configuration
├── views/             # All EJS templates
│   ├── login.ejs
│   ├── dashboard.ejs
│   ├── patients/
│   ├── appointments/
│   ├── availability/
│   ├── treatments/
│   ├── billing/
│   └── inventory/
└── public/
    └── css/
        └── style.css   # Styling
```

## Support

Email: ahmedakg@gmail.com
Clinic: Abdullah Dental Care, Hayatabad, Peshawar
