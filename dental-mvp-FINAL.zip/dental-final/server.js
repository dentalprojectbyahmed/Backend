const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();

// Database connection
const db = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

// Middleware
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

// Auth middleware
const requireAuth = (req, res, next) => {
  if (!req.session.user) return res.redirect('/login');
  next();
};

app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// Routes
app.get('/', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [users] = await db.query('SELECT * FROM users WHERE username = ? AND active = 1', [username]);
    if (users.length === 0) {
      return res.render('login', { error: 'Invalid credentials' });
    }
    const user = users[0];
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.render('login', { error: 'Invalid credentials' });
    }
    req.session.user = { id: user.id, username: user.username, full_name: user.full_name, role: user.role };
    res.redirect('/dashboard');
  } catch (error) {
    console.error(error);
    res.render('login', { error: 'Login failed' });
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

app.get('/dashboard', requireAuth, async (req, res) => {
  try {
    const [patients] = await db.query('SELECT COUNT(*) as count FROM patients');
    const [appointments] = await db.query('SELECT COUNT(*) as count FROM appointments WHERE appointment_date = CURDATE()');
    const [billing] = await db.query('SELECT SUM(amount) as total FROM billing WHERE billing_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)');
    const [inventory] = await db.query('SELECT COUNT(*) as count FROM inventory WHERE quantity <= reorder_level');
    
    res.render('dashboard', {
      stats: {
        patients: patients[0].count,
        todayAppointments: appointments[0].count,
        monthlyRevenue: billing[0].total || 0,
        lowStock: inventory[0].count
      }
    });
  } catch (error) {
    console.error(error);
    res.render('dashboard', { stats: {} });
  }
});

// PATIENTS
app.get('/patients', requireAuth, async (req, res) => {
  const [patients] = await db.query('SELECT * FROM patients ORDER BY created_at DESC');
  res.render('patients/list', { patients });
});

app.get('/patients/add', requireAuth, (req, res) => {
  res.render('patients/form', { patient: null, error: null });
});

app.post('/patients/add', requireAuth, async (req, res) => {
  const { name, phone, email, date_of_birth, gender, address, medical_notes } = req.body;
  try {
    await db.query('INSERT INTO patients (name, phone, email, date_of_birth, gender, address, medical_notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, phone, email || null, date_of_birth || null, gender, address || null, medical_notes || null]);
    res.redirect('/patients');
  } catch (error) {
    res.render('patients/form', { patient: req.body, error: 'Failed to add patient' });
  }
});

app.get('/patients/edit/:id', requireAuth, async (req, res) => {
  const [patients] = await db.query('SELECT * FROM patients WHERE id = ?', [req.params.id]);
  if (patients.length === 0) return res.redirect('/patients');
  res.render('patients/form', { patient: patients[0], error: null });
});

app.post('/patients/edit/:id', requireAuth, async (req, res) => {
  const { name, phone, email, date_of_birth, gender, address, medical_notes } = req.body;
  await db.query('UPDATE patients SET name=?, phone=?, email=?, date_of_birth=?, gender=?, address=?, medical_notes=? WHERE id=?',
    [name, phone, email || null, date_of_birth || null, gender, address || null, medical_notes || null, req.params.id]);
  res.redirect('/patients');
});

app.post('/patients/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM patients WHERE id = ?', [req.params.id]);
  res.redirect('/patients');
});

// APPOINTMENTS
app.get('/appointments', requireAuth, async (req, res) => {
  const [appointments] = await db.query(`
    SELECT a.*, p.name as patient_name, u.full_name as dentist_name 
    FROM appointments a 
    JOIN patients p ON a.patient_id = p.id 
    JOIN users u ON a.dentist_id = u.id 
    ORDER BY a.appointment_date DESC, a.appointment_time DESC
  `);
  res.render('appointments/list', { appointments });
});

app.get('/appointments/add', requireAuth, async (req, res) => {
  const [patients] = await db.query('SELECT id, name FROM patients ORDER BY name');
  const [dentists] = await db.query("SELECT id, full_name FROM users WHERE role='dentist' AND active=1");
  res.render('appointments/form', { appointment: null, patients, dentists, error: null });
});

app.post('/appointments/add', requireAuth, async (req, res) => {
  const { patient_id, dentist_id, appointment_date, appointment_time, notes } = req.body;
  await db.query('INSERT INTO appointments (patient_id, dentist_id, appointment_date, appointment_time, notes) VALUES (?, ?, ?, ?, ?)',
    [patient_id, dentist_id, appointment_date, appointment_time, notes || null]);
  res.redirect('/appointments');
});

app.get('/appointments/edit/:id', requireAuth, async (req, res) => {
  const [appointments] = await db.query('SELECT * FROM appointments WHERE id = ?', [req.params.id]);
  const [patients] = await db.query('SELECT id, name FROM patients');
  const [dentists] = await db.query("SELECT id, full_name FROM users WHERE role='dentist'");
  res.render('appointments/form', { appointment: appointments[0], patients, dentists, error: null });
});

app.post('/appointments/edit/:id', requireAuth, async (req, res) => {
  const { patient_id, dentist_id, appointment_date, appointment_time, status, notes } = req.body;
  await db.query('UPDATE appointments SET patient_id=?, dentist_id=?, appointment_date=?, appointment_time=?, status=?, notes=? WHERE id=?',
    [patient_id, dentist_id, appointment_date, appointment_time, status, notes || null, req.params.id]);
  res.redirect('/appointments');
});

app.post('/appointments/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM appointments WHERE id = ?', [req.params.id]);
  res.redirect('/appointments');
});

// AVAILABILITY
app.get('/availability', requireAuth, async (req, res) => {
  const [availability] = await db.query(`
    SELECT a.*, u.full_name as dentist_name 
    FROM availability a 
    JOIN users u ON a.dentist_id = u.id 
    ORDER BY a.available_date DESC
  `);
  res.render('availability/list', { availability });
});

app.get('/availability/add', requireAuth, async (req, res) => {
  const [dentists] = await db.query("SELECT id, full_name FROM users WHERE role='dentist' AND active=1");
  res.render('availability/form', { dentists });
});

app.post('/availability/add', requireAuth, async (req, res) => {
  const { dentist_id, available_date, start_time, end_time } = req.body;
  await db.query('INSERT INTO availability (dentist_id, available_date, start_time, end_time) VALUES (?, ?, ?, ?)',
    [dentist_id, available_date, start_time, end_time]);
  res.redirect('/availability');
});

app.post('/availability/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM availability WHERE id = ?', [req.params.id]);
  res.redirect('/availability');
});

// TREATMENTS
app.get('/treatments', requireAuth, async (req, res) => {
  const [treatments] = await db.query(`
    SELECT t.*, p.name as patient_name, u.full_name as dentist_name 
    FROM treatments t 
    JOIN patients p ON t.patient_id = p.id 
    JOIN users u ON t.dentist_id = u.id 
    ORDER BY t.treatment_date DESC
  `);
  res.render('treatments/list', { treatments });
});

app.get('/treatments/add', requireAuth, async (req, res) => {
  const [patients] = await db.query('SELECT id, name FROM patients');
  const [dentists] = await db.query("SELECT id, full_name FROM users WHERE role='dentist'");
  res.render('treatments/form', { patients, dentists });
});

app.post('/treatments/add', requireAuth, async (req, res) => {
  const { patient_id, dentist_id, treatment_date, diagnosis, procedure_done, notes, cost } = req.body;
  await db.query('INSERT INTO treatments (patient_id, dentist_id, treatment_date, diagnosis, procedure_done, notes, cost) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [patient_id, dentist_id, treatment_date, diagnosis, procedure_done, notes || null, cost || 0]);
  res.redirect('/treatments');
});

app.post('/treatments/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM treatments WHERE id = ?', [req.params.id]);
  res.redirect('/treatments');
});

// BILLING
app.get('/billing', requireAuth, async (req, res) => {
  const [billing] = await db.query(`
    SELECT b.*, p.name as patient_name 
    FROM billing b 
    JOIN patients p ON b.patient_id = p.id 
    ORDER BY b.billing_date DESC
  `);
  res.render('billing/list', { billing });
});

app.get('/billing/add', requireAuth, async (req, res) => {
  const [patients] = await db.query('SELECT id, name FROM patients');
  res.render('billing/form', { patients });
});

app.post('/billing/add', requireAuth, async (req, res) => {
  const { patient_id, amount, payment_status, payment_method, paid_amount, billing_date, notes } = req.body;
  await db.query('INSERT INTO billing (patient_id, amount, payment_status, payment_method, paid_amount, billing_date, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [patient_id, amount, payment_status, payment_method, paid_amount || 0, billing_date, notes || null]);
  res.redirect('/billing');
});

app.post('/billing/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM billing WHERE id = ?', [req.params.id]);
  res.redirect('/billing');
});

// INVENTORY
app.get('/inventory', requireAuth, async (req, res) => {
  const [inventory] = await db.query('SELECT * FROM inventory ORDER BY item_name');
  res.render('inventory/list', { inventory });
});

app.get('/inventory/add', requireAuth, (req, res) => {
  res.render('inventory/form', { item: null });
});

app.post('/inventory/add', requireAuth, async (req, res) => {
  const { item_name, quantity, unit, reorder_level, notes } = req.body;
  await db.query('INSERT INTO inventory (item_name, quantity, unit, reorder_level, notes) VALUES (?, ?, ?, ?, ?)',
    [item_name, quantity || 0, unit || null, reorder_level || 10, notes || null]);
  res.redirect('/inventory');
});

app.get('/inventory/edit/:id', requireAuth, async (req, res) => {
  const [items] = await db.query('SELECT * FROM inventory WHERE id = ?', [req.params.id]);
  res.render('inventory/form', { item: items[0] });
});

app.post('/inventory/edit/:id', requireAuth, async (req, res) => {
  const { item_name, quantity, unit, reorder_level, notes } = req.body;
  await db.query('UPDATE inventory SET item_name=?, quantity=?, unit=?, reorder_level=?, notes=? WHERE id=?',
    [item_name, quantity, unit, reorder_level, notes || null, req.params.id]);
  res.redirect('/inventory');
});

app.post('/inventory/delete/:id', requireAuth, async (req, res) => {
  await db.query('DELETE FROM inventory WHERE id = ?', [req.params.id]);
  res.redirect('/inventory');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🦷 Abdullah Dental Care MVP running on http://localhost:${PORT}`);
  console.log(`Login: admin / admin123`);
});
