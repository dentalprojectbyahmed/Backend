import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

const TREATMENTS = [
  {
    "id": 1,
    "name": "Consultation",
    "usd": 7,
    "pkr": 2000,
    "category": "Consultation"
  },
  {
    "id": 2,
    "name": "Periapical X-Ray",
    "usd": 4,
    "pkr": 1000,
    "category": "Diagnostics"
  },
  {
    "id": 3,
    "name": "Post-Op Follow-up",
    "usd": 4,
    "pkr": 1000,
    "category": "Consultation"
  },
  {
    "id": 4,
    "name": "Pits & Fissure Sealants",
    "usd": 18,
    "pkr": 5000,
    "category": "Preventive",
    "perTooth": true
  },
  {
    "id": 5,
    "name": "Fluoride Application (Children)",
    "usd": 7,
    "pkr": 2000,
    "category": "Preventive"
  },
  {
    "id": 6,
    "name": "Night Guard Single Arch",
    "usd": 35,
    "pkr": 10000,
    "category": "Preventive"
  },
  {
    "id": 7,
    "name": "Athletic Mouthguards",
    "usd": 30,
    "pkr": 8500,
    "category": "Preventive"
  },
  {
    "id": 8,
    "name": "Temporary Filling",
    "usd": 15,
    "pkr": 4000,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 9,
    "name": "Glass Ionomer Fluoride",
    "usd": 18,
    "pkr": 5000,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 10,
    "name": "Light Cure Composite (A) Class I & V",
    "usd": 30,
    "pkr": 8500,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 11,
    "name": "'Light Cure Composite (B) Class II",
    "usd": 30,
    "pkr": 8500,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 12,
    "name": "Amalgam/Cermet Silver",
    "usd": 18,
    "pkr": 5000,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 13,
    "name": "Inlays/Onlays Composite",
    "usd": 45,
    "pkr": 12500,
    "category": "Fillings",
    "perTooth": true
  },
  {
    "id": 14,
    "name": "Fibre Post & Core Buildup",
    "usd": 35,
    "pkr": 10000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 15,
    "name": "Metal Post & Core",
    "usd": 30,
    "pkr": 8500,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 16,
    "name": "RCT Single Root",
    "usd": 55,
    "pkr": 15000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 17,
    "name": "RCT 2 Root",
    "usd": 65,
    "pkr": 18000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 18,
    "name": "RCT 3 Root",
    "usd": 75,
    "pkr": 21000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 19,
    "name": "RCT 4 Root",
    "usd": 90,
    "pkr": 25000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 20,
    "name": "Re-RCT Single Root",
    "usd": 65,
    "pkr": 18000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 21,
    "name": "Re-RCT Multi Root",
    "usd": 90,
    "pkr": 25000,
    "category": "Endodontics",
    "perTooth": true
  },
  {
    "id": 22,
    "name": "Pulpotomy Primary Teeth",
    "usd": 20,
    "pkr": 5500,
    "category": "Pediatric",
    "perTooth": true
  },
  {
    "id": 23,
    "name": "Pulpectomy Primary Teeth",
    "usd": 30,
    "pkr": 8500,
    "category": "Pediatric",
    "perTooth": true
  },
  {
    "id": 24,
    "name": "Metal Crown",
    "usd": 90,
    "pkr": 25000,
    "category": "Prosthodontics",
    "perTooth": true
  },
  {
    "id": 25,
    "name": "Porcelain Fused to Metal (PFM) Crown",
    "usd": 110,
    "pkr": 30000,
    "category": "Prosthodontics",
    "perTooth": true
  },
  {
    "id": 26,
    "name": "Zirconia Crown",
    "usd": 180,
    "pkr": 50000,
    "category": "Prosthodontics",
    "perTooth": true
  },
  {
    "id": 27,
    "name": "E-max Crown",
    "usd": 215,
    "pkr": 60000,
    "category": "Prosthodontics",
    "perTooth": true
  },
  {
    "id": 28,
    "name": "Veneers Composite",
    "usd": 90,
    "pkr": 25000,
    "category": "Cosmetic",
    "perTooth": true
  },
  {
    "id": 29,
    "name": "Veneers Porcelain",
    "usd": 180,
    "pkr": 50000,
    "category": "Cosmetic",
    "perTooth": true
  },
  {
    "id": 30,
    "name": "Maryland Bridge",
    "usd": 180,
    "pkr": 50000,
    "category": "Prosthodontics"
  },
  {
    "id": 31,
    "name": "PFM Bridge (3 Units)",
    "usd": 270,
    "pkr": 75000,
    "category": "Prosthodontics"
  },
  {
    "id": 32,
    "name": "Zirconia Bridge (3 Units)",
    "usd": 430,
    "pkr": 120000,
    "category": "Prosthodontics"
  },
  {
    "id": 33,
    "name": "Complete Denture (Single Arch)",
    "usd": 180,
    "pkr": 50000,
    "category": "Prosthodontics"
  },
  {
    "id": 34,
    "name": "Complete Denture (Both Arches)",
    "usd": 320,
    "pkr": 90000,
    "category": "Prosthodontics"
  },
  {
    "id": 35,
    "name": "Flexible Denture (Valplast)",
    "usd": 215,
    "pkr": 60000,
    "category": "Prosthodontics"
  },
  {
    "id": 36,
    "name": "Cast Partial Denture",
    "usd": 180,
    "pkr": 50000,
    "category": "Prosthodontics"
  },
  {
    "id": 37,
    "name": "Acrylic Partial Denture",
    "usd": 90,
    "pkr": 25000,
    "category": "Prosthodontics"
  },
  {
    "id": 38,
    "name": "Immediate Denture",
    "usd": 215,
    "pkr": 60000,
    "category": "Prosthodontics"
  },
  {
    "id": 39,
    "name": "Overdenture",
    "usd": 250,
    "pkr": 70000,
    "category": "Prosthodontics"
  },
  {
    "id": 40,
    "name": "Simple Extraction",
    "usd": 18,
    "pkr": 5000,
    "category": "Surgery",
    "perTooth": true
  },
  {
    "id": 41,
    "name": "Surgical Extraction",
    "usd": 35,
    "pkr": 10000,
    "category": "Surgery",
    "perTooth": true
  },
  {
    "id": 42,
    "name": "Impacted Wisdom Tooth (Simple)",
    "usd": 55,
    "pkr": 15000,
    "category": "Surgery",
    "perTooth": true
  },
  {
    "id": 43,
    "name": "Impacted Wisdom Tooth (Complicated)",
    "usd": 90,
    "pkr": 25000,
    "category": "Surgery",
    "perTooth": true
  },
  {
    "id": 44,
    "name": "Primary Tooth Extraction",
    "usd": 11,
    "pkr": 3000,
    "category": "Pediatric",
    "perTooth": true
  },
  {
    "id": 45,
    "name": "Scaling & Polishing",
    "usd": 25,
    "pkr": 7000,
    "category": "Periodontics"
  },
  {
    "id": 46,
    "name": "Deep Scaling (Per Quadrant)",
    "usd": 35,
    "pkr": 10000,
    "category": "Periodontics"
  },
  {
    "id": 47,
    "name": "Root Planning (Per Quadrant)",
    "usd": 35,
    "pkr": 10000,
    "category": "Periodontics"
  },
  {
    "id": 48,
    "name": "Gingivectomy (Per Quadrant)",
    "usd": 55,
    "pkr": 15000,
    "category": "Periodontics"
  },
  {
    "id": 49,
    "name": "Gum Graft",
    "usd": 180,
    "pkr": 50000,
    "category": "Periodontics"
  },
  {
    "id": 50,
    "name": "Crown Lengthening",
    "usd": 90,
    "pkr": 25000,
    "category": "Periodontics",
    "perTooth": true
  },
  {
    "id": 51,
    "name": "Dental Implant (Fixture Only)",
    "usd": 360,
    "pkr": 100000,
    "category": "Implants",
    "perTooth": true
  },
  {
    "id": 52,
    "name": "Implant with Crown (PFM)",
    "usd": 540,
    "pkr": 150000,
    "category": "Implants",
    "perTooth": true
  },
  {
    "id": 53,
    "name": "Implant with Crown (Zirconia)",
    "usd": 720,
    "pkr": 200000,
    "category": "Implants",
    "perTooth": true
  },
  {
    "id": 54,
    "name": "Bone Grafting",
    "usd": 180,
    "pkr": 50000,
    "category": "Implants"
  },
  {
    "id": 55,
    "name": "Sinus Lift",
    "usd": 270,
    "pkr": 75000,
    "category": "Implants"
  },
  {
    "id": 56,
    "name": "Guided Tissue Regeneration (GTR)",
    "usd": 90,
    "pkr": 25000,
    "category": "Implants"
  },
  {
    "id": 57,
    "name": "Fixed Braces (Simple Case)",
    "usd": 540,
    "pkr": 150000,
    "category": "Orthodontics"
  },
  {
    "id": 58,
    "name": "Fixed Braces (Complicated Case)",
    "usd": 900,
    "pkr": 250000,
    "category": "Orthodontics"
  },
  {
    "id": 59,
    "name": "Fixed Braces (Ceramic Brackets)",
    "usd": 1080,
    "pkr": 300000,
    "category": "Orthodontics"
  },
  {
    "id": 60,
    "name": "Removable Braces Clearpath",
    "usd": 1200,
    "pkr": 335000,
    "category": "Orthodontics"
  },
  {
    "id": 61,
    "name": "Retainers (Removable) Upper & Lower",
    "usd": 55,
    "pkr": 15000,
    "category": "Orthodontics"
  },
  {
    "id": 62,
    "name": "Retainers (Fixed) Upper & Lower",
    "usd": 72,
    "pkr": 20000,
    "category": "Orthodontics"
  },
  {
    "id": 63,
    "name": "Laser Teeth Whitening (Half Strength)",
    "usd": 90,
    "pkr": 25000,
    "category": "Cosmetic"
  },
  {
    "id": 64,
    "name": "Laser Teeth Whitening (Full Strength)",
    "usd": 108,
    "pkr": 30000,
    "category": "Cosmetic"
  },
  {
    "id": 65,
    "name": "Soft Tissue Laser/Cautry per Quadrant",
    "usd": 36,
    "pkr": 10000,
    "category": "Cosmetic"
  },
  {
    "id": 66,
    "name": "Emergency Consultation",
    "usd": 18,
    "pkr": 5000,
    "category": "Emergency"
  },
  {
    "id": 67,
    "name": "Desensitizing Treatment",
    "usd": 25,
    "pkr": 7000,
    "category": "Preventive"
  },
  {
    "id": 68,
    "name": "Space Maintainer",
    "usd": 55,
    "pkr": 15000,
    "category": "Pediatric"
  },
  {
    "id": 69,
    "name": "Splinting (Per Tooth)",
    "usd": 35,
    "pkr": 10000,
    "category": "Periodontics",
    "perTooth": true
  },
  {
    "id": 70,
    "name": "Custom Service",
    "usd": 0,
    "pkr": 0,
    "category": "Other"
  }
];

async function main() {
  for (const t of TREATMENTS) {
    await prisma.treatmentCatalog.upsert({
      where: { id: t.id },
      update: { name: t.name, usd: t.usd, pkr: t.pkr, unit: (t.perTooth ? 'tooth' : 'other'), surfaces: false },
      create: { id: t.id, name: t.name, usd: t.usd, pkr: t.pkr, unit: (t.perTooth ? 'tooth' : 'other'), surfaces: false }
    });
  }

  const conditions = [
    { name: 'Post-extraction pain', category: 'Pain', notes: '' },
    { name: 'Acute pulpitis', category: 'Endodontic', notes: '' }
  ];
  for (const c of conditions) {
    await prisma.condition.upsert({
      where: { name: c.name },
      update: {},
      create: c
    });
  }

  const pe = await prisma.condition.findUnique({ where: { name: 'Post-extraction pain' } });
  const ap = await prisma.condition.findUnique({ where: { name: 'Acute pulpitis' } });
  if (pe && ap) {
    await prisma.prescriptionTemplate.createMany({
      data: [
        { conditionId: pe.id, level: 'basic', medications: [{ drug: 'Ibuprofen 400mg', dose: '1 tab', frequency: '8 hourly', duration: '3 days' }], defaultInstructions: 'Take after food.' },
        { conditionId: ap.id, level: 'basic', medications: [{ drug: 'Amoxicillin 500mg', dose: '1 cap', frequency: '8 hourly', duration: '5 days' }], defaultInstructions: 'Complete antibiotic course.' }
      ]
    });
  }

  await prisma.consentTemplate.createMany({
    data: [
      { name: 'General Treatment Consent', bodyText: 'I consent to dental examination and treatment as explained.' },
      { name: 'Extraction Consent', bodyText: 'I consent to extraction of specified tooth/teeth and understand risks and alternatives.' }
    ],
    skipDuplicates: true
  });
}

main().catch(e => {
  console.error(e);
  process.exit(1);
}).finally(async () => {
  await prisma.$disconnect();
});
