import { prisma } from './prisma';

export async function audit(userId: number | undefined, action: string, entity: string, entityId?: number, details?: any) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: userId || null,
        action,
        entity,
        entityId: entityId || null,
        details: details || null
      }
    });
  } catch (err) {
    console.error('Audit log failed', err);
  }
}
