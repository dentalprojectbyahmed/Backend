import PDFDocument from 'pdfkit';
import { prisma } from './prisma';

export async function buildInvoicePdf(treatmentId: number): Promise<Buffer> {
  const treatment = await prisma.treatment.findUnique({
    where: { id: treatmentId },
    include: { patient: true }
  });
  if (!treatment || !treatment.patient) {
    throw new Error('Treatment not found');
  }

  const consents = await prisma.consentRecord.findMany({
    where: { treatmentId },
    include: { template: true }
  });

  const doc = new PDFDocument({ margin: 40 });
  const chunks: Buffer[] = [];

  return await new Promise<Buffer>((resolve, reject) => {
    doc.on('data', (chunk) => chunks.push(chunk as Buffer));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', (err) => reject(err));

    doc.fontSize(18).text('Dental Clinic Invoice', { align: 'center' });
    doc.moveDown();

    const p = treatment.patient;
    doc.fontSize(12).text(`Invoice ID: ${treatment.id}`);
    doc.text(`Date: ${treatment.date.toISOString().slice(0, 10)}`);
    doc.moveDown();
    doc.text(`Patient: ${p.name}`);
    doc.text(`Phone: ${p.phone}`);
    doc.moveDown();

    doc.fontSize(14).text('Items').moveDown(0.5);
    const items = (treatment.items as any[]) || [];
    items.forEach((item) => {
      const tooth = item.tooth ? ` (Tooth ${item.tooth})` : '';
      const visits = item.visitsTotal ? ` [Visit ${item.visitIndex || 1}/${item.visitsTotal}]` : '';
      const line = `- ${item.name}${tooth}${visits}: ${item.qty || 1} x ${item.unitPkr || 0} = ${item.totalPkr || 0}`;
      doc.fontSize(12).text(line);
    });

    doc.moveDown();
    doc.fontSize(12).text(`Total: ${treatment.totalPkr}`);
    doc.text(`Discount: ${treatment.discountPkr}`);
    doc.text(`Paid: ${treatment.paidPkr}`);
    doc.text(`Balance: ${treatment.balancePkr}`);

    if (consents.length) {
      doc.addPage();
      doc.fontSize(16).text('Treatment Consents', { align: 'center' });
      doc.moveDown();
      consents.forEach((c) => {
        doc.fontSize(12).text(c.template.name, { underline: true });
        doc.moveDown(0.3);
        doc.fontSize(10).text(c.template.bodyText);
        doc.moveDown();
      });
    }

    doc.end();
  });
}
