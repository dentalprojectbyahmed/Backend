import { google } from 'googleapis';
import { prisma } from './prisma';

const SCOPES = ['https://www.googleapis.com/auth/drive.file'];

function getOAuthClient() {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const redirectUri = process.env.GOOGLE_REDIRECT_URI;

  if (!clientId || !clientSecret || !redirectUri) {
    throw new Error('Google OAuth env vars not configured');
  }

  return new google.auth.OAuth2(clientId, clientSecret, redirectUri);
}

export function generateDriveAuthUrl() {
  const client = getOAuthClient();
  return client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
    prompt: 'consent'
  });
}

export async function saveDriveTokens(code: string) {
  const client = getOAuthClient();
  const { tokens } = await client.getToken(code);

  await prisma.setting.upsert({
    where: { key: 'google_drive_tokens' },
    update: { value: tokens },
    create: { key: 'google_drive_tokens', value: tokens }
  });

  return tokens;
}

export async function getDriveClient() {
  const client = getOAuthClient();
  const setting = await prisma.setting.findUnique({
    where: { key: 'google_drive_tokens' }
  });
  if (!setting) throw new Error('Drive not connected');
  client.setCredentials(setting.value as any);
  return google.drive({ version: 'v3', auth: client });
}

export async function uploadJsonToDrive(name: string, data: any) {
  const drive = await getDriveClient();
  const fileMetadata = { name };
  const media = {
    mimeType: 'application/json',
    body: Buffer.from(JSON.stringify(data, null, 2), 'utf-8')
  } as any;
  const res = await drive.files.create({
    requestBody: fileMetadata,
    media,
    fields: 'id, name, webViewLink'
  });
  return res.data;
}
