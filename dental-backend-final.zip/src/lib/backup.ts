import { prisma } from './prisma';
import { uploadJsonToDrive } from './googleDrive';

export async function exportFullBackup() {
  const [
    patients,
    appointments,
    treatments,
    prescriptions,
    treatmentCatalog,
    users,
    settings,
    consents,
    consentTemplates,
    conditions,
    prescriptionTemplates,
    expenses
  ] = await Promise.all([
    prisma.patient.findMany(),
    prisma.appointment.findMany(),
    prisma.treatment.findMany(),
    prisma.prescription.findMany(),
    prisma.treatmentCatalog.findMany(),
    prisma.user.findMany(),
    prisma.setting.findMany(),
    prisma.consentRecord.findMany(),
    prisma.consentTemplate.findMany(),
    prisma.condition.findMany(),
    prisma.prescriptionTemplate.findMany(),
    prisma.expense.findMany()
  ]);

  return {
    generatedAt: new Date().toISOString(),
    patients,
    appointments,
    treatments,
    prescriptions,
    treatmentCatalog,
    users,
    settings,
    consents,
    consentTemplates,
    conditions,
    prescriptionTemplates,
    expenses
  };
}

export async function uploadBackupToDrive() {
  const data = await exportFullBackup();
  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `dental-backup-${ts}.json`;
  return uploadJsonToDrive(filename, data);
}
