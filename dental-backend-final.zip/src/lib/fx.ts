import fetch from 'node-fetch';
import { prisma } from './prisma';

export async function updateDailyFxRate() {
  const url = process.env.FX_API_URL;
  if (!url) return;
  const res = await fetch(url);
  if (!res.ok) return;
  const data = await res.json() as any;
  const rate = data?.rates?.PKR;
  if (!rate) return;

  await prisma.setting.upsert({
    where: { key: 'usd_to_pkr' },
    update: { value: { rate, updatedAt: new Date().toISOString() } },
    create: { key: 'usd_to_pkr', value: { rate, updatedAt: new Date().toISOString() } }
  });
}

export async function getFxRate() {
  const s = await prisma.setting.findUnique({ where: { key: 'usd_to_pkr' } });
  const rate = (s?.value as any)?.rate;
  if (!rate) return 280;
  return rate as number;
}
