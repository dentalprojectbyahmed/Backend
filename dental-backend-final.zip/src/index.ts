import express from 'express';
import dotenv from 'dotenv';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

import { loggingMiddleware } from './middleware/logging';
import { authRequired } from './middleware/auth';
import authRouter from './routes/auth';
import patientsRouter from './routes/patients';
import appointmentsRouter from './routes/appointments';
import catalogRouter from './routes/catalog';
import treatmentsRouter from './routes/treatments';
import prescriptionsRouter from './routes/prescriptions';
import prescriptionTemplatesRouter from './routes/prescriptionTemplates';
import consentsRouter from './routes/consents';
import backupRouter from './routes/backup';
import googleRouter from './routes/google';
import pdfRouter from './routes/pdf';
import reportsRouter from './routes/reports';
import { registerCronJobs } from './cron/jobs';

dotenv.config();

const app = express();

app.use(helmet());
app.use(cors({
  origin: (origin, callback) => {
    const allowed = (process.env.CORS_ORIGINS || '').split(',').map(o => o.trim()).filter(Boolean);
    if (!origin || allowed.length === 0 || allowed.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  }
}));
app.use(express.json());
app.use(loggingMiddleware);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000
});
app.use(limiter);

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, at: new Date().toISOString() });
});

app.use('/api/auth', authRouter);
app.use('/api/google', googleRouter);

app.use('/api/patients', authRequired, patientsRouter);
app.use('/api/appointments', authRequired, appointmentsRouter);
app.use('/api/catalog', authRequired, catalogRouter);
app.use('/api/treatments', authRequired, treatmentsRouter);
app.use('/api/prescriptions', authRequired, prescriptionsRouter);
app.use('/api/prescription-templates', authRequired, prescriptionTemplatesRouter);
app.use('/api/consents', authRequired, consentsRouter);
app.use('/api/backup', authRequired, backupRouter);
app.use('/api/pdf', authRequired, pdfRouter);
app.use('/api/reports', authRequired, reportsRouter);

registerCronJobs();

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`Dental backend listening on ${port}`);
});
