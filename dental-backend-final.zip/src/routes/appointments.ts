import { Router } from 'express';
import { prisma } from '../lib/prisma';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const { date, status } = req.query;
    const where: any = {};

    if (date) {
      const d = new Date(String(date));
      const start = new Date(d);
      start.setHours(0, 0, 0, 0);
      const end = new Date(start);
      end.setDate(end.getDate() + 1);
      where.date = { gte: start, lt: end };
    }

    if (status) where.status = String(status);

    const items = await prisma.appointment.findMany({
      where,
      orderBy: { date: 'asc' },
      include: { patient: true }
    });

    res.json({ items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list appointments' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patientId, date, reason } = req.body;
    const d = new Date(date);

    // strict no double booking for same time slot
    const existing = await prisma.appointment.findFirst({
      where: { date: d }
    });
    if (existing) {
      return res.status(400).json({ error: 'Time slot already booked' });
    }

    const appt = await prisma.appointment.create({
      data: {
        patientId,
        date: d,
        reason,
        status: 'booked'
      }
    });

    res.status(201).json(appt);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create appointment' });
  }
});

router.patch('/:id/status', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { status } = req.body;
    const appt = await prisma.appointment.update({
      where: { id },
      data: { status }
    });
    res.json(appt);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

export default router;
