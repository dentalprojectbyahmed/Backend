import { Router } from 'express';
import { authRequired, requireRole } from '../middleware/auth';
import { generateDriveAuthUrl, saveDriveTokens } from '../lib/googleDrive';
import { prisma } from '../lib/prisma';

const router = Router();

router.get('/drive/auth-url', authRequired, requireRole(['admin']), (_req, res) => {
  try {
    const url = generateDriveAuthUrl();
    res.json({ url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate auth URL' });
  }
});

router.get('/drive/callback', async (req, res) => {
  try {
    const code = req.query.code as string;
    if (!code) return res.status(400).json({ error: 'Missing code' });
    await saveDriveTokens(code);
    res.send('Drive connected. You can close this window.');
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save tokens' });
  }
});

router.get('/drive/status', authRequired, requireRole(['admin']), async (_req, res) => {
  try {
    const setting = await prisma.setting.findUnique({ where: { key: 'google_drive_tokens' } });
    res.json({ connected: !!setting });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to check status' });
  }
});

export default router;
