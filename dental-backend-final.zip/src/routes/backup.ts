import { Router } from 'express';
import { exportFullBackup, uploadBackupToDrive } from '../lib/backup';
import { requireRole } from '../middleware/auth';

const router = Router();

router.get('/export', requireRole(['admin']), async (_req, res) => {
  try {
    const data = await exportFullBackup();
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to export backup' });
  }
});

router.post('/drive-now', requireRole(['admin']), async (_req, res) => {
  try {
    const result = await uploadBackupToDrive();
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to upload backup' });
  }
});

export default router;
