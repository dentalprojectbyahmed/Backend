import { Router } from 'express';
import { buildInvoicePdf } from '../lib/pdf';

const router = Router();

router.get('/invoice/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const buffer = await buildInvoicePdf(id);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename=invoice-${id}.pdf`);
    res.send(buffer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate invoice PDF' });
  }
});

export default router;
