import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { audit } from '../lib/audit';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const search = (req.query.search as string) || '';
    const where = search
      ? {
          OR: [
            { name: { contains: search, mode: 'insensitive' } },
            { phone: { contains: search } }
          ]
        }
      : {};

    const patients = await prisma.patient.findMany({
      where,
      orderBy: { createdAt: 'desc' }
    });

    res.json({ items: patients });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list patients' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const patient = await prisma.patient.findUnique({
      where: { id },
      include: {
        appointments: true,
        treatments: true,
        prescriptions: true,
        consents: true
      }
    });
    if (!patient) return res.status(404).json({ error: 'Not found' });
    res.json(patient);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load patient' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { name, phone, age, gender, address, notes, behaviorTag } = req.body;
    const patient = await prisma.patient.create({
      data: { name, phone, age, gender, address, notes, behaviorTag }
    });
    await audit(req.user?.userId, 'create', 'Patient', patient.id, { name, phone });
    res.status(201).json(patient);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create patient' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, phone, age, gender, address, notes, behaviorTag } = req.body;
    const patient = await prisma.patient.update({
      where: { id },
      data: { name, phone, age, gender, address, notes, behaviorTag }
    });
    await audit(req.user?.userId, 'update', 'Patient', id, { name, phone });
    res.json(patient);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update patient' });
  }
});

export default router;
