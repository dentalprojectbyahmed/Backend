import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { requireRole } from '../middleware/auth';
import { audit } from '../lib/audit';

const router = Router();

router.get('/templates', async (_req, res) => {
  try {
    const templates = await prisma.consentTemplate.findMany({
      orderBy: { name: 'asc' }
    });
    res.json({ items: templates });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list templates' });
  }
});

router.post('/templates', requireRole(['admin']), async (req, res) => {
  try {
    const { name, bodyText } = req.body;
    const tmpl = await prisma.consentTemplate.create({
      data: { name, bodyText }
    });
    res.status(201).json(tmpl);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create template' });
  }
});

router.put('/templates/:id', requireRole(['admin']), async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, bodyText } = req.body;
    const tmpl = await prisma.consentTemplate.update({
      where: { id },
      data: { name, bodyText }
    });
    res.json(tmpl);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update template' });
  }
});

router.post('/records', async (req, res) => {
  try {
    const { templateId, patientId, treatmentId } = req.body;
    const record = await prisma.consentRecord.create({
      data: {
        templateId,
        patientId,
        treatmentId: treatmentId || null
      }
    });
    await audit(req.user?.userId, 'create', 'ConsentRecord', record.id, { templateId, patientId, treatmentId });
    res.status(201).json(record);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create consent record' });
  }
});

router.get('/records', async (req, res) => {
  try {
    const { patientId } = req.query;
    const where: any = {};
    if (patientId) where.patientId = Number(patientId);
    const records = await prisma.consentRecord.findMany({
      where,
      orderBy: { signedAt: 'desc' },
      include: { template: true, treatment: true }
    });
    res.json({ items: records });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list consent records' });
  }
});

export default router;
