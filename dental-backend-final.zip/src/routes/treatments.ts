import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { getFxRate } from '../lib/fx';
import { audit } from '../lib/audit';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const { patientId, status } = req.query;
    const where: any = {};
    if (patientId) where.patientId = Number(patientId);
    if (status) where.status = String(status);

    const items = await prisma.treatment.findMany({
      where,
      orderBy: { date: 'desc' }
    });

    res.json({ items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list treatments' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patientId, appointmentId, date, items, status } = req.body;
    const rate = await getFxRate();

    const totalUsd = (items || []).reduce(
      (sum: number, it: any) => sum + (it.unitUsd || 0) * (it.qty || 1),
      0
    );
    const totalPkr = totalUsd * rate;

    const treatment = await prisma.treatment.create({
      data: {
        patientId,
        appointmentId: appointmentId || null,
        date: new Date(date),
        items,
        totalUsd,
        totalPkr,
        discountPkr: 0,
        paidPkr: 0,
        balancePkr: totalPkr,
        status: status || 'planned'
      }
    });

    await audit(req.user?.userId, 'create', 'Treatment', treatment.id, { totalUsd, totalPkr });

    res.status(201).json(treatment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create treatment' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { items, discountPkr, paidPkr, status } = req.body;
    const rate = await getFxRate();

    const totalUsd = (items || []).reduce(
      (sum: number, it: any) => sum + (it.unitUsd || 0) * (it.qty || 1),
      0
    );
    const totalPkr = totalUsd * rate;
    const disc = discountPkr ?? 0;
    const paid = paidPkr ?? 0;
    const balance = totalPkr - disc - paid;

    const treatment = await prisma.treatment.update({
      where: { id },
      data: {
        items,
        totalUsd,
        totalPkr,
        discountPkr: disc,
        paidPkr: paid,
        balancePkr: balance,
        status: status || 'done'
      }
    });

    await audit(req.user?.userId, 'update', 'Treatment', id, { totalUsd, totalPkr, disc, paid });

    res.json(treatment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update treatment' });
  }
});

export default router;
