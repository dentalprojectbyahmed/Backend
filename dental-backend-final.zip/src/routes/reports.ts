import { Router } from 'express';
import { prisma } from '../lib/prisma';

const router = Router();

router.get('/summary', async (req, res) => {
  try {
    const { from, to } = req.query;
    const wTreat: any = {};
    const wExp: any = {};

    if (from || to) {
      const tDate: any = {};
      const eDate: any = {};
      if (from) {
        const f = new Date(String(from));
        tDate.gte = f;
        eDate.gte = f;
      }
      if (to) {
        const end = new Date(String(to));
        end.setDate(end.getDate() + 1);
        tDate.lte = end;
        eDate.lte = end;
      }
      wTreat.date = tDate;
      wExp.date = eDate;
    }

    const [treatments, expenses] = await Promise.all([
      prisma.treatment.findMany({ where: wTreat }),
      prisma.expense.findMany({ where: wExp })
    ]);

    const revenue = treatments.reduce((sum, t) => sum + (t.paidPkr || 0), 0);
    const outstanding = treatments.reduce((sum, t) => sum + (t.balancePkr || 0), 0);
    const expenseTotal = expenses.reduce((sum, e) => sum + e.amount, 0);

    res.json({
      revenue,
      outstanding,
      expenseTotal,
      net: revenue - expenseTotal
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to build report' });
  }
});

export default router;
