import { Router } from 'express';
import { prisma } from '../lib/prisma';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = Router();

// One-time admin creation
router.post('/register-admin', async (req, res) => {
  try {
    const { email, name, password, pin } = req.body;
    const existing = await prisma.user.findFirst({ where: { role: 'admin' } });
    if (existing) return res.status(400).json({ error: 'Admin already exists' });

    const passwordHash = await bcrypt.hash(password, 10);
    const pinHash = pin ? await bcrypt.hash(pin, 10) : null;

    const user = await prisma.user.create({
      data: { email, name, role: 'admin', passwordHash, pinHash: pinHash || undefined }
    });

    res.status(201).json({ id: user.id, email: user.email });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to register admin' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password, pin } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    if (user.pinHash) {
      if (!pin) return res.status(401).json({ error: 'PIN required' });
      const pinOk = await bcrypt.compare(pin, user.pinHash);
      if (!pinOk) return res.status(401).json({ error: 'Invalid PIN' });
    }

    const secret = process.env.JWT_SECRET;
    if (!secret) return res.status(500).json({ error: 'JWT_SECRET not configured' });

    const token = jwt.sign({ userId: user.id, role: user.role }, secret, { expiresIn: '12h' });

    res.json({
      token,
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
});

export default router;
