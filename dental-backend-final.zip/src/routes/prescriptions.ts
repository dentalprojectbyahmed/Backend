import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { audit } from '../lib/audit';

const router = Router();

router.get('/', async (req, res) => {
  try {
    const { patientId } = req.query;
    const where: any = {};
    if (patientId) where.patientId = Number(patientId);

    const items = await prisma.prescription.findMany({
      where,
      orderBy: { date: 'desc' }
    });

    res.json({ items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list prescriptions' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patientId, date, condition, medications, instructions } = req.body;
    const prescription = await prisma.prescription.create({
      data: {
        patientId,
        date: new Date(date),
        condition,
        medications,
        instructions
      }
    });
    await audit(req.user?.userId, 'create', 'Prescription', prescription.id, { condition });
    res.status(201).json(prescription);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create prescription' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { condition, medications, instructions } = req.body;
    const prescription = await prisma.prescription.update({
      where: { id },
      data: { condition, medications, instructions }
    });
    await audit(req.user?.userId, 'update', 'Prescription', id, { condition });
    res.json(prescription);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update prescription' });
  }
});

export default router;
