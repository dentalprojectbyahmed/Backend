import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { requireRole } from '../middleware/auth';

const router = Router();

router.get('/', async (_req, res) => {
  try {
    const templates = await prisma.prescriptionTemplate.findMany({
      include: { condition: true },
      orderBy: { conditionId: 'asc' }
    });
    res.json({ items: templates });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list templates' });
  }
});

router.post('/', requireRole(['admin', 'doctor']), async (req, res) => {
  try {
    const { conditionId, level, medications, defaultInstructions } = req.body;
    const tmpl = await prisma.prescriptionTemplate.create({
      data: { conditionId, level, medications, defaultInstructions }
    });
    res.status(201).json(tmpl);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create template' });
  }
});

// Use template to create prescription
router.post('/:id/use', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { patientId, date, extraInstructions } = req.body;
    const tmpl = await prisma.prescriptionTemplate.findUnique({
      where: { id },
      include: { condition: true }
    });
    if (!tmpl) return res.status(404).json({ error: 'Template not found' });

    const prescription = await prisma.prescription.create({
      data: {
        patientId,
        date: date ? new Date(date) : new Date(),
        condition: tmpl.condition.name,
        medications: tmpl.medications,
        instructions: extraInstructions || tmpl.defaultInstructions
      }
    });

    res.status(201).json(prescription);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create prescription from template' });
  }
});

export default router;
