import { Router } from 'express';
import { prisma } from '../lib/prisma';
import { getFxRate } from '../lib/fx';

const router = Router();

router.get('/', async (_req, res) => {
  try {
    const rate = await getFxRate();
    const items = await prisma.treatmentCatalog.findMany({
      orderBy: { id: 'asc' }
    });
    const converted = items.map((t) => ({
      ...t,
      pkr: t.usd * rate
    }));
    res.json({ items: converted, usdToPkr: rate });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load catalog' });
  }
});

export default router;
