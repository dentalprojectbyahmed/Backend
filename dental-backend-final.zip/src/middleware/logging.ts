import { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';

export function loggingMiddleware(req: Request, res: Response, next: NextFunction) {
  const requestId = randomUUID();
  (req as any).requestId = requestId;
  const start = Date.now();

  res.on('finish', () => {
    const duration = Date.now() - start;
    const log = {
      requestId,
      method: req.method,
      url: req.originalUrl,
      status: res.statusCode,
      durationMs: duration
    };
    // eslint-disable-next-line no-console
    console.log(JSON.stringify(log));
  });

  next();
}
