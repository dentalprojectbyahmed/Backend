import cron from 'node-cron';
import { prisma } from '../lib/prisma';
import { uploadBackupToDrive } from '../lib/backup';
import { updateDailyFxRate } from '../lib/fx';

export function registerCronJobs() {
  // Auto no-show at 23:00
  cron.schedule('0 23 * * *', async () => {
    try {
      const now = new Date();
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      const end = new Date(start);
      end.setDate(start.getDate() + 1);

      await prisma.appointment.updateMany({
        where: {
          date: { gte: start, lt: end },
          status: { in: ['booked', 'waiting'] }
        },
        data: { status: 'no-show' }
      });
    } catch (err) {
      console.error('no-show cron failed', err);
    }
  });

  // Hourly backup
  cron.schedule('0 * * * *', async () => {
    try {
      await uploadBackupToDrive();
    } catch (err) {
      console.error('backup cron failed', err);
    }
  });

  // Daily FX rate update at 08:00
  cron.schedule('0 8 * * *', async () => {
    try {
      await updateDailyFxRate();
    } catch (err) {
      console.error('fx cron failed', err);
    }
  });
}
