# Dental Backend (Production Seed)

This is a Node.js + Express + TypeScript + Prisma backend for your dental clinic app, aligned with your MASTER ARCHITECTURE PLAN and Claude integration:

- Patients, appointments, treatments, prescriptions.
- Treatment catalog seeded from the 70-item USD-pegged list.
- Live USD→PKR rate (daily) with catalog conversion.
- Consents per treatment, auto-attachable to invoice PDF.
- Prescription templates per condition (basic seed).
- Google Drive JSON backup (hourly).
- Auto no-show at 23:00.
- JWT auth with roles and PIN.
- Basic reports (revenue, outstanding, expenses).

## Setup

1. Install dependencies:

```bash
npm install
```

2. Copy `.env.example` → `.env` and set:

- `DATABASE_URL`
- `JWT_SECRET`
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`
- `CORS_ORIGINS`
- `FX_API_URL` (already set to a public FX API)

3. Migrate + generate:

```bash
npx prisma migrate dev --name init
npx prisma generate
```

4. Seed treatments, conditions, consent templates:

```bash
npx prisma db seed
```

5. Run:

```bash
npm run dev
```

Your developer can now wire the existing frontend to these REST endpoints.
