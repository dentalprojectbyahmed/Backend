
# Production PDF System (pdfkit) – Integration Package

This package gives you:
- A real PDF implementation using `pdfkit` for:
  - Invoice PDFs
  - Treatment Plan PDFs
  - Prescription PDFs
- HTTP endpoints to download PDFs:
  - GET /api/pdf/invoice/:invoiceId
  - GET /api/pdf/treatment-plan/:planId
  - GET /api/pdf/prescription/:prescriptionId

## 1. Install Dependencies

In your project root:

  npm install pdfkit
  npm install --save-dev @types/pdfkit

## 2. Replace / Add Files

Copy the following files from this package into your project, overwriting existing ones:

- src/pdf/pdf.types.ts
- src/pdf/pdf.utils.ts
- src/pdf/invoicePdf.service.ts
- src/pdf/treatmentPlanPdf.service.ts
- src/pdf/prescriptionPdf.service.ts
- src/pdf/pdf.routes.ts

Also replace the service files with extended versions that add getById helpers:

- src/invoices/invoices.service.ts
- src/treatmentPlans/treatmentPlans.service.ts
- src/prescriptions/prescriptions.service.ts
- src/patients/patients.service.ts

## 3. Wire PDF Routes

In your routes index (index.master.ts), add:

  import pdfRouter from "../pdf/pdf.routes";

  // inside registerRoutes(app):
  app.use("/api/pdf", pdfRouter);

## 4. Use

Invoice PDF:
  GET /api/pdf/invoice/{invoiceId}

Treatment Plan PDF:
  GET /api/pdf/treatment-plan/{planId}

Prescription PDF:
  GET /api/pdf/prescription/{prescriptionId}

All respond with application/pdf.
