
import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { renderToBuffer } from "./pdf.utils";
import { Prescription } from "../prescriptions/prescriptions.schema";

export async function renderPrescriptionPdf(
  ctx: PdfRenderContext,
  prescription: Prescription,
  patient: { id: string; name: string }
): Promise<PdfBuffer> {
  return renderToBuffer((doc) => {
    // Header
    doc.fontSize(16).text(ctx.clinic.name);
    doc.fontSize(10).text(ctx.clinic.address);
    doc.text("Phone: " + ctx.clinic.phone);
    doc.moveDown();

    doc.fontSize(14).text("PRESCRIPTION", { align: "right" });
    doc.fontSize(10).text("Date: " + prescription.createdAt, { align: "right" });
    doc.moveDown();

    // Patient & condition
    doc.fontSize(11).text("Patient: " + patient.name + " (" + patient.id + ")");
    doc.text("Condition: " + prescription.conditionCode);
    doc.moveDown(1);

    // Items
    doc.fontSize(11).text("Medications:", { underline: true });
    doc.moveDown(0.5);

    doc.fontSize(10);
    for (const item of prescription.items) {
      doc.text(
        "- " +
          item.drugName +
          " " +
          item.dose +
          ", " +
          item.frequency +
          " for " +
          item.duration
      );
      if (item.notes) {
        doc.text("  Notes: " + item.notes);
      }
      doc.moveDown(0.5);
    }

    doc.moveDown(1.5);

    // Safety notes placeholder (can be expanded)
    doc.fontSize(9).text(
      "Please follow the prescribed doses and contact your doctor if you experience any unusual symptoms.",
      { align: "justify" }
    );

    doc.moveDown(2);
    doc.fontSize(10).text("Doctor's signature: ____________________", { align: "left" });
  });
}
