
import { Router } from "express";
import { z } from "zod";
import { renderInvoicePdf } from "./invoicePdf.service";
import { renderTreatmentPlanPdf } from "./treatmentPlanPdf.service";
import { renderPrescriptionPdf } from "./prescriptionPdf.service";
import { getInvoiceById, listInvoices } from "../invoices/invoices.service";
import { getPlanById } from "../treatmentPlans/treatmentPlans.service";
import { getPrescriptionById } from "../prescriptions/prescriptions.service";
import { getPatientById } from "../patients/patients.service";
import { getConsentsForTreatmentCodes } from "../consents/consents.service";

const router = Router();

// Dummy clinic context – replace with real settings service if available
async function getClinicContext() {
  return {
    clinic: {
      name: "Your Dental Clinic",
      address: "Clinic Address",
      phone: "Clinic Phone"
    }
  };
}

router.get("/invoice/:invoiceId", async (req, res, next) => {
  try {
    const schema = z.object({ invoiceId: z.string().min(1) });
    const { invoiceId } = schema.parse(req.params);

    const invoice = await getInvoiceById(invoiceId);
    if (!invoice) {
      return res.status(404).json({ success: false, error: { code: "NOT_FOUND", message: "Invoice not found" } });
    }

    const patient = await getPatientById(invoice.patientId);
    if (!patient) {
      return res.status(404).json({ success: false, error: { code: "PATIENT_NOT_FOUND", message: "Patient not found" } });
    }

    // Collect consents based on treatment codes; here we assume treatmentId is code-compatible
    const treatmentCodes = invoice.items.map((i: any) => i.treatmentId);
    const consents = await getConsentsForTreatmentCodes(treatmentCodes);

    const ctx = await getClinicContext();
    const pdf = await renderInvoicePdf(
      ctx,
      invoice as any,
      { id: patient.id!, name: patient.name },
      consents.map(c => ({ title: c.title, body: c.body }))
    );

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="invoice-${invoice.number || invoice.id}.pdf"`);
    res.send(pdf);
  } catch (err) {
    next(err);
  }
});

router.get("/treatment-plan/:planId", async (req, res, next) => {
  try {
    const schema = z.object({ planId: z.string().min(1) });
    const { planId } = schema.parse(req.params);

    const plan = await getPlanById(planId);
    if (!plan) {
      return res.status(404).json({ success: false, error: { code: "NOT_FOUND", message: "Treatment plan not found" } });
    }

    const patient = await getPatientById(plan.patientId);
    if (!patient) {
      return res.status(404).json({ success: false, error: { code: "PATIENT_NOT_FOUND", message: "Patient not found" } });
    }

    const ctx = await getClinicContext();
    const pdf = await renderTreatmentPlanPdf(
      ctx,
      plan as any,
      { id: patient.id!, name: patient.name }
    );

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="treatment-plan-${plan.id}.pdf"`);
    res.send(pdf);
  } catch (err) {
    next(err);
  }
});

router.get("/prescription/:prescriptionId", async (req, res, next) => {
  try {
    const schema = z.object({ prescriptionId: z.string().min(1) });
    const { prescriptionId } = schema.parse(req.params);

    const prescription = await getPrescriptionById(prescriptionId);
    if (!prescription) {
      return res.status(404).json({ success: false, error: { code: "NOT_FOUND", message: "Prescription not found" } });
    }

    const patient = await getPatientById(prescription.patientId);
    if (!patient) {
      return res.status(404).json({ success: false, error: { code: "PATIENT_NOT_FOUND", message: "Patient not found" } });
    }

    const ctx = await getClinicContext();
    const pdf = await renderPrescriptionPdf(
      ctx,
      prescription as any,
      { id: patient.id!, name: patient.name }
    );

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="prescription-${prescription.id}.pdf"`);
    res.send(pdf);
  } catch (err) {
    next(err);
  }
});

export default router;
