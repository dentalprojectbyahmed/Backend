
import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { renderToBuffer } from "./pdf.utils";
import { TreatmentPlan } from "../treatmentPlans/treatmentPlans.schema";

export async function renderTreatmentPlanPdf(
  ctx: PdfRenderContext,
  plan: TreatmentPlan,
  patient: { id: string; name: string }
): Promise<PdfBuffer> {
  return renderToBuffer((doc) => {
    doc.fontSize(16).text(ctx.clinic.name);
    doc.fontSize(10).text(ctx.clinic.address);
    doc.text("Phone: " + ctx.clinic.phone);
    doc.moveDown();

    doc.fontSize(14).text("TREATMENT PLAN", { align: "right" });
    doc.fontSize(10).text("Plan ID: " + (plan.id || ""), { align: "right" });
    doc.text("Date: " + plan.createdAt, { align: "right" });
    doc.moveDown();

    doc.fontSize(11).text("Patient: " + patient.name + " (" + patient.id + ")");
    doc.moveDown(1);

    doc.fontSize(11).text("Planned Treatments:", { underline: true });
    doc.moveDown(0.5);

    const col1 = 40;
    const col2 = 260;
    const col3 = 340;
    const col4 = 420;

    doc.fontSize(10);
    doc.text("Treatment", col1);
    doc.text("Tooth", col2);
    doc.text("Status", col3);
    doc.text("Price", col4);
    doc.moveDown();

    let total = 0;
    const formatMoney = (n: number) => "PKR " + n.toFixed(0);

    let y = doc.y + 4;
    for (const item of plan.items) {
      total += item.pricePkr || 0;
      doc.text(item.name, col1, y);
      doc.text(item.tooth || "-", col2, y);
      doc.text(item.status || "PLANNED", col3, y);
      doc.text(formatMoney(item.pricePkr || 0), col4, y, { width: 80, align: "right" });
      y += 16;
    }

    doc.moveDown(2);
    doc.fontSize(12).text("Estimated Total: " + formatMoney(total), { align: "right" });
    doc.moveDown(2);

    doc.fontSize(9).text(
      "This is a treatment estimate. Final cost may vary based on clinical findings and changes in the treatment plan.",
      { align: "justify" }
    );
  });
}
