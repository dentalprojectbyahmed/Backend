
import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { renderToBuffer } from "./pdf.utils";
import { Invoice } from "../invoices/invoices.schema";

export async function renderInvoicePdf(
  ctx: PdfRenderContext,
  invoice: Invoice,
  patient: { id: string; name: string },
  consents: { title: string; body: string }[]
): Promise<PdfBuffer> {
  return renderToBuffer((doc) => {
    // Header
    doc.fontSize(16).text(ctx.clinic.name, { align: "left" });
    doc.fontSize(10).text(ctx.clinic.address);
    doc.text("Phone: " + ctx.clinic.phone);
    doc.moveDown();

    // Invoice meta
    doc.fontSize(14).text("INVOICE", { align: "right" });
    doc.fontSize(10).text("Invoice #: " + (invoice.number || ""), { align: "right" });
    doc.text("Date: " + invoice.date, { align: "right" });
    doc.moveDown();

    // Patient
    doc.fontSize(11).text("Patient: " + patient.name + " (" + patient.id + ")");
    doc.moveDown();

    // Items table
    doc.fontSize(11).text("Items:", { underline: true });
    doc.moveDown(0.3);

    const tableTop = doc.y;
    const col1 = 40;
    const col2 = 260;
    const col3 = 360;
    const col4 = 440;

    doc.fontSize(10);
    doc.text("Treatment", col1, tableTop);
    doc.text("Tooth", col2, tableTop);
    doc.text("Qty", col3, tableTop);
    doc.text("Amount", col4, tableTop);

    doc.moveDown();
    let y = doc.y + 4;

    const formatMoney = (n: number) => "PKR " + n.toFixed(0);

    let gross = 0;
    for (const item of invoice.items) {
      const subtotal = (item.unitPricePkr || 0) * (item.quantity || 1);
      gross += subtotal;

      doc.text(item.name, col1, y);
      doc.text(item.tooth || "-", col2, y);
      doc.text(String(item.quantity || 1), col3, y, { width: 40, align: "right" });
      doc.text(formatMoney(subtotal), col4, y, { width: 80, align: "right" });

      y += 16;
    }

    doc.moveDown(2);

    // Totals
    const discountPercent = invoice.discountPercent || 0;
    const discountFlat = invoice.discountFlat || 0;
    const afterPercent = gross * (1 - discountPercent / 100);
    const total = afterPercent - discountFlat;

    doc.fontSize(11);
    doc.text("Gross: " + formatMoney(gross), { align: "right" });
    doc.text("Discount %: " + discountPercent.toFixed(0) + "%", { align: "right" });
    doc.text("Discount Flat: " + formatMoney(discountFlat), { align: "right" });
    doc.moveDown(0.5);
    doc.fontSize(12).text("Total: " + formatMoney(total), { align: "right" });
    doc.moveDown(1);

    doc.fontSize(10).text("Payment Method: " + invoice.paymentMethod, { align: "right" });
    doc.moveDown(1.5);

    // Consents (second page if needed)
    if (consents.length > 0) {
      doc.addPage();
      doc.fontSize(14).text("Treatment Consents", { align: "left", underline: true });
      doc.moveDown();

      doc.fontSize(10);
      for (const c of consents) {
        doc.fontSize(12).text(c.title, { underline: true });
        doc.moveDown(0.3);
        doc.fontSize(10).text(c.body, { align: "justify" });
        doc.moveDown(1);
      }
    }

    // Footer
    doc.moveDown(2);
    doc.fontSize(8).text("Thank you for choosing " + ctx.clinic.name + ".", {
      align: "center"
    });
  });
}
