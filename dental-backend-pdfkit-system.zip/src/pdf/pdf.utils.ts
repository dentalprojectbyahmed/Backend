
import PDFDocument from "pdfkit";
import { PdfBuffer } from "./pdf.types";

export function renderToBuffer(build: (doc: PDFKit.PDFDocument) => void): Promise<PdfBuffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40 }) as PDFKit.PDFDocument;

    const chunks: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", (err: Error) => reject(err));

    build(doc);
    doc.end();
  });
}
