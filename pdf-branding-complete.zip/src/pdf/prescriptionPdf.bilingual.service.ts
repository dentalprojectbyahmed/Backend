
import { renderToBuffer } from "./pdf.utils";
import { drawHeader, drawFooter, styles } from "./pdf.styling.complete";

export async function renderPrescriptionPdfBilingual(ctx, prescription, patient) {
  return renderToBuffer((doc) => {
    drawHeader(doc, ctx);

    styles.title(doc, "Prescription / نسخہ");

    doc.fontSize(11).text("Patient: " + patient.name + " (" + patient.id + ")");
    doc.text("Condition: " + prescription.conditionCode);
    doc.text("Patient / مریض");
    doc.moveDown(1);

    styles.label(doc, "Medications / ادویات:");

    doc.fontSize(10);
    for (const item of prescription.items) {
      doc.text(
        "- " + item.drugName + " " + item.dose +
        " (" + item.frequency + ", " + item.duration + ")"
      );
      doc.text("  Notes / ہدایات: " + (item.notes || "-"));
      doc.moveDown(0.5);
    }

    doc.moveDown(1.5);
    doc.fontSize(10).text(
      "Follow dosage exactly as written. If symptoms worsen, contact your doctor.",
      { align: "justify" }
    );
    doc.text("دوائی اسی طرح لیں جیسا لکھا گیا ہے۔ اگر علامات بڑھ جائیں تو فوراً ڈاکٹر سے رابطہ کریں۔",
      { align: "right" }
    );

    doc.moveDown(2);
    doc.text("Doctor's signature: ____________________", { align: "left" });

    drawFooter(doc, ctx);
  });
}
