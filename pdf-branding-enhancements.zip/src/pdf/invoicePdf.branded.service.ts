
import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { renderToBuffer } from "./pdf.utils";
import { drawHeader, drawFooter, styles } from "./pdf.styling";

export async function renderInvoicePdfBranded(ctx, invoice, patient, consents) {
  return renderToBuffer((doc) => {
    drawHeader(doc, ctx);

    styles.title(doc, "Invoice");

    doc.fontSize(10).text("Invoice #: " + invoice.number);
    doc.text("Date: " + invoice.date);
    doc.moveDown();

    styles.label(doc, "Patient: " + patient.name + " (" + patient.id + ")");

    // Items table
    doc.moveDown();
    doc.fontSize(11).text("Items", { underline: true });
    doc.moveDown(0.5);

    const col = { t:40, tooth:240, qty:330, amt:420 };

    doc.fontSize(10).text("Treatment", col.t);
    doc.text("Tooth", col.tooth);
    doc.text("Qty", col.qty);
    doc.text("Amount", col.amt);
    doc.moveDown(0.5);

    let y = doc.y;
    let gross=0;
    const format=n=>"PKR " + n.toFixed(0);

    for(const item of invoice.items){
      const subtotal=(item.unitPricePkr||0)*(item.quantity||1);
      gross+=subtotal;
      doc.text(item.name, col.t, y);
      doc.text(item.tooth||"-", col.tooth, y);
      doc.text(String(item.quantity||1), col.qty, y);
      doc.text(format(subtotal), col.amt, y);
      y+=16;
    }

    doc.moveDown(2);
    doc.fontSize(11).text("Gross: "+format(gross),{align:"right"});
    doc.text("Discount %: "+(invoice.discountPercent||0),{align:"right"});
    doc.text("Discount Flat: "+format(invoice.discountFlat||0),{align:"right"});
    const total=gross*(1-(invoice.discountPercent||0)/100)-(invoice.discountFlat||0);
    doc.moveDown(0.5);
    doc.fontSize(12).text("Total: "+format(total),{align:"right"});
    doc.moveDown(1);

    // Consents page
    if(consents.length>0){
      doc.addPage();
      drawHeader(doc, ctx);
      styles.title(doc, "Treatment Consents");
      doc.fontSize(10);
      for(const c of consents){
        doc.fontSize(12).text(c.title,{underline:true});
        doc.moveDown(0.3);
        doc.fontSize(10).text(c.body,{align:"justify"});
        doc.moveDown();
      }
      drawFooter(doc, ctx);
      return;
    }

    drawFooter(doc, ctx);
  });
}
