
Branding Enhancements for PDF System (pdfkit)

This package adds:
- Header block with logo (left) + clinic info (right)
- Footer block with branding text
- Unified typography presets
- Divider lines and spacing system
- Helper function: drawHeader / drawFooter
- Updated invoice, treatment plan, prescription PDFs with new styling
