
const request = require('supertest');
const baseUrl = process.env.BASE_URL || "http://localhost:4000";

describe("Patients API", () => {
  it("should list patients", async () => {
    const res = await request(baseUrl).get("/api/patients");
    expect(res.statusCode).toBe(200);
  });
});
