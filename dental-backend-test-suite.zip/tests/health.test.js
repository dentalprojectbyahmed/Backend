
const request = require('supertest');
const baseUrl = process.env.BASE_URL || "http://localhost:4000";

describe("Health API", () => {
  it("should return 200 for basic health", async () => {
    const res = await request(baseUrl).get("/health");
    expect(res.statusCode).toBe(200);
  });
});
