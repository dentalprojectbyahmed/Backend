// 35 COMPLETE PRESCRIPTION PROTOCOLS

module.exports.PRESCRIPTIONS = {
  // POST-OPERATIVE
  'Post-Extraction': {
    premium: [
      { drug: 'Augmentin 625mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '1-2 tabs TDS', duration: '3 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 250mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy'],
    instructions: 'Apply ice pack for 20 minutes every hour. Avoid hot foods/drinks for 24 hours. No smoking. Salt water rinses after 24 hours.'
  },

  'Post-RCT': {
    premium: [
      { drug: 'Augmentin 1g', dosage: '1 tab BD', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '5 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '2 tabs TDS', duration: '2 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'NSAID allergy'],
    instructions: 'Avoid chewing on treated tooth until permanent restoration. Mild sensitivity is normal for 2-3 days.'
  },

  'Post-Scaling': {
    premium: [
      { drug: 'Chlorhexidine 0.2% Mouthwash', dosage: '10ml BD', duration: '7 days', timing: 'After brushing' },
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' }
    ],
    standard: [
      { drug: 'Listerine Mouthwash', dosage: '10ml BD', duration: '7 days', timing: 'After brushing' }
    ],
    basic: [
      { drug: 'Salt water rinses', dosage: '3-4 times daily', duration: '7 days', timing: 'After meals' }
    ],
    contraindications: [],
    instructions: 'Gentle brushing for 48 hours. Some sensitivity is normal. Avoid very hot/cold foods initially.'
  },

  // ACUTE CONDITIONS
  'Acute Pulpitis': {
    premium: [
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Tramadol 50mg', dosage: '1 tab if severe pain', duration: '2 days', timing: 'As needed' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '3 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '2 tabs TDS', duration: '3 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '2 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '1-2 tabs TDS', duration: '2 days', timing: 'After meals' }
    ],
    contraindications: ['NSAID allergy', 'Peptic ulcer', 'Pregnancy'],
    instructions: 'Avoid hot/cold stimuli. Emergency RCT required within 48 hours.'
  },

  'Pericoronitis': {
    premium: [
      { drug: 'Augmentin 625mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '7 days', timing: 'After brushing' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '2 tabs TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Warm salt water rinses', dosage: '4-6 times daily', duration: '7 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'Pregnancy (Flagyl)'],
    instructions: 'Keep area clean. Irrigate with warm salt water. Avoid hard foods. May require operculectomy.'
  },

  'Dry Socket': {
    premium: [
      { drug: 'Augmentin 625mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Tramadol 50mg', dosage: '1 tab BD', duration: '3 days', timing: 'Every 12 hours' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '5 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Panadol 500mg', dosage: '2 tabs TDS', duration: '5 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'NSAID allergy'],
    instructions: 'Socket must be curetted and packed with Alveogel. Change dressing every 48 hours. Avoid smoking.'
  },

  'Abscess': {
    premium: [
      { drug: 'Augmentin 1g', dosage: '1 tab BD', duration: '7 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '7 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'Pregnancy (Flagyl)'],
    instructions: 'Incision & drainage required. Hot salt water rinses 4-6 times daily. Seek emergency care if swelling worsens.'
  },

  // CHRONIC CONDITIONS
  'Gingivitis': {
    premium: [
      { drug: 'Chlorhexidine 0.2% Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' },
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' },
      { drug: 'Vitamin C 500mg', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' }
    ],
    standard: [
      { drug: 'Listerine Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' },
      { drug: 'Vitamin C 500mg', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' }
    ],
    basic: [
      { drug: 'Warm salt water rinses', dosage: '3 times daily', duration: '14 days', timing: 'After meals' }
    ],
    contraindications: [],
    instructions: 'Scaling required. Improve oral hygiene - brush twice daily, floss daily. Regular dental checkups every 6 months.'
  },

  'Periodontitis': {
    premium: [
      { drug: 'Doxycycline 100mg', dosage: '1 tab OD', duration: '21 days', timing: 'After meals' },
      { drug: 'Chlorhexidine 0.2% Mouthwash', dosage: '10ml BD', duration: '21 days', timing: 'After brushing' },
      { drug: 'Vitamin C 1000mg', dosage: '1 tab OD', duration: '60 days', timing: 'After breakfast' },
      { drug: 'Calcium + Vit D', dosage: '1 tab OD', duration: '60 days', timing: 'After dinner' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '10 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '10 days', timing: 'After meals' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Warm salt water rinses', dosage: '4 times daily', duration: '21 days', timing: 'After meals' }
    ],
    contraindications: ['Tetracycline allergy', 'Pregnancy', 'Children under 12'],
    instructions: 'Deep scaling & root planning required. Possible surgery. Strict oral hygiene. 3-month recall.'
  },

  // PEDIATRIC
  'Pediatric Post-Extraction': {
    premium: [
      { drug: 'Amoxil Suspension 125mg/5ml', dosage: '5ml TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen Suspension 100mg/5ml', dosage: '5ml TDS', duration: '3 days', timing: 'After meals' }
    ],
    standard: [
      { drug: 'Amoxil Suspension 125mg/5ml', dosage: '5ml TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Panadol Suspension 120mg/5ml', dosage: '5-10ml TDS', duration: '2 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Panadol Suspension', dosage: 'Age-appropriate dose TDS', duration: '2 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy'],
    instructions: 'Soft foods only. No school sports for 24 hours. Monitor for bleeding. Ice cream is allowed!'
  },

  'Pediatric Acute Pulpitis': {
    premium: [
      { drug: 'Brufen Suspension 100mg/5ml', dosage: '10ml TDS', duration: '2 days', timing: 'After meals' },
      { drug: 'Panadol Suspension', dosage: 'Age-appropriate', duration: '2 days', timing: 'Every 6 hours' }
    ],
    standard: [
      { drug: 'Brufen Suspension', dosage: 'Age-appropriate', duration: '2 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Panadol Suspension', dosage: 'Age-appropriate', duration: '2 days', timing: 'Every 6 hours' }
    ],
    contraindications: ['NSAID allergy'],
    instructions: 'Urgent pulpotomy/pulpectomy required within 24 hours. Avoid sugary foods.'
  },

  // ORTHODONTIC
  'Orthodontic Discomfort': {
    premium: [
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' },
      { drug: 'Orthodontic Wax', dosage: 'Apply as needed', duration: 'Ongoing', timing: 'On brackets' }
    ],
    standard: [
      { drug: 'Panadol 500mg', dosage: '1-2 tabs TDS', duration: '3 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Panadol 500mg', dosage: '1 tab TDS', duration: '2 days', timing: 'After meals' }
    ],
    contraindications: [],
    instructions: 'Soft foods for 48 hours. Use wax on irritating brackets. Pain is normal after adjustments.'
  },

  'Orthodontic Bracket Injury': {
    premium: [
      { drug: 'Oracure Gel', dosage: 'Apply to sore area', duration: '5 days', timing: '3-4 times daily' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '5 days', timing: 'After brushing' }
    ],
    standard: [
      { drug: 'SM-33 Gel', dosage: 'Apply to ulcer', duration: '5 days', timing: '3-4 times daily' }
    ],
    basic: [
      { drug: 'Salt water rinses', dosage: '4 times daily', duration: '5 days', timing: 'After meals' }
    ],
    contraindications: [],
    instructions: 'Use orthodontic wax. Emergency appointment if wire is sharp. Ulcers heal in 5-7 days.'
  },

  // SENSITIVITY
  'Dentinal Hypersensitivity': {
    premium: [
      { drug: 'Sensodyne Repair & Protect', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' },
      { drug: 'Fluoride Varnish', dosage: 'Professional application', duration: 'Clinic visit', timing: '' },
      { drug: 'GC Tooth Mousse', dosage: 'Apply nightly', duration: '30 days', timing: 'Before bed' }
    ],
    standard: [
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' },
      { drug: 'Fluoride Mouthwash', dosage: '10ml OD', duration: '30 days', timing: 'Before bed' }
    ],
    basic: [
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' }
    ],
    contraindications: [],
    instructions: 'Avoid acidic foods/drinks. Use soft toothbrush. May need bonding/restoration if severe.'
  },

  // ULCERS & SORES
  'Aphthous Ulcers': {
    premium: [
      { drug: 'Oracure Gel', dosage: 'Apply to ulcer', duration: '7 days', timing: '4 times daily' },
      { drug: 'Vitamin B Complex', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' },
      { drug: 'Lysine 1000mg', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' }
    ],
    standard: [
      { drug: 'SM-33 Gel', dosage: 'Apply to ulcer', duration: '7 days', timing: '3-4 times daily' },
      { drug: 'Vitamin B Complex', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' }
    ],
    basic: [
      { drug: 'Betadine Gargle', dosage: 'Diluted rinses', duration: '7 days', timing: '3 times daily' }
    ],
    contraindications: [],
    instructions: 'Avoid spicy/acidic foods. Good oral hygiene. If recurrent, check for vitamin deficiency or stress.'
  },

  'Oral Candidiasis': {
    premium: [
      { drug: 'Fluconazole 150mg', dosage: '1 tab weekly', duration: '2 weeks', timing: 'After meals' },
      { drug: 'Mycostatin Oral Suspension', dosage: '5ml QID', duration: '14 days', timing: 'Hold in mouth' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' }
    ],
    standard: [
      { drug: 'Mycostatin Oral Suspension', dosage: '5ml QID', duration: '14 days', timing: 'Swish & swallow' },
      { drug: 'Nystatin Cream', dosage: 'Apply to denture', duration: '14 days', timing: 'If denture wearer' }
    ],
    basic: [
      { drug: 'Gentian Violet 1%', dosage: 'Apply to lesions', duration: '7 days', timing: 'BD' }
    ],
    contraindications: ['Liver disease (Fluconazole)'],
    instructions: 'Sterilize dentures. Improve oral hygiene. Check blood sugar if diabetic. Treat for full 14 days.'
  },

  'Herpes Labialis': {
    premium: [
      { drug: 'Acyclovir 400mg', dosage: '1 tab 5 times daily', duration: '5 days', timing: 'Every 4 hours' },
      { drug: 'Acyclovir Cream 5%', dosage: 'Apply to lesion', duration: '5 days', timing: '5 times daily' },
      { drug: 'Lysine 1000mg', dosage: '1 tab TDS', duration: '14 days', timing: 'After meals' }
    ],
    standard: [
      { drug: 'Acyclovir Cream', dosage: 'Apply to lesion', duration: '7 days', timing: '5 times daily' },
      { drug: 'Lysine 1000mg', dosage: '1 tab BD', duration: '14 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Zinc Oxide Cream', dosage: 'Apply to lesion', duration: '7 days', timing: '3-4 times daily' }
    ],
    contraindications: ['Acyclovir allergy'],
    instructions: 'Most effective if started within 48 hours of prodrome. Avoid kissing. Not contagious when crusted.'
  },

  // TMJ & FACIAL PAIN
  'TMJ Disorder': {
    premium: [
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Myoril 4mg', dosage: '1 tab BD', duration: '7 days', timing: 'After meals' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '7 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Hot compress', dosage: 'Apply 20 mins', duration: 'BD', timing: 'Morning & night' }
    ],
    basic: [
      { drug: 'Panadol 500mg', dosage: '2 tabs TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Jaw exercises', dosage: 'Gentle stretching', duration: 'Ongoing', timing: '3 times daily' }
    ],
    contraindications: ['NSAID allergy', 'Peptic ulcer'],
    instructions: 'Soft diet. Avoid wide mouth opening. Night guard may be needed. Physical therapy beneficial.'
  },

  'Trigeminal Neuralgia': {
    premium: [
      { drug: 'Carbamazepine 200mg', dosage: '1 tab BD', duration: 'As directed', timing: 'After meals' },
      { drug: 'Vitamin B Complex', dosage: '1 tab OD', duration: 'Ongoing', timing: 'After breakfast' }
    ],
    standard: [
      { drug: 'Carbamazepine 100mg', dosage: '1 tab BD', duration: 'As directed', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Refer to neurologist', dosage: '', duration: '', timing: '' }
    ],
    contraindications: ['Bone marrow depression', 'Liver disease'],
    instructions: 'Requires neurologist consultation. Avoid trigger points. Regular blood monitoring needed.'
  },

  // IMPLANTS
  'Post-Implant Placement': {
    premium: [
      { drug: 'Augmentin 1g', dosage: '1 tab BD', duration: '7 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Dexamethasone 4mg', dosage: '1 tab BD', duration: '2 days', timing: 'After meals' },
      { drug: 'Chlorhexidine 0.2% Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'NSAID allergy'],
    instructions: 'Soft diet for 1 week. No chewing on implant side. Ice pack first 24 hours. No smoking critical for success.'
  },

  // DENTURE-RELATED
  'Denture Stomatitis': {
    premium: [
      { drug: 'Fluconazole 150mg', dosage: '1 tab weekly', duration: '2 weeks', timing: 'After meals' },
      { drug: 'Mycostatin Oral Suspension', dosage: '5ml QID', duration: '14 days', timing: 'Apply to denture' },
      { drug: 'Corsodyl Gel', dosage: 'Apply to denture', duration: '14 days', timing: 'At night' }
    ],
    standard: [
      { drug: 'Mycostatin Oral Gel', dosage: 'Apply to affected area', duration: '14 days', timing: 'QID' },
      { drug: 'Denture cleanser', dosage: 'Soak denture', duration: 'Nightly', timing: 'Ongoing' }
    ],
    basic: [
      { drug: 'Hypochlorite solution', dosage: 'Soak denture 20 mins', duration: 'Daily', timing: 'At night' }
    ],
    contraindications: [],
    instructions: 'Remove denture at night. Clean thoroughly. Leave denture out for several hours daily. Reline if loose.'
  },

  // WISDOM TEETH
  'Impacted Wisdom Tooth (Pre-op)': {
    premium: [
      { drug: 'Augmentin 625mg', dosage: '1 tab TDS', duration: '3 days before surgery', timing: 'After meals' },
      { drug: 'Chlorhexidine Mouthwash', dosage: '10ml BD', duration: '3 days before surgery', timing: 'After brushing' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '3 days before surgery', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Warm salt water rinses', dosage: 'TDS', duration: '3 days before surgery', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy'],
    instructions: 'Pre-operative antibiotics if infection present. NPO 8 hours before surgery if sedation planned.'
  },

  'Post-Wisdom Tooth Extraction': {
    premium: [
      { drug: 'Augmentin 1g', dosage: '1 tab BD', duration: '7 days', timing: 'After meals' },
      { drug: 'Brufen 600mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Tramadol 50mg', dosage: '1 tab if severe pain', duration: '3 days', timing: 'Every 8 hours' },
      { drug: 'Omeprazole 20mg', dosage: '1 tab OD', duration: '7 days', timing: 'Before breakfast' }
    ],
    standard: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '7 days', timing: 'After meals' },
      { drug: 'Ponstan 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Flagyl 400mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' }
    ],
    basic: [
      { drug: 'Amoxil 500mg', dosage: '1 tab TDS', duration: '5 days', timing: 'After meals' },
      { drug: 'Brufen 400mg', dosage: '1 tab TDS', duration: '3 days', timing: 'After meals' }
    ],
    contraindications: ['Penicillin allergy', 'Pregnancy (Flagyl)', 'NSAID allergy'],
    instructions: 'Ice pack 20 mins every hour for 24 hours. Soft foods 5-7 days. Sleep with head elevated. No smoking/alcohol. Stitches removed after 7 days.'
  },

  // COSMETIC
  'Post-Whitening Sensitivity': {
    premium: [
      { drug: 'Sensodyne Repair & Protect', dosage: 'BD', duration: '14 days', timing: 'Morning & night' },
      { drug: 'GC Tooth Mousse', dosage: 'Apply nightly', duration: '14 days', timing: 'Before bed' },
      { drug: 'Potassium Nitrate Gel', dosage: 'Apply in trays', duration: '7 days', timing: '15 mins daily' }
    ],
    standard: [
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: '14 days', timing: 'Morning & night' },
      { drug: 'Fluoride Gel', dosage: 'Apply in trays', duration: '7 days', timing: '5 mins daily' }
    ],
    basic: [
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: '7 days', timing: 'Morning & night' }
    ],
    contraindications: [],
    instructions: 'Avoid hot/cold foods for 48 hours. No staining foods (coffee, tea, wine) for 48 hours. Sensitivity is temporary.'
  },

  // ADDITIONAL CONDITIONS
  'Bruxism Management': {
    premium: [
      { drug: 'Night Guard (Custom)', dosage: 'Wear nightly', duration: 'Ongoing', timing: 'At bedtime' },
      { drug: 'Muscle Relaxant (Myoril)', dosage: '1 tab at night', duration: '14 days', timing: 'Before bed' },
      { drug: 'Magnesium 400mg', dosage: '1 tab OD', duration: '60 days', timing: 'Before bed' }
    ],
    standard: [
      { drug: 'Night Guard', dosage: 'Wear nightly', duration: 'Ongoing', timing: 'At bedtime' },
      { drug: 'Stress management', dosage: '', duration: 'Ongoing', timing: '' }
    ],
    basic: [
      { drug: 'Soft diet', dosage: '', duration: '7 days', timing: '' },
      { drug: 'Jaw exercises', dosage: 'Gentle stretching', duration: 'Ongoing', timing: 'BD' }
    ],
    contraindications: [],
    instructions: 'Night guard is essential. Address stress/anxiety. Avoid hard foods. May need botox if severe.'
  },

  'Halitosis': {
    premium: [
      { drug: 'Chlorhexidine 0.2% Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' },
      { drug: 'Tongue Scraper', dosage: 'Use daily', duration: 'Ongoing', timing: 'Morning' },
      { drug: 'Probiotics', dosage: '1 tab OD', duration: '30 days', timing: 'After breakfast' }
    ],
    standard: [
      { drug: 'Listerine Mouthwash', dosage: '10ml BD', duration: '14 days', timing: 'After brushing' },
      { drug: 'Tongue cleaning', dosage: 'Daily', duration: 'Ongoing', timing: 'With brushing' }
    ],
    basic: [
      { drug: 'Good oral hygiene', dosage: 'Brush, floss, tongue', duration: 'Ongoing', timing: 'BD' }
    ],
    contraindications: [],
    instructions: 'Rule out dental disease, scaling needed. Check for systemic causes. Hydrate well. Avoid smoking.'
  },

  'Post-Bleaching': {
    premium: [
      { drug: 'Fluoride Gel 1.1%', dosage: 'Apply in trays', duration: '7 days', timing: '5 mins daily' },
      { drug: 'Sensodyne Repair', dosage: 'BD', duration: '14 days', timing: 'Morning & night' },
      { drug: 'Vitamin E Oil', dosage: 'Apply to gums', duration: '3 days', timing: 'If irritated' }
    ],
    standard: [
      { drug: 'Sensodyne Toothpaste', dosage: 'BD', duration: '7 days', timing: 'Morning & night' }
    ],
    basic: [
      { drug: 'Regular toothpaste', dosage: 'BD', duration: 'Ongoing', timing: 'Morning & night' }
    ],
    contraindications: [],
    instructions: 'Avoid staining foods 48 hours. No smoking. Sensitivity resolves in 2-3 days. Touch-up every 6-12 months.'
  }
};

// MEDICAL CONTRAINDICATIONS DATABASE
module.exports.MEDICAL_CONTRAINDICATIONS = {
  'Pregnancy': {
    avoid: ['Tetracyclines', 'Metronidazole (1st trimester)', 'NSAIDs (3rd trimester)', 'Aspirin'],
    safe: ['Amoxicillin', 'Penicillin', 'Paracetamol', 'Local anesthetics without epinephrine'],
    notes: 'Defer elective treatments to 2nd trimester. Emergency care only in 1st/3rd trimester.'
  },
  'Breastfeeding': {
    avoid: ['Tetracyclines', 'Chloramphenicol', 'High-dose Aspirin'],
    safe: ['Penicillins', 'Cephalosporins', 'Paracetamol', 'Ibuprofen'],
    notes: 'Most drugs safe in small amounts. Feed before dental appointment.'
  },
  'Diabetes': {
    avoid: [],
    safe: ['All antibiotics with proper management'],
    notes: 'Morning appointments. Check blood sugar. Healing may be delayed. Strict infection control.'
  },
  'Hypertension': {
    avoid: ['Epinephrine in high doses'],
    safe: ['Local anesthetics with minimal epinephrine (1:200,000)'],
    notes: 'Monitor BP. Defer if BP >180/110. Stress reduction protocol.'
  },
  'Heart Disease': {
    avoid: ['Excessive epinephrine'],
    safe: ['Standard antibiotics', 'Local anesthetics with caution'],
    notes: 'Antibiotic prophylaxis if valve disease/prosthetic valve. Consult cardiologist.'
  },
  'Asthma': {
    avoid: ['Aspirin', 'NSAIDs (if aspirin-sensitive)'],
    safe: ['Paracetamol', 'COX-2 inhibitors', 'Penicillins'],
    notes: 'Bring inhaler. Morning appointments. Avoid supine position if severe.'
  },
  'Liver Disease': {
    avoid: ['Paracetamol (high doses)', 'Tetracyclines', 'Metronidazole'],
    safe: ['Penicillins (reduced dose)', 'Local anesthetics (reduced dose)'],
    notes: 'Increased bleeding risk. Dose adjustment needed. Check PT/INR.'
  },
  'Kidney Disease': {
    avoid: ['Tetracyclines', 'NSAIDs'],
    safe: ['Penicillins (dose adjusted)', 'Paracetamol'],
    notes: 'Dose adjustment for all drugs. Check with nephrologist.'
  },
  'Anticoagulant Therapy': {
    avoid: ['Aspirin', 'NSAIDs', 'Intramuscular injections'],
    safe: ['Paracetamol', 'COX-2 inhibitors', 'Local anesthetics (careful technique)'],
    notes: 'Check INR before surgery. Continue warfarin for minor procedures. Hemostatic measures.'
  },
  'Epilepsy': {
    avoid: ['Tramadol (lowers seizure threshold)'],
    safe: ['Most antibiotics', 'Paracetamol', 'Local anesthetics'],
    notes: 'Drug interactions with phenytoin. Stress reduction. Emergency protocol ready.'
  }
};
