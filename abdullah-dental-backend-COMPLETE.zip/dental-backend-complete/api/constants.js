const { TREATMENTS, BEHAVIOR_TAGS, PAYMENT_METHODS, EXPENSE_CATEGORIES, CLINIC_INFO, TOOTH_CHARTS } = require('../data/constants');
const { PRESCRIPTIONS, MEDICAL_CONTRAINDICATIONS } = require('../data/prescriptions');
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  try {
    return res.json({ 
      success: true, 
      data: { 
        treatments: TREATMENTS, 
        behaviorTags: BEHAVIOR_TAGS, 
        paymentMethods: PAYMENT_METHODS, 
        expenseCategories: EXPENSE_CATEGORIES, 
        clinicInfo: CLINIC_INFO, 
        toothCharts: TOOTH_CHARTS,
        prescriptionConditions: Object.keys(PRESCRIPTIONS),
        medicalContraindications: Object.keys(MEDICAL_CONTRAINDICATIONS)
      } 
    });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
