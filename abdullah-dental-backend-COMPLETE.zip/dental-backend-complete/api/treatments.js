const sheetsDb = require('../lib/sheetsDb');
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();
  try {
    await sheetsDb.initialize();
    if (req.method === 'GET') {
      const data = await sheetsDb.getTreatments(req.query.patientId);
      return res.json({ success: true, data });
    }
    if (req.method === 'POST') {
      const data = await sheetsDb.createTreatment(req.body);
      await sheetsDb.updatePoints('treatment_completed');
      return res.status(201).json({ success: true, data });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
};
