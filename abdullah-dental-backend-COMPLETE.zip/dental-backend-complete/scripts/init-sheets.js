const { google } = require('googleapis');

async function initializeSpreadsheet() {
  const auth = new google.auth.GoogleAuth({
    credentials: {
      client_email: process.env.GOOGLE_CLIENT_EMAIL,
      private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    },
    scopes: ['https://www.googleapis.com/auth/spreadsheets'],
  });

  const sheets = google.sheets({ version: 'v4', auth });
  const spreadsheetId = process.env.SPREADSHEET_ID;

  console.log('🦷 Initializing Abdullah Dental Care Backend...\n');

  const sheetSetup = [
    { name: 'Patients', headers: ['ID', 'Name', 'Phone', 'Age', 'Gender', 'Address', 'Behavior Tag', 'Medical History', 'Allergies', 'Last Visit', 'Outstanding Balance', 'Created At', 'Updated At'] },
    { name: 'Appointments', headers: ['ID', 'Patient ID', 'Patient Name', 'Phone', 'Date', 'Time', 'Type', 'Status', 'Notes', 'Reminder Sent', 'Created At', 'Updated At'] },
    { name: 'Treatments', headers: ['ID', 'Patient ID', 'Patient Name', 'Date', 'Items (JSON)', 'Teeth (JSON)', 'Total', 'Discount', 'Discount Type', 'Paid', 'Balance', 'Status', 'Created At', 'Updated At'] },
    { name: 'Prescriptions', headers: ['ID', 'Patient ID', 'Patient Name', 'Date', 'Condition', 'Tier', 'Medications (JSON)', 'Instructions', 'Warnings', 'Created At', 'Updated At'] },
    { name: 'LabWork', headers: ['ID', 'Patient ID', 'Patient Name', 'Date', 'Description', 'Lab Name', 'Lab Charges', 'Status', 'Sent Date', 'Return Date', 'Notes', 'Created At', 'Updated At'] },
    { name: 'Expenses', headers: ['ID', 'Date', 'Category', 'Amount', 'Description', 'Payment Method', 'Vendor', 'Receipt URL', 'Created At', 'Updated At'] },
    { name: 'Orthodontics', headers: ['ID', 'Patient ID', 'Patient Name', 'Start Date', 'Type', 'Total Cost', 'Advance Payment', 'Installments (JSON)', 'Monthly Amount', 'Paid Installments', 'Status', 'Last Payment Date', 'Created At', 'Updated At'] },
    { name: 'Gamification', headers: ['ID', 'Points', 'Streak', 'Action', 'Points Earned', 'Date'] },
    { name: 'Recalls', headers: ['ID', 'Patient ID', 'Recall Date', 'Status', 'Created At'] }
  ];

  for (const sheet of sheetSetup) {
    try {
      await sheets.spreadsheets.batchUpdate({
        spreadsheetId,
        requestBody: { requests: [{ addSheet: { properties: { title: sheet.name }}}]}
      });
      await sheets.spreadsheets.values.update({
        spreadsheetId, range: `${sheet.name}!A1`, valueInputOption: 'RAW',
        requestBody: { values: [sheet.headers] }
      });
      console.log(`✅ ${sheet.name} created`);
    } catch (error) {
      if (error.message.includes('already exists')) {
        console.log(`⚠️  ${sheet.name} exists, skipping...`);
      } else {
        console.error(`❌ Error: ${sheet.name}:`, error.message);
      }
    }
  }

  console.log('\n🎉 Spreadsheet initialization complete!');
  console.log(`📋 URL: https://docs.google.com/spreadsheets/d/${spreadsheetId}`);
}

initializeSpreadsheet().catch(console.error);
