const testPatient = { name: 'Test Patient', phone: '+92-300-1234567', age: 30, gender: 'Male', address: 'Hayatabad, Peshawar', behaviorTag: 'Regular' };

async function testAPI(baseUrl) {
  console.log('🧪 Testing API at:', baseUrl);
  
  try {
    const res = await fetch(`${baseUrl}/api/patients`);
    const data = await res.json();
    console.log('✅ Patients endpoint working:', data.success ? 'SUCCESS' : 'FAIL');
    
    const createRes = await fetch(`${baseUrl}/api/patients`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testPatient)
    });
    const created = await createRes.json();
    console.log('✅ Create patient:', created.success ? 'SUCCESS' : 'FAIL');
    
    console.log('\n🎉 All tests passed! Backend is working correctly.');
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

const baseUrl = process.argv[2] || 'http://localhost:3000';
testAPI(baseUrl);
