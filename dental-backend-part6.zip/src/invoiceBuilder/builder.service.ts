export function buildInvoice(items,discountFlat,discountPercent){
 const enriched=items.map(i=>({...i,subtotal:i.quantity*i.unitPricePkr}));
 const gross=enriched.reduce((s,x)=>s+x.subtotal,0);
 const afterP=gross*(1-discountPercent/100);
 const total=afterP-discountFlat;
 return {items:enriched,gross,total};
}