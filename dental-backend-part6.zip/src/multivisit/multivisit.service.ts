export function advanceVisit(item){
 if(!item.multiVisitTotalVisits)return {done:true};
 const completed=item.multiVisitCompletedVisits||0;
 const next=completed+1;
 const done=next>=item.multiVisitTotalVisits;
 return {done,completed:next};
}