import {AdultTeeth} from './chart.model';
export function isValidTooth(t){return AdultTeeth.includes(t);}
export function getQuadrant(t){const n=parseInt(t);if(n>=11 && n<=18)return 'UR';if(n>=21 && n<=28)return 'UL';if(n>=31 && n<=38)return 'LL';if(n>=41 && n<=48)return 'LR';return null;}