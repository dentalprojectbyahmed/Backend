
# Dental Backend – Part 7B (Infrastructure & Utility Layer)

This part adds:
- Feature flags module
- SMS & Email provider facades
- Text template engine
- ID/numbering utilities
- System health monitor
- Config registry
