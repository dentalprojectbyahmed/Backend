
/**
 * Very simple template engine:
 * - Replaces {{key}} with values from context.
 */
export function renderTemplate(template: string, context: Record<string, any>): string {
  return template.replace(/{{\s*([a-zA-Z0-9_]+)\s*}}/g, (_match, key) => {
    const val = context[key];
    return val === undefined || val === null ? "" : String(val);
  });
}
