
/**
 * Simple in-memory config registry.
 * In a real system this could come from a DB or environment.
 */

const configStore: Record<string, any> = {};

export function setConfig(key: string, value: any) {
  configStore[key] = value;
}

export function getConfig<T = any>(key: string, defaultValue?: T): T | undefined {
  const val = configStore[key];
  if (val === undefined) return defaultValue;
  return val as T;
}

export function getAllConfig(): Record<string, any> {
  return { ...configStore };
}
