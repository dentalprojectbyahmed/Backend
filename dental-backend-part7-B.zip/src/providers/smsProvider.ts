
export type SmsPayload = {
  to: string;
  body: string;
};

export interface SmsProvider {
  send(payload: SmsPayload): Promise<void>;
}

/**
 * Default dummy implementation.
 * Replace with Twilio, local gateway, etc.
 */
export class DummySmsProvider implements SmsProvider {
  async send(payload: SmsPayload): Promise<void> {
    // eslint-disable-next-line no-console
    console.log("[DummySmsProvider] SMS to %s: %s", payload.to, payload.body);
  }
}
