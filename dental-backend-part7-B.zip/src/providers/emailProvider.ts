
export type EmailPayload = {
  to: string;
  subject: string;
  body: string;
};

export interface EmailProvider {
  send(payload: EmailPayload): Promise<void>;
}

/**
 * Default dummy implementation.
 * Replace with real SMTP / transactional email.
 */
export class DummyEmailProvider implements EmailProvider {
  async send(payload: EmailPayload): Promise<void> {
    // eslint-disable-next-line no-console
    console.log("[DummyEmailProvider] Email to %s: %s", payload.to, payload.subject);
  }
}
