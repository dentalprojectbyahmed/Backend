
import { getCachedRate } from "../usdPkr/usdPkr.service";

export type HealthCheck = {
  name: string;
  ok: boolean;
  detail?: string;
};

export type HealthReport = {
  status: "ok" | "degraded";
  checks: HealthCheck[];
};

export async function buildHealthReport(): Promise<HealthReport> {
  const checks: HealthCheck[] = [];

  // Example: USD→PKR cache
  const rate = getCachedRate();
  checks.push({
    name: "usd_pkr_cache",
    ok: !!rate,
    detail: rate ? "rate cached for " + rate.date : "no rate cached"
  });

  const degraded = checks.some(c => !c.ok);
  return {
    status: degraded ? "degraded" : "ok",
    checks
  };
}
