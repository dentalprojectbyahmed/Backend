
import { Router } from "express";
import { buildHealthReport } from "./health.service";

const router = Router();

router.get("/deep", async (_req, res, next) => {
  try {
    const report = await buildHealthReport();
    res.json({ success: true, data: report });
  } catch (err) {
    next(err);
  }
});

export default router;
