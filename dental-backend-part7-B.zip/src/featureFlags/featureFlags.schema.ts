
export type FeatureFlag = {
  key: string;
  enabled: boolean;
  description?: string;
};
