
import { FeatureFlag } from "./featureFlags.schema";

const flags: FeatureFlag[] = [];

export function setFlag(key: string, enabled: boolean, description?: string) {
  const existing = flags.find(f => f.key === key);
  if (existing) {
    existing.enabled = enabled;
    if (description !== undefined) existing.description = description;
    return existing;
  }
  const f: FeatureFlag = { key, enabled, description };
  flags.push(f);
  return f;
}

export function isEnabled(key: string): boolean {
  const f = flags.find(x => x.key === key);
  return !!(f && f.enabled);
}

export function listFlags(): FeatureFlag[] {
  return flags;
}
