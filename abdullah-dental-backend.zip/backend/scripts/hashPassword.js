const bcrypt = require('bcryptjs');
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(password, salt);
  console.log(`Password: ${password}\nHashed: ${hash}`);
}
hashPassword(process.argv[2] || 'admin123');
