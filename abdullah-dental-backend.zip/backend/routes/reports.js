const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/revenue', async (req, res) => {
  try {
    const { date_from, date_to } = req.query;
    let query = 'SELECT SUM(amount) as total_revenue, COUNT(*) as transaction_count FROM billing WHERE 1=1';
    const params = [];
    if (date_from) { query += ' AND billing_date >= ?'; params.push(date_from); }
    if (date_to) { query += ' AND billing_date <= ?'; params.push(date_to); }
    const [result] = await db.query(query, params);
    res.json(result[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get revenue report', details: error.message });
  }
});

router.get('/expenses-summary', async (req, res) => {
  try {
    const { date_from, date_to } = req.query;
    let query = 'SELECT SUM(amount) as total_expenses, category, COUNT(*) as count FROM expenses WHERE 1=1';
    const params = [];
    if (date_from) { query += ' AND expense_date >= ?'; params.push(date_from); }
    if (date_to) { query += ' AND expense_date <= ?'; params.push(date_to); }
    query += ' GROUP BY category';
    const [results] = await db.query(query, params);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get expenses summary', details: error.message });
  }
});

router.get('/dashboard-stats', async (req, res) => {
  try {
    const [patients] = await db.query('SELECT COUNT(*) as count FROM patients');
    const [appointments] = await db.query('SELECT COUNT(*) as count FROM appointments WHERE appointment_date = CURDATE()');
    const [revenue] = await db.query('SELECT SUM(amount) as total FROM billing WHERE MONTH(billing_date) = MONTH(CURDATE())');
    const [expenses] = await db.query('SELECT SUM(amount) as total FROM expenses WHERE MONTH(expense_date) = MONTH(CURDATE())');
    
    res.json({
      total_patients: patients[0].count,
      today_appointments: appointments[0].count,
      monthly_revenue: revenue[0].total || 0,
      monthly_expenses: expenses[0].total || 0
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get dashboard stats', details: error.message });
  }
});

module.exports = router;
