const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

// All routes are protected
router.use(authMiddleware);

// Get all patients with optional search
router.get('/', async (req, res) => {
  try {
    const { search, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT p.*, 
        COUNT(DISTINCT a.id) as total_appointments,
        COUNT(DISTINCT t.id) as total_treatments,
        SUM(t.amount) as total_revenue
      FROM patients p
      LEFT JOIN appointments a ON p.id = a.patient_id
      LEFT JOIN treatments t ON p.id = t.patient_id
    `;
    
    const params = [];
    
    if (search) {
      query += ` WHERE p.name LIKE ? OR p.phone LIKE ? OR p.email LIKE ?`;
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }
    
    query += ` GROUP BY p.id ORDER BY p.created_at DESC LIMIT ? OFFSET ?`;
    params.push(parseInt(limit), parseInt(offset));
    
    const [patients] = await db.query(query, params);
    
    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM patients';
    if (search) {
      countQuery += ` WHERE name LIKE ? OR phone LIKE ? OR email LIKE ?`;
    }
    const [countResult] = await db.query(countQuery, search ? [`%${search}%`, `%${search}%`, `%${search}%`] : []);
    
    res.json({
      patients,
      total: countResult[0].total,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

  } catch (error) {
    console.error('Get patients error:', error);
    res.status(500).json({ error: 'Failed to get patients', details: error.message });
  }
});

// Get single patient
router.get('/:id', async (req, res) => {
  try {
    const [patients] = await db.query('SELECT * FROM patients WHERE id = ?', [req.params.id]);
    
    if (patients.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }
    
    // Get patient stats
    const [appointments] = await db.query(
      'SELECT COUNT(*) as count FROM appointments WHERE patient_id = ?',
      [req.params.id]
    );
    
    const [treatments] = await db.query(
      'SELECT COUNT(*) as count, SUM(amount) as revenue FROM treatments WHERE patient_id = ?',
      [req.params.id]
    );
    
    const patient = patients[0];
    patient.stats = {
      appointments: appointments[0].count,
      treatments: treatments[0].count,
      revenue: treatments[0].revenue || 0
    };
    
    res.json(patient);

  } catch (error) {
    console.error('Get patient error:', error);
    res.status(500).json({ error: 'Failed to get patient', details: error.message });
  }
});

// Create new patient
router.post('/', async (req, res) => {
  try {
    const {
      name, phone, email, date_of_birth, gender, address,
      medical_history, allergies, emergency_contact, emergency_phone
    } = req.body;

    if (!name || !phone) {
      return res.status(400).json({ error: 'Name and phone are required' });
    }

    // Check for duplicate phone
    const [existing] = await db.query('SELECT id FROM patients WHERE phone = ?', [phone]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Patient with this phone number already exists' });
    }

    const [result] = await db.query(
      `INSERT INTO patients 
      (name, phone, email, date_of_birth, gender, address, medical_history, allergies, emergency_contact, emergency_phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [name, phone, email, date_of_birth, gender, address, medical_history, allergies, emergency_contact, emergency_phone]
    );

    res.status(201).json({
      message: 'Patient created successfully',
      patientId: result.insertId
    });

  } catch (error) {
    console.error('Create patient error:', error);
    res.status(500).json({ error: 'Failed to create patient', details: error.message });
  }
});

// Update patient
router.put('/:id', async (req, res) => {
  try {
    const {
      name, phone, email, date_of_birth, gender, address,
      medical_history, allergies, emergency_contact, emergency_phone, points, badges
    } = req.body;

    const [result] = await db.query(
      `UPDATE patients SET 
      name = ?, phone = ?, email = ?, date_of_birth = ?, gender = ?, address = ?,
      medical_history = ?, allergies = ?, emergency_contact = ?, emergency_phone = ?,
      points = ?, badges = ?
      WHERE id = ?`,
      [name, phone, email, date_of_birth, gender, address, medical_history, allergies, 
       emergency_contact, emergency_phone, points, badges, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json({ message: 'Patient updated successfully' });

  } catch (error) {
    console.error('Update patient error:', error);
    res.status(500).json({ error: 'Failed to update patient', details: error.message });
  }
});

// Delete patient
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM patients WHERE id = ?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }

    res.json({ message: 'Patient deleted successfully' });

  } catch (error) {
    console.error('Delete patient error:', error);
    res.status(500).json({ error: 'Failed to delete patient', details: error.message });
  }
});

// Get patient appointments
router.get('/:id/appointments', async (req, res) => {
  try {
    const [appointments] = await db.query(
      'SELECT * FROM appointments WHERE patient_id = ? ORDER BY appointment_date DESC, appointment_time DESC',
      [req.params.id]
    );

    res.json(appointments);

  } catch (error) {
    console.error('Get patient appointments error:', error);
    res.status(500).json({ error: 'Failed to get appointments', details: error.message });
  }
});

// Get patient treatments
router.get('/:id/treatments', async (req, res) => {
  try {
    const [treatments] = await db.query(
      'SELECT * FROM treatments WHERE patient_id = ? ORDER BY treatment_date DESC',
      [req.params.id]
    );

    res.json(treatments);

  } catch (error) {
    console.error('Get patient treatments error:', error);
    res.status(500).json({ error: 'Failed to get treatments', details: error.message });
  }
});

module.exports = router;
