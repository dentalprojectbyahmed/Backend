const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { patient_id } = req.query;
    let query = 'SELECT o.*, p.name as patient_name FROM orthodontics o JOIN patients p ON o.patient_id = p.id WHERE 1=1';
    const params = [];
    if (patient_id) { query += ' AND o.patient_id = ?'; params.push(patient_id); }
    query += ' ORDER BY o.start_date DESC';
    const [cases] = await db.query(query, params);
    res.json(cases);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get orthodontic cases', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patient_id, start_date, total_cost, paid_amount, payment_plan, status, notes } = req.body;
    if (!patient_id || !total_cost) return res.status(400).json({ error: 'Patient and total cost required' });
    const [result] = await db.query(
      'INSERT INTO orthodontics (patient_id, start_date, total_cost, paid_amount, payment_plan, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [patient_id, start_date || new Date(), total_cost, paid_amount || 0, payment_plan, status || 'active', notes]
    );
    res.status(201).json({ message: 'Orthodontic case created', caseId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create orthodontic case', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { total_cost, paid_amount, payment_plan, status, notes, end_date } = req.body;
    const [result] = await db.query(
      'UPDATE orthodontics SET total_cost=?, paid_amount=?, payment_plan=?, status=?, notes=?, end_date=? WHERE id=?',
      [total_cost, paid_amount, payment_plan, status, notes, end_date, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Case not found' });
    res.json({ message: 'Orthodontic case updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update orthodontic case', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM orthodontics WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Case not found' });
    res.json({ message: 'Orthodontic case deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete orthodontic case', details: error.message });
  }
});

module.exports = router;
