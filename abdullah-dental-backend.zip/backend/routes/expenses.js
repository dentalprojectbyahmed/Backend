const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { category, date_from, date_to } = req.query;
    let query = 'SELECT * FROM expenses WHERE 1=1';
    const params = [];
    if (category) { query += ' AND category = ?'; params.push(category); }
    if (date_from) { query += ' AND expense_date >= ?'; params.push(date_from); }
    if (date_to) { query += ' AND expense_date <= ?'; params.push(date_to); }
    query += ' ORDER BY expense_date DESC';
    const [expenses] = await db.query(query, params);
    res.json(expenses);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get expenses', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { expense_date, category, amount, description, payment_method } = req.body;
    if (!amount || !category) return res.status(400).json({ error: 'Amount and category required' });
    const [result] = await db.query(
      'INSERT INTO expenses (expense_date, category, amount, description, payment_method) VALUES (?, ?, ?, ?, ?)',
      [expense_date || new Date(), category, amount, description, payment_method || 'cash']
    );
    res.status(201).json({ message: 'Expense created', expenseId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create expense', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { expense_date, category, amount, description, payment_method } = req.body;
    const [result] = await db.query(
      'UPDATE expenses SET expense_date=?, category=?, amount=?, description=?, payment_method=? WHERE id=?',
      [expense_date, category, amount, description, payment_method, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Expense not found' });
    res.json({ message: 'Expense updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update expense', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM expenses WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Expense not found' });
    res.json({ message: 'Expense deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete expense', details: error.message });
  }
});

module.exports = router;
