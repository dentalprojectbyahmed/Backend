const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { patient_id, status } = req.query;
    let query = 'SELECT l.*, p.name as patient_name FROM lab_work l JOIN patients p ON l.patient_id = p.id WHERE 1=1';
    const params = [];
    if (patient_id) { query += ' AND l.patient_id = ?'; params.push(patient_id); }
    if (status) { query += ' AND l.status = ?'; params.push(status); }
    query += ' ORDER BY l.sent_date DESC';
    const [labWork] = await db.query(query, params);
    res.json(labWork);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get lab work', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patient_id, work_type, lab_name, sent_date, expected_date, cost, status, notes } = req.body;
    if (!patient_id || !work_type) return res.status(400).json({ error: 'Patient and work type required' });
    const [result] = await db.query(
      'INSERT INTO lab_work (patient_id, work_type, lab_name, sent_date, expected_date, cost, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [patient_id, work_type, lab_name, sent_date || new Date(), expected_date, cost, status || 'pending', notes]
    );
    res.status(201).json({ message: 'Lab work created', labWorkId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create lab work', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { work_type, lab_name, expected_date, cost, status, notes, received_date } = req.body;
    const [result] = await db.query(
      'UPDATE lab_work SET work_type=?, lab_name=?, expected_date=?, cost=?, status=?, notes=?, received_date=? WHERE id=?',
      [work_type, lab_name, expected_date, cost, status, notes, received_date, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Lab work not found' });
    res.json({ message: 'Lab work updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update lab work', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM lab_work WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Lab work not found' });
    res.json({ message: 'Lab work deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete lab work', details: error.message });
  }
});

module.exports = router;
