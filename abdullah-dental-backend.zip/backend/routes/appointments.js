const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

// Get all appointments
router.get('/', async (req, res) => {
  try {
    const { date, status, patient_id } = req.query;
    
    let query = `
      SELECT a.*, p.name as patient_name, p.phone as patient_phone
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      WHERE 1=1
    `;
    const params = [];
    
    if (date) {
      query += ' AND a.appointment_date = ?';
      params.push(date);
    }
    
    if (status) {
      query += ' AND a.status = ?';
      params.push(status);
    }
    
    if (patient_id) {
      query += ' AND a.patient_id = ?';
      params.push(patient_id);
    }
    
    query += ' ORDER BY a.appointment_date DESC, a.appointment_time DESC';
    
    const [appointments] = await db.query(query, params);
    res.json(appointments);

  } catch (error) {
    res.status(500).json({ error: 'Failed to get appointments', details: error.message });
  }
});

// Get single appointment
router.get('/:id', async (req, res) => {
  try {
    const [appointments] = await db.query(
      `SELECT a.*, p.name as patient_name, p.phone as patient_phone, p.email as patient_email
       FROM appointments a
       JOIN patients p ON a.patient_id = p.id
       WHERE a.id = ?`,
      [req.params.id]
    );
    
    if (appointments.length === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }
    
    res.json(appointments[0]);

  } catch (error) {
    res.status(500).json({ error: 'Failed to get appointment', details: error.message });
  }
});

// Create appointment
router.post('/', async (req, res) => {
  try {
    const { patient_id, appointment_date, appointment_time, treatment_type, notes, status } = req.body;

    if (!patient_id || !appointment_date || !appointment_time) {
      return res.status(400).json({ error: 'Patient, date, and time are required' });
    }

    const [result] = await db.query(
      `INSERT INTO appointments (patient_id, appointment_date, appointment_time, treatment_type, notes, status)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [patient_id, appointment_date, appointment_time, treatment_type, notes, status || 'scheduled']
    );

    res.status(201).json({
      message: 'Appointment created successfully',
      appointmentId: result.insertId
    });

  } catch (error) {
    res.status(500).json({ error: 'Failed to create appointment', details: error.message });
  }
});

// Update appointment
router.put('/:id', async (req, res) => {
  try {
    const { appointment_date, appointment_time, treatment_type, notes, status } = req.body;

    const [result] = await db.query(
      `UPDATE appointments SET appointment_date = ?, appointment_time = ?, treatment_type = ?, notes = ?, status = ?
       WHERE id = ?`,
      [appointment_date, appointment_time, treatment_type, notes, status, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({ message: 'Appointment updated successfully' });

  } catch (error) {
    res.status(500).json({ error: 'Failed to update appointment', details: error.message });
  }
});

// Delete appointment
router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM appointments WHERE id = ?', [req.params.id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    res.json({ message: 'Appointment deleted successfully' });

  } catch (error) {
    res.status(500).json({ error: 'Failed to delete appointment', details: error.message });
  }
});

// Get available time slots for a date
router.get('/available-slots/:date', async (req, res) => {
  try {
    const [appointments] = await db.query(
      'SELECT appointment_time FROM appointments WHERE appointment_date = ? AND status != ?',
      [req.params.date, 'cancelled']
    );
    
    // Clinic hours: 9 AM to 8 PM
    const allSlots = [];
    for (let hour = 9; hour <= 20; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        allSlots.push(time);
      }
    }
    
    const bookedTimes = appointments.map(a => a.appointment_time);
    const availableSlots = allSlots.filter(slot => !bookedTimes.includes(slot));
    
    res.json({ availableSlots });

  } catch (error) {
    res.status(500).json({ error: 'Failed to get available slots', details: error.message });
  }
});

module.exports = router;
