# Abdullah Dental Care - Backend API

Complete Node.js + Express + MySQL2 backend for dental clinic management.

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd backend
npm install
```

### 2. Setup Database
```bash
# Create database
mysql -u root -p < database/schema.sql

# Or manually:
mysql -u root -p
source database/schema.sql
```

### 3. Configure Environment
```bash
# Edit .env file
nano .env

# Update these values:
DB_PASSWORD=your_mysql_password
JWT_SECRET=your_secure_secret_key
```

### 4. Run Server
```bash
# Development
npm run dev

# Production
npm start
```

Server runs on http://localhost:5000

## 📡 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login
- `GET /api/auth/me` - Get current user
- `POST /api/auth/logout` - Logout

### Patients
- `GET /api/patients` - Get all patients
- `GET /api/patients/:id` - Get single patient
- `POST /api/patients` - Create patient
- `PUT /api/patients/:id` - Update patient
- `DELETE /api/patients/:id` - Delete patient

### Appointments
- `GET /api/appointments` - Get all appointments
- `POST /api/appointments` - Create appointment
- `PUT /api/appointments/:id` - Update appointment
- `DELETE /api/appointments/:id` - Delete appointment

### Treatments, Prescriptions, Billing, Lab Work, Inventory, Expenses, Orthodontics
- Similar CRUD operations for each module

### Reports
- `GET /api/reports/revenue` - Revenue report
- `GET /api/reports/expenses-summary` - Expenses by category
- `GET /api/reports/dashboard-stats` - Dashboard statistics

## 🔐 Authentication

All endpoints except `/api/auth/login` and `/api/auth/register` require JWT token:

```javascript
headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN'
}
```

## 👤 Default Users

Username: `admin` / Password: `admin123`
Username: `naveed` / Password: `admin123`

**⚠️ Change passwords after first login!**

## 🏥 Clinic Information

- **Name:** Abdullah Dental Care
- **Doctor:** Dr. Ahmed Abdullah Khan (BDS, MPH, PMC 7071-D)
- **Location:** Hayatabad, Peshawar, Pakistan
- **Currency:** PKR (Pakistani Rupee)

## 📞 Support

For issues or questions, contact: ahmedakg@gmail.com
