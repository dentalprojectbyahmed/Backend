const pool = require('./db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') return res.status(200).end();
  
  try {
    if (req.method === 'GET') {
      const { patientId } = req.query;
      let query = 'SELECT * FROM treatments';
      let params = [];
      
      if (patientId) {
        query += ' WHERE patient_id = ?';
        params = [patientId];
      }
      
      query += ' ORDER BY date DESC';
      const [treatments] = await pool.query(query, params);
      return res.json({ success: true, data: treatments });
    }
    
    if (req.method === 'POST') {
      const { patient_id, patient_name, date, items, teeth, total, discount, paid } = req.body;
      const balance = total - (discount || 0) - (paid || 0);
      const status = balance > 0 ? 'Partial' : 'Paid';
      
      const [result] = await pool.query(
        'INSERT INTO treatments (patient_id, patient_name, date, items, teeth, total, discount, paid, balance, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [patient_id, patient_name, date, JSON.stringify(items), JSON.stringify(teeth || []), total, discount || 0, paid || 0, balance, status]
      );
      
      // Update patient outstanding balance
      await pool.query(
        'UPDATE patients SET outstanding_balance = outstanding_balance + ? WHERE id = ?',
        [balance, patient_id]
      );
      
      const [treatment] = await pool.query('SELECT * FROM treatments WHERE id = ?', [result.insertId]);
      return res.status(201).json({ success: true, data: treatment[0] });
    }
    
  } catch (error) {
    console.error('Treatments API error:', error);
    return res.status(500).json({ error: error.message });
  }
};
