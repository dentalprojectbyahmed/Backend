const pool = require('./db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') return res.status(200).end();
  
  try {
    if (req.method === 'GET') {
      const { startDate, endDate } = req.query;
      let query = 'SELECT * FROM appointments';
      let params = [];
      
      if (startDate && endDate) {
        query += ' WHERE date BETWEEN ? AND ?';
        params = [startDate, endDate];
      }
      
      query += ' ORDER BY date DESC, time DESC';
      const [appointments] = await pool.query(query, params);
      return res.json({ success: true, data: appointments });
    }
    
    if (req.method === 'POST') {
      const { patient_id, patient_name, phone, date, time, type, status, notes } = req.body;
      const [result] = await pool.query(
        'INSERT INTO appointments (patient_id, patient_name, phone, date, time, type, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [patient_id, patient_name, phone, date, time, type || 'General', status || 'Scheduled', notes]
      );
      
      const [appointment] = await pool.query('SELECT * FROM appointments WHERE id = ?', [result.insertId]);
      return res.status(201).json({ success: true, data: appointment[0] });
    }
    
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = [...Object.values(updates), id];
      
      await pool.query(`UPDATE appointments SET ${fields} WHERE id = ?`, values);
      const [appointment] = await pool.query('SELECT * FROM appointments WHERE id = ?', [id]);
      return res.json({ success: true, data: appointment[0] });
    }
    
  } catch (error) {
    console.error('Appointments API error:', error);
    return res.status(500).json({ error: error.message });
  }
};
