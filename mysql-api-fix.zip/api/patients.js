const pool = require('./db');

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') return res.status(200).end();
  
  try {
    if (req.method === 'GET') {
      const [patients] = await pool.query('SELECT * FROM patients ORDER BY created_at DESC');
      return res.json({ success: true, data: patients });
    }
    
    if (req.method === 'POST') {
      const { name, phone, age, gender, address, behavior_tag, medical_history, allergies } = req.body;
      const [result] = await pool.query(
        'INSERT INTO patients (name, phone, age, gender, address, behavior_tag, medical_history, allergies) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [name, phone, age, gender, address, behavior_tag || 'Regular', JSON.stringify(medical_history || {}), allergies]
      );
      
      const [patient] = await pool.query('SELECT * FROM patients WHERE id = ?', [result.insertId]);
      return res.status(201).json({ success: true, data: patient[0] });
    }
    
    if (req.method === 'PUT') {
      const { id, ...updates } = req.body;
      const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = [...Object.values(updates), id];
      
      await pool.query(`UPDATE patients SET ${fields} WHERE id = ?`, values);
      const [patient] = await pool.query('SELECT * FROM patients WHERE id = ?', [id]);
      return res.json({ success: true, data: patient[0] });
    }
    
    if (req.method === 'DELETE') {
      await pool.query('DELETE FROM patients WHERE id = ?', [req.query.id]);
      return res.json({ success: true });
    }
    
  } catch (error) {
    console.error('Patients API error:', error);
    return res.status(500).json({ error: error.message });
  }
};
