
export function Dialog({ open, onClose, children }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4">
      <div className="bg-[var(--card)] text-[var(--card-foreground)] rounded-[var(--radius-lg)] p-6 shadow-lg">
        {children}
        <button onClick={onClose} className="mt-4 bg-[var(--accent)] text-[var(--accent-foreground)] px-4 py-2 rounded-[var(--radius)]">
          Close
        </button>
      </div>
    </div>
  );
}
