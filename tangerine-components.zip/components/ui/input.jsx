
export function Input({ ...props }) {
  return (
    <input
      className="w-full border border-[var(--input)] rounded-[var(--radius)] px-3 py-2 bg-[var(--background)] text-[var(--foreground)] shadow-xs focus:ring-2 focus:ring-[var(--ring)]"
      {...props}
    />
  );
}
