
export function Sidebar({ children }) {
  return (
    <aside className="w-64 bg-[var(--sidebar)] text-[var(--sidebar-foreground)] border-r border-[var(--sidebar-border)] p-4">
      {children}
    </aside>
  );
}
