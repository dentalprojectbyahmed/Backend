
export function Card({ children }) {
  return (
    <div className="bg-[var(--card)] text-[var(--card-foreground)] rounded-[var(--radius-lg)] p-4 shadow">
      {children}
    </div>
  );
}
