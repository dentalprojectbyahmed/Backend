
export function Button({ children, variant="primary", ...props }) {
  const classes = {
    primary: "bg-[var(--primary)] text-[var(--primary-foreground)] rounded-[var(--radius)] px-4 py-2 shadow-sm",
    secondary: "bg-[var(--secondary)] text-[var(--secondary-foreground)] rounded-[var(--radius)] px-4 py-2 shadow-sm",
    outline: "border border-[var(--border)] text-[var(--foreground)] rounded-[var(--radius)] px-4 py-2"
  };
  return <button className={classes[variant]} {...props}>{children}</button>;
}
