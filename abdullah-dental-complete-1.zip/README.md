# Abdullah Dental Care - Complete Management System

## Quick Start

### 1. Install MySQL and Node.js
```bash
# Install MySQL 8.0
# Install Node.js 18+
```

### 2. Setup Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env: add your MySQL password

# Import database
mysql -u root -p < database/schema.sql
# Password creates: admin/admin123 and naveed/admin123

# Start server
npm start
```

### 3. Setup Frontend
```bash
cd frontend
npm install
npm start
# Opens http://localhost:3000
```

## Login
- **Username:** admin
- **Password:** admin123

## Features
✓ 8 Modules: Patients, Appointments, Treatments, Prescriptions, Lab Work, Expenses, Orthodontics, Reports
✓ 70 Treatment Templates (all dental procedures)
✓ 35 Prescription Protocols (Pakistani medicines)
✓ PKR currency, +92 phone format
✓ JazzCash/EasyPaisa payment methods
✓ Patient gamification (badges/points)
✓ 6-month recall automation
✓ 50-50 ortho payment splits
✓ Free forever (your own MySQL server)

## Tech Stack
- Backend: Node.js + Express + MySQL2
- Frontend: React (pure JavaScript)
- Auth: JWT tokens
- Free & open for Abdullah Dental Care

## Production Deployment
```bash
# Backend with PM2
cd backend
npm install --production
pm2 start server.js --name dental-api

# Frontend build
cd frontend
npm run build
# Deploy build/ folder to web server
```

## Clinic Info
**Abdullah Dental Care**
Dr. Ahmed Abdullah Khan (BDS, MPH, PMC 7071-D)
Hayatabad, Peshawar, Pakistan
