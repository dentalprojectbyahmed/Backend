import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const api = axios.create({ baseURL: API_URL, headers: { 'Content-Type': 'application/json' } });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const login = (username, password) => api.post('/auth/login', { username, password });
export const getPatients = () => api.get('/patients');
export const getPatient = (id) => api.get(`/patients/${id}`);
export const createPatient = (data) => api.post('/patients', data);
export const updatePatient = (id, data) => api.put(`/patients/${id}`, data);
export const deletePatient = (id) => api.delete(`/patients/${id}`);
export const getRecallsDue = () => api.get('/patients/recalls/due');
export const getAppointments = (params) => api.get('/appointments', { params });
export const getTodayAppointments = () => api.get('/appointments/today');
export const createAppointment = (data) => api.post('/appointments', data);
export const updateAppointment = (id, data) => api.put(`/appointments/${id}`, data);
export const deleteAppointment = (id) => api.delete(`/appointments/${id}`);
export const getTreatments = (params) => api.get('/treatments', { params });
export const createTreatment = (data) => api.post('/treatments', data);
export const updateTreatment = (id, data) => api.put(`/treatments/${id}`, data);
export const deleteTreatment = (id) => api.delete(`/treatments/${id}`);
export const getPrescriptions = (params) => api.get('/prescriptions', { params });
export const createPrescription = (data) => api.post('/prescriptions', data);
export const deletePrescription = (id) => api.delete(`/prescriptions/${id}`);
export const getLabWork = (params) => api.get('/lab-work', { params });
export const createLabWork = (data) => api.post('/lab-work', data);
export const updateLabWork = (id, data) => api.put(`/lab-work/${id}`, data);
export const deleteLabWork = (id) => api.delete(`/lab-work/${id}`);
export const getExpenses = (params) => api.get('/expenses', { params });
export const createExpense = (data) => api.post('/expenses', data);
export const updateExpense = (id, data) => api.put(`/expenses/${id}`, data);
export const deleteExpense = (id) => api.delete(`/expenses/${id}`);
export const getOrthodontics = (params) => api.get('/orthodontics', { params });
export const createOrthoCase = (data) => api.post('/orthodontics', data);
export const updateOrthoCase = (id, data) => api.put(`/orthodontics/${id}`, data);
export const getOrthoPayments = (id) => api.get(`/orthodontics/${id}/payments`);
export const addOrthoPayment = (id, data) => api.post(`/orthodontics/${id}/payments`, data);
export const getOrthoVisits = (id) => api.get(`/orthodontics/${id}/visits`);
export const addOrthoVisit = (id, data) => api.post(`/orthodontics/${id}/visits`, data);
export const getTreatmentTemplates = (params) => api.get('/treatment-templates', { params });
export const getPrescriptionProtocols = () => api.get('/prescription-protocols');
export const getDashboardStats = () => api.get('/dashboard/stats');
export const getRevenueReport = (params) => api.get('/reports/revenue', { params });
export const getExpensesReport = (params) => api.get('/reports/expenses', { params });
export const getTreatmentsReport = (params) => api.get('/reports/treatments', { params });
export const getPayments = (params) => api.get('/payments', { params });
export const createPayment = (data) => api.post('/payments', data);

export default api;
