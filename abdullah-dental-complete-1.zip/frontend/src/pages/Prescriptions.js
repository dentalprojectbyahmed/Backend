import React, { useState, useEffect } from 'react';
import { getPrescriptions, createPrescription, getPatients, getPrescriptionProtocols } from '../services/api';

function Prescriptions() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [patients, setPatients] = useState([]);
  const [protocols, setProtocols] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    patient_id: '', prescription_date: new Date().toISOString().split('T')[0],
    protocol_name: '', medicines: '', instructions: '', duration_days: '5'
  });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [presRes, patientsRes, protocolsRes] = await Promise.all([
        getPrescriptions(),
        getPatients(),
        getPrescriptionProtocols()
      ]);
      setPrescriptions(presRes.data);
      setPatients(patientsRes.data);
      setProtocols(protocolsRes.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleProtocolSelect = (e) => {
    const protocol = protocols.find(p => p.id === parseInt(e.target.value));
    if (protocol) {
      setFormData({
        ...formData,
        protocol_name: protocol.protocol_name,
        medicines: protocol.medicines,
        instructions: protocol.instructions,
        duration_days: protocol.duration_days || '5'
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createPrescription(formData);
      loadData();
      setShowForm(false);
    } catch (error) {
      alert('Error creating prescription');
    }
  };

  return (
    <div>
      <div className="page-header flex-between">
        <h1>Prescriptions</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">+ New Rx</button>
      </div>
      <div className="table-container">
        <table>
          <thead>
            <tr><th>Date</th><th>Patient</th><th>Protocol</th><th>Duration</th><th>Medicines</th></tr>
          </thead>
          <tbody>
            {prescriptions.map(p => (
              <tr key={p.id}>
                <td>{new Date(p.prescription_date).toLocaleDateString()}</td>
                <td>{p.full_name}</td>
                <td>{p.protocol_name || 'Custom'}</td>
                <td>{p.duration_days} days</td>
                <td><pre style={{fontSize: '12px', margin: 0}}>{p.medicines}</pre></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>New Prescription</h2>
              <button onClick={() => setShowForm(false)} className="close-btn">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Patient *</label>
                <select required value={formData.patient_id} onChange={e => setFormData({...formData, patient_id: e.target.value})}>
                  <option value="">Select</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Protocol (35 Pakistani Protocols)</label>
                <select onChange={handleProtocolSelect}>
                  <option value="">-- Select Protocol or Write Custom --</option>
                  {protocols.map(p => <option key={p.id} value={p.id}>{p.protocol_name} - {p.indication}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Medicines *</label>
                <textarea required rows="6" value={formData.medicines} onChange={e => setFormData({...formData, medicines: e.target.value})} placeholder="Cap Amoxicillin 500mg TDS&#10;Tab Brufen 400mg TDS&#10;Tab Flagyl 400mg TDS" />
              </div>
              <div className="form-group">
                <label>Instructions</label>
                <textarea rows="3" value={formData.instructions} onChange={e => setFormData({...formData, instructions: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Duration (Days)</label>
                <input type="number" value={formData.duration_days} onChange={e => setFormData({...formData, duration_days: e.target.value})} />
              </div>
              <button type="submit" className="btn btn-primary">Save Prescription</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Prescriptions;