import React, { useState, useEffect } from 'react';
import { getPatients, createPatient, updatePatient, deletePatient, getRecallsDue } from '../services/api';

function Patients() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    full_name: '', father_name: '', age: '', gender: 'male',
    phone: '', cnic: '', address: '', medical_history: '', allergies: ''
  });

  useEffect(() => { loadPatients(); }, []);

  const loadPatients = async () => {
    try {
      const response = await getPatients();
      setPatients(response.data);
    } catch (error) {
      alert('Error loading patients');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updatePatient(editingId, formData);
      } else {
        await createPatient(formData);
      }
      loadPatients();
      resetForm();
    } catch (error) {
      alert('Error saving patient');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this patient?')) {
      try {
        await deletePatient(id);
        loadPatients();
      } catch (error) {
        alert('Error deleting patient');
      }
    }
  };

  const handleEdit = (patient) => {
    setFormData({
      full_name: patient.full_name,
      father_name: patient.father_name || '',
      age: patient.age || '',
      gender: patient.gender,
      phone: patient.phone,
      cnic: patient.cnic || '',
      address: patient.address || '',
      medical_history: patient.medical_history || '',
      allergies: patient.allergies || ''
    });
    setEditingId(patient.id);
    setShowForm(true);
  };

  const resetForm = () => {
    setFormData({
      full_name: '', father_name: '', age: '', gender: 'male',
      phone: '', cnic: '', address: '', medical_history: '', allergies: ''
    });
    setEditingId(null);
    setShowForm(false);
  };

  const filteredPatients = patients.filter(p => 
    p.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.mr_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.phone.includes(searchTerm)
  );

  const getBadgeClass = (badge) => {
    if (badge?.includes('Platinum')) return 'badge-platinum';
    if (badge?.includes('Gold')) return 'badge-gold';
    if (badge?.includes('Silver')) return 'badge-silver';
    if (badge?.includes('Bronze')) return 'badge-bronze';
    return 'badge-info';
  };

  if (loading) return <div className="loading">Loading patients...</div>;

  return (
    <div>
      <div className="page-header flex-between">
        <div>
          <h1>Patients</h1>
          <p>Total: {patients.length} patients</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">
          + Add Patient
        </button>
      </div>

      <div style={{marginBottom: '20px'}}>
        <input
          type="text"
          placeholder="Search by name, MR number, or phone..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{padding: '10px', width: '400px', borderRadius: '5px', border: '1px solid #ddd'}}
        />
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>MR Number</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Age/Gender</th>
              <th>Last Visit</th>
              <th>Badge</th>
              <th>Points</th>
              <th>Balance</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredPatients.map(patient => (
              <tr key={patient.id}>
                <td><strong>{patient.mr_number}</strong></td>
                <td>{patient.full_name}</td>
                <td>{patient.phone}</td>
                <td>{patient.age}/{patient.gender}</td>
                <td>{patient.last_visit ? new Date(patient.last_visit).toLocaleDateString() : 'N/A'}</td>
                <td><span className={`badge ${getBadgeClass(patient.badge)}`}>{patient.badge}</span></td>
                <td>{patient.points}</td>
                <td>PKR {patient.total_balance || 0}</td>
                <td>
                  <button onClick={() => handleEdit(patient)} className="btn btn-secondary" style={{marginRight: '5px'}}>Edit</button>
                  <button onClick={() => handleDelete(patient.id)} className="btn btn-danger">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={() => resetForm()}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{editingId ? 'Edit Patient' : 'Add New Patient'}</h2>
              <button onClick={resetForm} className="close-btn">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="grid-2">
                <div className="form-group">
                  <label>Full Name *</label>
                  <input required value={formData.full_name} onChange={(e) => setFormData({...formData, full_name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Father Name</label>
                  <input value={formData.father_name} onChange={(e) => setFormData({...formData, father_name: e.target.value})} />
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Age</label>
                  <input type="number" value={formData.age} onChange={(e) => setFormData({...formData, age: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Gender *</label>
                  <select required value={formData.gender} onChange={(e) => setFormData({...formData, gender: e.target.value})}>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Phone *</label>
                  <input required placeholder="+92-300-0000000" value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>CNIC</label>
                  <input placeholder="12345-1234567-1" value={formData.cnic} onChange={(e) => setFormData({...formData, cnic: e.target.value})} />
                </div>
              </div>
              <div className="form-group">
                <label>Address</label>
                <textarea rows="2" value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Medical History</label>
                <textarea rows="2" value={formData.medical_history} onChange={(e) => setFormData({...formData, medical_history: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Allergies</label>
                <input value={formData.allergies} onChange={(e) => setFormData({...formData, allergies: e.target.value})} />
              </div>
              <div className="flex gap-2">
                <button type="submit" className="btn btn-primary">Save Patient</button>
                <button type="button" onClick={resetForm} className="btn btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Patients;