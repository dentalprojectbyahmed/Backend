import React, { useState, useEffect } from 'react';
import { getRevenueReport, getExpensesReport } from '../services/api';

function Reports() {
  const [revenue, setRevenue] = useState(null);
  const [expenses, setExpenses] = useState(null);
  const [startDate, setStartDate] = useState(new Date(new Date().setDate(1)).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => { loadReports(); }, [startDate, endDate]);

  const loadReports = async () => {
    try {
      const [revRes, expRes] = await Promise.all([
        getRevenueReport({ start_date: startDate, end_date: endDate }),
        getExpensesReport({ start_date: startDate, end_date: endDate })
      ]);
      setRevenue(revRes.data);
      setExpenses(expRes.data);
    } catch (error) {
      console.error(error);
    }
  };

  const profit = (revenue?.grand_total || 0) - (expenses?.grand_total || 0);

  return (
    <div>
      <div className="page-header">
        <h1>Reports & Analytics</h1>
      </div>
      <div className="grid-2" style={{marginBottom: '20px'}}>
        <div className="form-group">
          <label>From</label>
          <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
        </div>
        <div className="form-group">
          <label>To</label>
          <input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
        </div>
      </div>
      <div className="stats-grid" style={{gridTemplateColumns: 'repeat(3, 1fr)'}}>
        <div className="stat-card">
          <div className="stat-label">Total Revenue</div>
          <div className="stat-value" style={{color: '#27ae60'}}>PKR {revenue?.grand_total?.toLocaleString() || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Expenses</div>
          <div className="stat-value" style={{color: '#e74c3c'}}>PKR {expenses?.grand_total?.toLocaleString() || 0}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Net Profit</div>
          <div className="stat-value" style={{color: profit >= 0 ? '#27ae60' : '#e74c3c'}}>PKR {profit.toLocaleString()}</div>
        </div>
      </div>
      <div className="grid-2">
        <div className="table-container">
          <h3 style={{padding: '15px'}}>Revenue by Payment Method</h3>
          <table>
            <thead>
              <tr><th>Method</th><th>Count</th><th>Amount</th></tr>
            </thead>
            <tbody>
              {revenue?.summary?.map((s, i) => (
                <tr key={i}>
                  <td>{s.payment_method}</td>
                  <td>{s.count}</td>
                  <td>PKR {s.total?.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="table-container">
          <h3 style={{padding: '15px'}}>Expenses by Category</h3>
          <table>
            <thead>
              <tr><th>Category</th><th>Count</th><th>Amount</th></tr>
            </thead>
            <tbody>
              {expenses?.by_category?.map((e, i) => (
                <tr key={i}>
                  <td>{e.category}</td>
                  <td>{e.count}</td>
                  <td>PKR {e.total?.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Reports;