import React, { useState, useEffect } from 'react';
import { getAppointments, getTodayAppointments, createAppointment, updateAppointment, getPatients } from '../services/api';

function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [formData, setFormData] = useState({
    patient_id: '', appointment_date: new Date().toISOString().split('T')[0],
    appointment_time: '09:00', duration: '30', treatment_type: '', notes: '', status: 'scheduled'
  });

  useEffect(() => { loadData(); }, [selectedDate]);

  const loadData = async () => {
    try {
      const [apptsRes, patientsRes] = await Promise.all([
        getAppointments({ date: selectedDate }),
        getPatients()
      ]);
      setAppointments(apptsRes.data);
      setPatients(patientsRes.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createAppointment(formData);
      loadData();
      setShowForm(false);
    } catch (error) {
      alert('Error creating appointment');
    }
  };

  const updateStatus = async (id, status) => {
    try {
      await updateAppointment(id, { status });
      loadData();
    } catch (error) {
      alert('Error updating status');
    }
  };

  const getStatusBadge = (status) => {
    const badges = {
      scheduled: 'badge-info', confirmed: 'badge-success',
      completed: 'badge-success', cancelled: 'badge-danger', 'no-show': 'badge-warning'
    };
    return badges[status] || 'badge-info';
  };

  return (
    <div>
      <div className="page-header flex-between">
        <h1>Appointments</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">+ Schedule</button>
      </div>
      <div style={{marginBottom: '20px'}}>
        <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} style={{padding: '10px', fontSize: '16px'}} />
      </div>
      <div className="table-container">
        <table>
          <thead>
            <tr><th>Time</th><th>Patient</th><th>Phone</th><th>Treatment</th><th>Duration</th><th>Status</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {appointments.map(a => (
              <tr key={a.id}>
                <td><strong>{a.appointment_time}</strong></td>
                <td>{a.full_name}</td>
                <td>{a.phone}</td>
                <td>{a.treatment_type || 'General'}</td>
                <td>{a.duration} min</td>
                <td><span className={`badge ${getStatusBadge(a.status)}`}>{a.status}</span></td>
                <td>
                  <select value={a.status} onChange={(e) => updateStatus(a.id, e.target.value)} style={{padding: '5px'}}>
                    <option value="scheduled">Scheduled</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                    <option value="no-show">No-show</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Schedule Appointment</h2>
              <button onClick={() => setShowForm(false)} className="close-btn">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Patient *</label>
                <select required value={formData.patient_id} onChange={e => setFormData({...formData, patient_id: e.target.value})}>
                  <option value="">Select</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.mr_number} - {p.full_name}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Date *</label>
                  <input type="date" required value={formData.appointment_date} onChange={e => setFormData({...formData, appointment_date: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Time *</label>
                  <input type="time" required value={formData.appointment_time} onChange={e => setFormData({...formData, appointment_time: e.target.value})} />
                </div>
              </div>
              <div className="form-group">
                <label>Treatment Type</label>
                <input value={formData.treatment_type} onChange={e => setFormData({...formData, treatment_type: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Notes</label>
                <textarea rows="2" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} />
              </div>
              <button type="submit" className="btn btn-primary">Schedule</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Appointments;