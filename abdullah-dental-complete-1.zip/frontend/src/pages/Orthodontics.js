import React, { useState, useEffect } from 'react';
import { getOrthodontics, createOrthoCase, getPatients } from '../services/api';

function Orthodontics() {
  const [cases, setCases] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    patient_id: '', start_date: new Date().toISOString().split('T')[0],
    case_type: 'Fixed Braces', appliance_type: 'Metal', total_cost: '80000', deposit: '40000'
  });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [casesRes, patientsRes] = await Promise.all([getOrthodontics(), getPatients()]);
      setCases(casesRes.data);
      setPatients(patientsRes.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createOrthoCase(formData);
      loadData();
      setShowForm(false);
    } catch (error) {
      alert('Error');
    }
  };

  return (
    <div>
      <div className="page-header flex-between">
        <h1>Orthodontics</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">+ New Case</button>
      </div>
      <div className="table-container">
        <table>
          <thead>
            <tr><th>Patient</th><th>Type</th><th>Appliance</th><th>Start</th><th>Total Cost</th><th>Paid</th><th>Balance</th><th>Status</th></tr>
          </thead>
          <tbody>
            {cases.map(c => (
              <tr key={c.id}>
                <td>{c.full_name}</td>
                <td>{c.case_type}</td>
                <td>{c.appliance_type}</td>
                <td>{new Date(c.start_date).toLocaleDateString()}</td>
                <td>PKR {c.total_cost}</td>
                <td>PKR {c.deposit}</td>
                <td>PKR {c.balance}</td>
                <td><span className={`badge badge-${c.status === 'active' ? 'success' : 'warning'}`}>{c.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h2>New Orthodontic Case</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Patient *</label>
                <select required value={formData.patient_id} onChange={e => setFormData({...formData, patient_id: e.target.value})}>
                  <option value="">Select</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Case Type *</label>
                  <select required value={formData.case_type} onChange={e => setFormData({...formData, case_type: e.target.value})}>
                    <option value="Fixed Braces">Fixed Braces</option>
                    <option value="Removable">Removable</option>
                    <option value="Clear Aligners">Clear Aligners</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Appliance *</label>
                  <select required value={formData.appliance_type} onChange={e => setFormData({...formData, appliance_type: e.target.value})}>
                    <option value="Metal">Metal</option>
                    <option value="Ceramic">Ceramic</option>
                    <option value="Lingual">Lingual</option>
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Total Cost (PKR) *</label>
                  <input type="number" required value={formData.total_cost} onChange={e => setFormData({...formData, total_cost: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Initial Deposit (50%) *</label>
                  <input type="number" required value={formData.deposit} onChange={e => setFormData({...formData, deposit: e.target.value})} />
                </div>
              </div>
              <button type="submit" className="btn btn-primary">Start Case</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Orthodontics;