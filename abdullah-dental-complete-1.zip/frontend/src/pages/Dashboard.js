import React, { useState, useEffect } from 'react';
import { getDashboardStats } from '../services/api';

function Dashboard() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const response = await getDashboardStats();
      setStats(response.data);
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="loading">Loading dashboard...</div>;
  if (!stats) return <div>No data available</div>;

  return (
    <div>
      <div className="page-header">
        <h1>Dashboard</h1>
        <p>Overview of Abdullah Dental Care</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Today Appointments</div>
          <div className="stat-value">{stats.today_appointments}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Patients</div>
          <div className="stat-value">{stats.total_patients}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Month Revenue</div>
          <div className="stat-value">PKR {stats.month_revenue?.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Pending Payments</div>
          <div className="stat-value">PKR {stats.pending_payments?.toLocaleString()}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Recalls Due</div>
          <div className="stat-value">{stats.recalls_due}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Active Ortho Cases</div>
          <div className="stat-value">{stats.active_ortho_cases}</div>
        </div>
      </div>

      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px'}}>
        <div className="table-container">
          <h3 style={{padding: '15px'}}>Recent Treatments</h3>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Patient</th>
                <th>Treatment</th>
                <th>Cost</th>
              </tr>
            </thead>
            <tbody>
              {stats.recent_treatments?.slice(0, 5).map(t => (
                <tr key={t.id}>
                  <td>{new Date(t.treatment_date).toLocaleDateString()}</td>
                  <td>{t.full_name}</td>
                  <td>{t.treatment_name}</td>
                  <td>PKR {t.cost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="table-container">
          <h3 style={{padding: '15px'}}>Upcoming Appointments</h3>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Time</th>
                <th>Patient</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {stats.upcoming_appointments?.slice(0, 5).map(a => (
                <tr key={a.id}>
                  <td>{new Date(a.appointment_date).toLocaleDateString()}</td>
                  <td>{a.appointment_time}</td>
                  <td>{a.full_name}</td>
                  <td><span className="badge badge-info">{a.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;