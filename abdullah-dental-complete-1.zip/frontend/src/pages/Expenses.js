import React, { useState, useEffect } from 'react';
import { getExpenses, createExpense } from '../services/api';

function Expenses() {
  const [expenses, setExpenses] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    expense_date: new Date().toISOString().split('T')[0], category: 'Supplies',
    description: '', amount: '', payment_method: 'cash', vendor_name: ''
  });

  useEffect(() => { loadExpenses(); }, []);

  const loadExpenses = async () => {
    try {
      const res = await getExpenses();
      setExpenses(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createExpense(formData);
      loadExpenses();
      setShowForm(false);
    } catch (error) {
      alert('Error');
    }
  };

  const total = expenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);

  return (
    <div>
      <div className="page-header flex-between">
        <div>
          <h1>Expenses</h1>
          <p>Total: PKR {total.toLocaleString()}</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">+ Add Expense</button>
      </div>
      <div className="table-container">
        <table>
          <thead>
            <tr><th>Date</th><th>Category</th><th>Description</th><th>Vendor</th><th>Amount</th><th>Method</th></tr>
          </thead>
          <tbody>
            {expenses.map(e => (
              <tr key={e.id}>
                <td>{new Date(e.expense_date).toLocaleDateString()}</td>
                <td>{e.category}</td>
                <td>{e.description}</td>
                <td>{e.vendor_name || '-'}</td>
                <td>PKR {e.amount}</td>
                <td>{e.payment_method}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h2>New Expense</h2>
            <form onSubmit={handleSubmit}>
              <div className="grid-2">
                <div className="form-group">
                  <label>Date *</label>
                  <input type="date" required value={formData.expense_date} onChange={e => setFormData({...formData, expense_date: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Category *</label>
                  <select required value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>
                    <option value="Supplies">Supplies</option>
                    <option value="Equipment">Equipment</option>
                    <option value="Salary">Salary</option>
                    <option value="Rent">Rent</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label>Description *</label>
                <input required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Amount (PKR) *</label>
                  <input type="number" required value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Payment Method *</label>
                  <select required value={formData.payment_method} onChange={e => setFormData({...formData, payment_method: e.target.value})}>
                    <option value="cash">Cash</option>
                    <option value="bank">Bank Transfer</option>
                    <option value="jazzcash">JazzCash</option>
                    <option value="easypaisa">EasyPaisa</option>
                    <option value="card">Card</option>
                  </select>
                </div>
              </div>
              <button type="submit" className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Expenses;