import React, { useState, useEffect } from 'react';
import { getTreatments, createTreatment, getPatients, getTreatmentTemplates } from '../services/api';

function Treatments() {
  const [treatments, setTreatments] = useState([]);
  const [patients, setPatients] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    patient_id: '', treatment_date: new Date().toISOString().split('T')[0],
    tooth_number: '', treatment_name: '', treatment_category: 'Restorative',
    chief_complaint: '', diagnosis: '', procedure_done: '',
    cost: '', discount: '0', amount_paid: '0', notes: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [treatmentsRes, patientsRes, templatesRes] = await Promise.all([
        getTreatments(),
        getPatients(),
        getTreatmentTemplates()
      ]);
      setTreatments(treatmentsRes.data);
      setPatients(patientsRes.data);
      setTemplates(templatesRes.data);
    } catch (error) {
      alert('Error loading data');
    }
  };

  const handleTemplateSelect = (e) => {
    const template = templates.find(t => t.id === parseInt(e.target.value));
    if (template) {
      setFormData({
        ...formData,
        treatment_name: template.name,
        treatment_category: template.category,
        cost: template.default_cost
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createTreatment(formData);
      loadData();
      setShowForm(false);
      setFormData({
        patient_id: '', treatment_date: new Date().toISOString().split('T')[0],
        tooth_number: '', treatment_name: '', treatment_category: 'Restorative',
        chief_complaint: '', diagnosis: '', procedure_done: '',
        cost: '', discount: '0', amount_paid: '0', notes: ''
      });
    } catch (error) {
      alert('Error saving treatment');
    }
  };

  const getPaymentBadge = (status) => {
    if (status === 'paid') return 'badge-success';
    if (status === 'partial') return 'badge-warning';
    return 'badge-danger';
  };

  return (
    <div>
      <div className="page-header flex-between">
        <div>
          <h1>Treatments</h1>
          <p>Total: {treatments.length} treatments</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">
          + Add Treatment
        </button>
      </div>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Patient</th>
              <th>MR#</th>
              <th>Treatment</th>
              <th>Tooth</th>
              <th>Cost</th>
              <th>Paid</th>
              <th>Balance</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {treatments.map(t => (
              <tr key={t.id}>
                <td>{new Date(t.treatment_date).toLocaleDateString()}</td>
                <td>{t.full_name}</td>
                <td>{t.mr_number}</td>
                <td>{t.treatment_name}</td>
                <td>{t.tooth_number || '-'}</td>
                <td>PKR {t.cost}</td>
                <td>PKR {t.amount_paid}</td>
                <td>PKR {t.balance}</td>
                <td><span className={`badge ${getPaymentBadge(t.payment_status)}`}>{t.payment_status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{maxWidth: '800px'}}>
            <div className="modal-header">
              <h2>Add Treatment</h2>
              <button onClick={() => setShowForm(false)} className="close-btn">&times;</button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="grid-2">
                <div className="form-group">
                  <label>Patient *</label>
                  <select required value={formData.patient_id} onChange={(e) => setFormData({...formData, patient_id: e.target.value})}>
                    <option value="">Select Patient</option>
                    {patients.map(p => (
                      <option key={p.id} value={p.id}>{p.mr_number} - {p.full_name}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Date *</label>
                  <input type="date" required value={formData.treatment_date} onChange={(e) => setFormData({...formData, treatment_date: e.target.value})} />
                </div>
              </div>
              <div className="form-group">
                <label>Treatment Template</label>
                <select onChange={handleTemplateSelect}>
                  <option value="">-- Select from 70 templates --</option>
                  {templates.map(t => (
                    <option key={t.id} value={t.id}>{t.category}: {t.name} (PKR {t.default_cost})</option>
                  ))}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Treatment Name *</label>
                  <input required value={formData.treatment_name} onChange={(e) => setFormData({...formData, treatment_name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Tooth Number</label>
                  <input placeholder="e.g., 16, 21, 36" value={formData.tooth_number} onChange={(e) => setFormData({...formData, tooth_number: e.target.value})} />
                </div>
              </div>
              <div className="form-group">
                <label>Chief Complaint</label>
                <textarea rows="2" value={formData.chief_complaint} onChange={(e) => setFormData({...formData, chief_complaint: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Diagnosis</label>
                <textarea rows="2" value={formData.diagnosis} onChange={(e) => setFormData({...formData, diagnosis: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Procedure Done</label>
                <textarea rows="2" value={formData.procedure_done} onChange={(e) => setFormData({...formData, procedure_done: e.target.value})} />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Cost (PKR) *</label>
                  <input type="number" required value={formData.cost} onChange={(e) => setFormData({...formData, cost: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Discount (PKR)</label>
                  <input type="number" value={formData.discount} onChange={(e) => setFormData({...formData, discount: e.target.value})} />
                </div>
              </div>
              <div className="form-group">
                <label>Amount Paid (PKR)</label>
                <input type="number" value={formData.amount_paid} onChange={(e) => setFormData({...formData, amount_paid: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Notes</label>
                <textarea rows="2" value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
              </div>
              <button type="submit" className="btn btn-primary">Save Treatment</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Treatments;