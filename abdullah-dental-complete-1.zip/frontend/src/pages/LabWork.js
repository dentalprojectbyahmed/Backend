import React, { useState, useEffect } from 'react';
import { getLabWork, createLabWork, getPatients } from '../services/api';

function LabWork() {
  const [labWork, setLabWork] = useState([]);
  const [patients, setPatients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    patient_id: '', lab_name: '', work_type: '', work_description: '', tooth_numbers: '',
    sent_date: new Date().toISOString().split('T')[0], expected_date: '', cost: '', charged_to_patient: ''
  });

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [labRes, patientsRes] = await Promise.all([getLabWork(), getPatients()]);
      setLabWork(labRes.data);
      setPatients(patientsRes.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createLabWork(formData);
      loadData();
      setShowForm(false);
    } catch (error) {
      alert('Error');
    }
  };

  return (
    <div>
      <div className="page-header flex-between">
        <h1>Lab Work</h1>
        <button onClick={() => setShowForm(true)} className="btn btn-primary">+ New Lab Work</button>
      </div>
      <div className="table-container">
        <table>
          <thead>
            <tr><th>Patient</th><th>Lab</th><th>Work Type</th><th>Sent</th><th>Expected</th><th>Status</th><th>Cost</th></tr>
          </thead>
          <tbody>
            {labWork.map(l => (
              <tr key={l.id}>
                <td>{l.full_name}</td>
                <td>{l.lab_name}</td>
                <td>{l.work_type}</td>
                <td>{new Date(l.sent_date).toLocaleDateString()}</td>
                <td>{l.expected_date ? new Date(l.expected_date).toLocaleDateString() : 'TBD'}</td>
                <td><span className={`badge badge-${l.status === 'received' ? 'success' : 'warning'}`}>{l.status}</span></td>
                <td>PKR {l.cost}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h2>New Lab Work</h2>
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Patient *</label>
                <select required value={formData.patient_id} onChange={e => setFormData({...formData, patient_id: e.target.value})}>
                  <option value="">Select</option>
                  {patients.map(p => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                </select>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Lab Name *</label>
                  <input required value={formData.lab_name} onChange={e => setFormData({...formData, lab_name: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Work Type *</label>
                  <select required value={formData.work_type} onChange={e => setFormData({...formData, work_type: e.target.value})}>
                    <option value="">Select</option>
                    <option value="Crown">Crown</option>
                    <option value="Bridge">Bridge</option>
                    <option value="Denture">Denture</option>
                    <option value="Implant">Implant</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label>Cost (PKR) *</label>
                  <input type="number" required value={formData.cost} onChange={e => setFormData({...formData, cost: e.target.value})} />
                </div>
                <div className="form-group">
                  <label>Charged to Patient</label>
                  <input type="number" value={formData.charged_to_patient} onChange={e => setFormData({...formData, charged_to_patient: e.target.value})} />
                </div>
              </div>
              <button type="submit" className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default LabWork;