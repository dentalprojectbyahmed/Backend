import React from 'react';

function Header({ user, onLogout }) {
  return (
    <div className="header">
      <div>
        <h2>Abdullah Dental Care Management</h2>
        <small>Hayatabad, Peshawar</small>
      </div>
      <div className="user-info">
        <span>👤 {user.full_name} ({user.role})</span>
        <button onClick={onLogout} className="logout-btn">Logout</button>
      </div>
    </div>
  );
}

export default Header;