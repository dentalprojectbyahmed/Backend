import React from 'react';
import { Link, useLocation } from 'react-router-dom';

function Sidebar({ user }) {
  const location = useLocation();
  
  const menuItems = [
    { path: '/', icon: '📊', label: 'Dashboard' },
    { path: '/patients', icon: '👥', label: 'Patients' },
    { path: '/appointments', icon: '📅', label: 'Appointments' },
    { path: '/treatments', icon: '🦷', label: 'Treatments' },
    { path: '/prescriptions', icon: '💊', label: 'Prescriptions' },
    { path: '/lab-work', icon: '🔬', label: 'Lab Work' },
    { path: '/expenses', icon: '💰', label: 'Expenses' },
    { path: '/orthodontics', icon: '🦷', label: 'Orthodontics' },
    { path: '/reports', icon: '📈', label: 'Reports' }
  ];
  
  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>🦷 Abdullah Dental</h2>
        <p style={{fontSize: '12px', opacity: 0.8}}>Dr. Ahmed Abdullah Khan</p>
        <p style={{fontSize: '10px', opacity: 0.6}}>PMC 7071-D</p>
      </div>
      <ul className="sidebar-menu">
        {menuItems.map(item => (
          <li key={item.path}>
            <Link 
              to={item.path}
              className={location.pathname === item.path ? 'active' : ''}
            >
              <span style={{marginRight: '10px'}}>{item.icon}</span>
              <span>{item.label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;