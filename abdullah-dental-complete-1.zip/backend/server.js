const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const db = require('./config/database');
const authenticateToken = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// ==================== AUTH ROUTES ====================

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const [users] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    
    if (users.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const user = users[0];
    const validPassword = await bcrypt.compare(password, user.password);
    
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        full_name: user.full_name,
        role: user.role
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get current user
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    const [users] = await db.query('SELECT id, username, full_name, role FROM users WHERE id = ?', [req.user.id]);
    res.json(users[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== PATIENTS ROUTES ====================

// Get all patients
app.get('/api/patients', authenticateToken, async (req, res) => {
  try {
    const [patients] = await db.query(`
      SELECT p.*, 
        COUNT(DISTINCT t.id) as treatment_count,
        COALESCE(SUM(t.balance), 0) as total_balance
      FROM patients p
      LEFT JOIN treatments t ON p.id = t.patient_id
      GROUP BY p.id
      ORDER BY p.created_at DESC
    `);
    res.json(patients);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single patient
app.get('/api/patients/:id', authenticateToken, async (req, res) => {
  try {
    const [patients] = await db.query('SELECT * FROM patients WHERE id = ?', [req.params.id]);
    if (patients.length === 0) {
      return res.status(404).json({ error: 'Patient not found' });
    }
    res.json(patients[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create patient
app.post('/api/patients', authenticateToken, async (req, res) => {
  try {
    const { full_name, father_name, age, gender, phone, cnic, address, medical_history, allergies } = req.body;
    
    // Generate MR number
    const [lastPatient] = await db.query('SELECT mr_number FROM patients ORDER BY id DESC LIMIT 1');
    let mrNumber = 'MR-0001';
    if (lastPatient.length > 0) {
      const lastNum = parseInt(lastPatient[0].mr_number.split('-')[1]);
      mrNumber = `MR-${String(lastNum + 1).padStart(4, '0')}`;
    }
    
    // Calculate next recall (6 months from now)
    const nextRecall = new Date();
    nextRecall.setMonth(nextRecall.getMonth() + 6);
    const nextRecallDate = nextRecall.toISOString().split('T')[0];
    
    const [result] = await db.query(
      `INSERT INTO patients (mr_number, full_name, father_name, age, gender, phone, cnic, address, medical_history, allergies, next_recall) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [mrNumber, full_name, father_name, age, gender, phone, cnic, address, medical_history, allergies, nextRecallDate]
    );
    
    const [newPatient] = await db.query('SELECT * FROM patients WHERE id = ?', [result.insertId]);
    res.status(201).json(newPatient[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update patient
app.put('/api/patients/:id', authenticateToken, async (req, res) => {
  try {
    const { full_name, father_name, age, gender, phone, cnic, address, medical_history, allergies } = req.body;
    
    await db.query(
      `UPDATE patients SET full_name=?, father_name=?, age=?, gender=?, phone=?, cnic=?, address=?, medical_history=?, allergies=? WHERE id=?`,
      [full_name, father_name, age, gender, phone, cnic, address, medical_history, allergies, req.params.id]
    );
    
    const [updated] = await db.query('SELECT * FROM patients WHERE id = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete patient
app.delete('/api/patients/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM patients WHERE id = ?', [req.params.id]);
    res.json({ message: 'Patient deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get patients needing recall
app.get('/api/patients/recalls/due', authenticateToken, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const [recalls] = await db.query(
      'SELECT * FROM patients WHERE next_recall <= ? ORDER BY next_recall ASC',
      [today]
    );
    res.json(recalls);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== APPOINTMENTS ROUTES ====================

// Get all appointments
app.get('/api/appointments', authenticateToken, async (req, res) => {
  try {
    const { date, status } = req.query;
    let query = `
      SELECT a.*, p.full_name, p.phone, p.mr_number 
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
    `;
    const params = [];
    
    if (date) {
      query += ' WHERE a.appointment_date = ?';
      params.push(date);
    }
    
    if (status) {
      query += params.length > 0 ? ' AND' : ' WHERE';
      query += ' a.status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY a.appointment_date DESC, a.appointment_time ASC';
    
    const [appointments] = await db.query(query, params);
    res.json(appointments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create appointment
app.post('/api/appointments', authenticateToken, async (req, res) => {
  try {
    const { patient_id, appointment_date, appointment_time, duration, treatment_type, notes } = req.body;
    
    const [result] = await db.query(
      `INSERT INTO appointments (patient_id, appointment_date, appointment_time, duration, treatment_type, notes, created_by) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [patient_id, appointment_date, appointment_time, duration || 30, treatment_type, notes, req.user.id]
    );
    
    const [newAppt] = await db.query(
      `SELECT a.*, p.full_name, p.phone FROM appointments a JOIN patients p ON a.patient_id = p.id WHERE a.id = ?`,
      [result.insertId]
    );
    res.status(201).json(newAppt[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update appointment
app.put('/api/appointments/:id', authenticateToken, async (req, res) => {
  try {
    const { appointment_date, appointment_time, duration, status, treatment_type, notes } = req.body;
    
    await db.query(
      `UPDATE appointments SET appointment_date=?, appointment_time=?, duration=?, status=?, treatment_type=?, notes=? WHERE id=?`,
      [appointment_date, appointment_time, duration, status, treatment_type, notes, req.params.id]
    );
    
    const [updated] = await db.query(
      `SELECT a.*, p.full_name, p.phone FROM appointments a JOIN patients p ON a.patient_id = p.id WHERE a.id = ?`,
      [req.params.id]
    );
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete appointment
app.delete('/api/appointments/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM appointments WHERE id = ?', [req.params.id]);
    res.json({ message: 'Appointment deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get today's appointments
app.get('/api/appointments/today', authenticateToken, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const [appointments] = await db.query(
      `SELECT a.*, p.full_name, p.phone, p.mr_number 
       FROM appointments a
       JOIN patients p ON a.patient_id = p.id
       WHERE a.appointment_date = ?
       ORDER BY a.appointment_time ASC`,
      [today]
    );
    res.json(appointments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== TREATMENTS ROUTES ====================

// Get all treatments
app.get('/api/treatments', authenticateToken, async (req, res) => {
  try {
    const { patient_id } = req.query;
    let query = `
      SELECT t.*, p.full_name, p.mr_number, u.full_name as doctor_name
      FROM treatments t
      JOIN patients p ON t.patient_id = p.id
      LEFT JOIN users u ON t.performed_by = u.id
    `;
    
    if (patient_id) {
      query += ' WHERE t.patient_id = ?';
      const [treatments] = await db.query(query + ' ORDER BY t.treatment_date DESC', [patient_id]);
      return res.json(treatments);
    }
    
    const [treatments] = await db.query(query + ' ORDER BY t.treatment_date DESC');
    res.json(treatments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create treatment
app.post('/api/treatments', authenticateToken, async (req, res) => {
  try {
    const { 
      patient_id, treatment_date, tooth_number, treatment_name, treatment_category,
      chief_complaint, diagnosis, procedure_done, cost, discount, amount_paid, notes 
    } = req.body;
    
    const balance = cost - (discount || 0) - (amount_paid || 0);
    const payment_status = balance === 0 ? 'paid' : (amount_paid > 0 ? 'partial' : 'unpaid');
    
    const [result] = await db.query(
      `INSERT INTO treatments (
        patient_id, treatment_date, tooth_number, treatment_name, treatment_category,
        chief_complaint, diagnosis, procedure_done, cost, discount, amount_paid, balance,
        payment_status, notes, performed_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        patient_id, treatment_date, tooth_number, treatment_name, treatment_category,
        chief_complaint, diagnosis, procedure_done, cost, discount || 0, amount_paid || 0,
        balance, payment_status, notes, req.user.id
      ]
    );
    
    // Update patient stats
    await db.query(
      `UPDATE patients SET 
       last_visit = ?,
       total_visits = total_visits + 1,
       points = points + ?
       WHERE id = ?`,
      [treatment_date, Math.floor(cost / 100), patient_id]
    );
    
    // Update badge based on points
    await db.query(`
      UPDATE patients SET 
        badge = CASE
          WHEN points >= 1000 THEN 'Platinum Patient'
          WHEN points >= 500 THEN 'Gold Patient'
          WHEN points >= 200 THEN 'Silver Patient'
          WHEN points >= 50 THEN 'Bronze Patient'
          ELSE 'New Patient'
        END
      WHERE id = ?
    `, [patient_id]);
    
    // Record payment if amount was paid
    if (amount_paid > 0) {
      await db.query(
        `INSERT INTO payments (patient_id, payment_date, amount, payment_method, payment_for, reference_id, received_by)
         VALUES (?, ?, ?, 'cash', 'treatment', ?, ?)`,
        [patient_id, treatment_date, amount_paid, result.insertId, req.user.id]
      );
    }
    
    const [newTreatment] = await db.query(
      `SELECT t.*, p.full_name FROM treatments t JOIN patients p ON t.patient_id = p.id WHERE t.id = ?`,
      [result.insertId]
    );
    res.status(201).json(newTreatment[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update treatment
app.put('/api/treatments/:id', authenticateToken, async (req, res) => {
  try {
    const {
      treatment_date, tooth_number, treatment_name, treatment_category,
      chief_complaint, diagnosis, procedure_done, cost, discount, amount_paid, notes
    } = req.body;
    
    const balance = cost - (discount || 0) - (amount_paid || 0);
    const payment_status = balance === 0 ? 'paid' : (amount_paid > 0 ? 'partial' : 'unpaid');
    
    await db.query(
      `UPDATE treatments SET 
       treatment_date=?, tooth_number=?, treatment_name=?, treatment_category=?,
       chief_complaint=?, diagnosis=?, procedure_done=?, cost=?, discount=?,
       amount_paid=?, balance=?, payment_status=?, notes=?
       WHERE id=?`,
      [
        treatment_date, tooth_number, treatment_name, treatment_category,
        chief_complaint, diagnosis, procedure_done, cost, discount || 0,
        amount_paid || 0, balance, payment_status, notes, req.params.id
      ]
    );
    
    const [updated] = await db.query(
      `SELECT t.*, p.full_name FROM treatments t JOIN patients p ON t.patient_id = p.id WHERE t.id = ?`,
      [req.params.id]
    );
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete treatment
app.delete('/api/treatments/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM treatments WHERE id = ?', [req.params.id]);
    res.json({ message: 'Treatment deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== PRESCRIPTIONS ROUTES ====================

// Get all prescriptions
app.get('/api/prescriptions', authenticateToken, async (req, res) => {
  try {
    const { patient_id } = req.query;
    let query = `
      SELECT pr.*, p.full_name, p.mr_number
      FROM prescriptions pr
      JOIN patients p ON pr.patient_id = p.id
    `;
    
    if (patient_id) {
      query += ' WHERE pr.patient_id = ?';
      const [prescriptions] = await db.query(query + ' ORDER BY pr.prescription_date DESC', [patient_id]);
      return res.json(prescriptions);
    }
    
    const [prescriptions] = await db.query(query + ' ORDER BY pr.prescription_date DESC');
    res.json(prescriptions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create prescription
app.post('/api/prescriptions', authenticateToken, async (req, res) => {
  try {
    const { patient_id, treatment_id, prescription_date, protocol_name, medicines, instructions, duration_days } = req.body;
    
    const [result] = await db.query(
      `INSERT INTO prescriptions (patient_id, treatment_id, prescription_date, protocol_name, medicines, instructions, duration_days, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [patient_id, treatment_id, prescription_date, protocol_name, medicines, instructions, duration_days, req.user.id]
    );
    
    const [newPrescription] = await db.query(
      `SELECT pr.*, p.full_name FROM prescriptions pr JOIN patients p ON pr.patient_id = p.id WHERE pr.id = ?`,
      [result.insertId]
    );
    res.status(201).json(newPrescription[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete prescription
app.delete('/api/prescriptions/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM prescriptions WHERE id = ?', [req.params.id]);
    res.json({ message: 'Prescription deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== LAB WORK ROUTES ====================

// Get all lab work
app.get('/api/lab-work', authenticateToken, async (req, res) => {
  try {
    const { patient_id, status } = req.query;
    let query = `
      SELECT l.*, p.full_name, p.mr_number
      FROM lab_work l
      JOIN patients p ON l.patient_id = p.id
    `;
    const params = [];
    
    if (patient_id) {
      query += ' WHERE l.patient_id = ?';
      params.push(patient_id);
    }
    
    if (status) {
      query += params.length > 0 ? ' AND' : ' WHERE';
      query += ' l.status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY l.sent_date DESC';
    
    const [labWork] = await db.query(query, params);
    res.json(labWork);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create lab work
app.post('/api/lab-work', authenticateToken, async (req, res) => {
  try {
    const { 
      patient_id, lab_name, work_type, work_description, tooth_numbers,
      sent_date, expected_date, cost, paid_to_lab, charged_to_patient, notes 
    } = req.body;
    
    const lab_balance = cost - (paid_to_lab || 0);
    
    const [result] = await db.query(
      `INSERT INTO lab_work (
        patient_id, lab_name, work_type, work_description, tooth_numbers,
        sent_date, expected_date, cost, paid_to_lab, charged_to_patient, lab_balance, notes, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        patient_id, lab_name, work_type, work_description, tooth_numbers,
        sent_date, expected_date, cost, paid_to_lab || 0, charged_to_patient || 0,
        lab_balance, notes, req.user.id
      ]
    );
    
    const [newLabWork] = await db.query(
      `SELECT l.*, p.full_name FROM lab_work l JOIN patients p ON l.patient_id = p.id WHERE l.id = ?`,
      [result.insertId]
    );
    res.status(201).json(newLabWork[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update lab work
app.put('/api/lab-work/:id', authenticateToken, async (req, res) => {
  try {
    const {
      lab_name, work_type, work_description, tooth_numbers,
      sent_date, expected_date, received_date, status, cost,
      paid_to_lab, charged_to_patient, notes
    } = req.body;
    
    const lab_balance = cost - (paid_to_lab || 0);
    
    await db.query(
      `UPDATE lab_work SET 
       lab_name=?, work_type=?, work_description=?, tooth_numbers=?,
       sent_date=?, expected_date=?, received_date=?, status=?, cost=?,
       paid_to_lab=?, charged_to_patient=?, lab_balance=?, notes=?
       WHERE id=?`,
      [
        lab_name, work_type, work_description, tooth_numbers,
        sent_date, expected_date, received_date, status, cost,
        paid_to_lab || 0, charged_to_patient || 0, lab_balance, notes,
        req.params.id
      ]
    );
    
    const [updated] = await db.query(
      `SELECT l.*, p.full_name FROM lab_work l JOIN patients p ON l.patient_id = p.id WHERE l.id = ?`,
      [req.params.id]
    );
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete lab work
app.delete('/api/lab-work/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM lab_work WHERE id = ?', [req.params.id]);
    res.json({ message: 'Lab work deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== EXPENSES ROUTES ====================

// Get all expenses
app.get('/api/expenses', authenticateToken, async (req, res) => {
  try {
    const { start_date, end_date, category } = req.query;
    let query = 'SELECT * FROM expenses';
    const params = [];
    
    if (start_date && end_date) {
      query += ' WHERE expense_date BETWEEN ? AND ?';
      params.push(start_date, end_date);
    }
    
    if (category) {
      query += params.length > 0 ? ' AND' : ' WHERE';
      query += ' category = ?';
      params.push(category);
    }
    
    query += ' ORDER BY expense_date DESC';
    
    const [expenses] = await db.query(query, params);
    res.json(expenses);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create expense
app.post('/api/expenses', authenticateToken, async (req, res) => {
  try {
    const { expense_date, category, description, amount, payment_method, vendor_name, receipt_number, notes } = req.body;
    
    const [result] = await db.query(
      `INSERT INTO expenses (expense_date, category, description, amount, payment_method, vendor_name, receipt_number, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [expense_date, category, description, amount, payment_method, vendor_name, receipt_number, notes, req.user.id]
    );
    
    const [newExpense] = await db.query('SELECT * FROM expenses WHERE id = ?', [result.insertId]);
    res.status(201).json(newExpense[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update expense
app.put('/api/expenses/:id', authenticateToken, async (req, res) => {
  try {
    const { expense_date, category, description, amount, payment_method, vendor_name, receipt_number, notes } = req.body;
    
    await db.query(
      `UPDATE expenses SET expense_date=?, category=?, description=?, amount=?, payment_method=?, vendor_name=?, receipt_number=?, notes=? WHERE id=?`,
      [expense_date, category, description, amount, payment_method, vendor_name, receipt_number, notes, req.params.id]
    );
    
    const [updated] = await db.query('SELECT * FROM expenses WHERE id = ?', [req.params.id]);
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete expense
app.delete('/api/expenses/:id', authenticateToken, async (req, res) => {
  try {
    await db.query('DELETE FROM expenses WHERE id = ?', [req.params.id]);
    res.json({ message: 'Expense deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ORTHODONTICS ROUTES ====================

// Get all orthodontic cases
app.get('/api/orthodontics', authenticateToken, async (req, res) => {
  try {
    const { patient_id, status } = req.query;
    let query = `
      SELECT o.*, p.full_name, p.mr_number, p.phone
      FROM orthodontics o
      JOIN patients p ON o.patient_id = p.id
    `;
    const params = [];
    
    if (patient_id) {
      query += ' WHERE o.patient_id = ?';
      params.push(patient_id);
    }
    
    if (status) {
      query += params.length > 0 ? ' AND' : ' WHERE';
      query += ' o.status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY o.start_date DESC';
    
    const [cases] = await db.query(query, params);
    res.json(cases);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create orthodontic case
app.post('/api/orthodontics', authenticateToken, async (req, res) => {
  try {
    const {
      patient_id, start_date, expected_completion, case_type,
      appliance_type, total_cost, deposit, notes
    } = req.body;
    
    const balance = total_cost - (deposit || 0);
    
    const [result] = await db.query(
      `INSERT INTO orthodontics (patient_id, start_date, expected_completion, case_type, appliance_type, total_cost, deposit, balance, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [patient_id, start_date, expected_completion, case_type, appliance_type, total_cost, deposit || 0, balance, notes, req.user.id]
    );
    
    // Record deposit payment if any
    if (deposit > 0) {
      await db.query(
        `INSERT INTO ortho_payments (ortho_id, payment_date, amount, payment_method, installment_number, notes, created_by)
         VALUES (?, ?, ?, 'cash', 1, 'Initial deposit', ?)`,
        [result.insertId, start_date, deposit, req.user.id]
      );
    }
    
    const [newCase] = await db.query(
      `SELECT o.*, p.full_name FROM orthodontics o JOIN patients p ON o.patient_id = p.id WHERE o.id = ?`,
      [result.insertId]
    );
    res.status(201).json(newCase[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update orthodontic case
app.put('/api/orthodontics/:id', authenticateToken, async (req, res) => {
  try {
    const {
      start_date, expected_completion, actual_completion, case_type,
      appliance_type, total_cost, deposit, status, notes
    } = req.body;
    
    const balance = total_cost - deposit;
    
    await db.query(
      `UPDATE orthodontics SET start_date=?, expected_completion=?, actual_completion=?, case_type=?, appliance_type=?, total_cost=?, deposit=?, balance=?, status=?, notes=? WHERE id=?`,
      [start_date, expected_completion, actual_completion, case_type, appliance_type, total_cost, deposit, balance, status, notes, req.params.id]
    );
    
    const [updated] = await db.query(
      `SELECT o.*, p.full_name FROM orthodontics o JOIN patients p ON o.patient_id = p.id WHERE o.id = ?`,
      [req.params.id]
    );
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get orthodontic payments
app.get('/api/orthodontics/:id/payments', authenticateToken, async (req, res) => {
  try {
    const [payments] = await db.query(
      'SELECT * FROM ortho_payments WHERE ortho_id = ? ORDER BY payment_date DESC',
      [req.params.id]
    );
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add orthodontic payment
app.post('/api/orthodontics/:id/payments', authenticateToken, async (req, res) => {
  try {
    const { payment_date, amount, payment_method, notes } = req.body;
    const orthoId = req.params.id;
    
    // Get current installment count
    const [payments] = await db.query('SELECT COUNT(*) as count FROM ortho_payments WHERE ortho_id = ?', [orthoId]);
    const installmentNumber = payments[0].count + 1;
    
    const [result] = await db.query(
      `INSERT INTO ortho_payments (ortho_id, payment_date, amount, payment_method, installment_number, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [orthoId, payment_date, amount, payment_method, installmentNumber, notes, req.user.id]
    );
    
    // Update orthodontic case balance
    await db.query(
      'UPDATE orthodontics SET deposit = deposit + ?, balance = balance - ? WHERE id = ?',
      [amount, amount, orthoId]
    );
    
    const [newPayment] = await db.query('SELECT * FROM ortho_payments WHERE id = ?', [result.insertId]);
    res.status(201).json(newPayment[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get orthodontic visits
app.get('/api/orthodontics/:id/visits', authenticateToken, async (req, res) => {
  try {
    const [visits] = await db.query(
      'SELECT * FROM ortho_visits WHERE ortho_id = ? ORDER BY visit_date DESC',
      [req.params.id]
    );
    res.json(visits);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add orthodontic visit
app.post('/api/orthodontics/:id/visits', authenticateToken, async (req, res) => {
  try {
    const { visit_date, procedure_done, next_visit_date, notes } = req.body;
    const orthoId = req.params.id;
    
    // Get current visit count
    const [visits] = await db.query('SELECT COUNT(*) as count FROM ortho_visits WHERE ortho_id = ?', [orthoId]);
    const visitNumber = visits[0].count + 1;
    
    const [result] = await db.query(
      `INSERT INTO ortho_visits (ortho_id, visit_date, visit_number, procedure_done, next_visit_date, notes, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [orthoId, visit_date, visitNumber, procedure_done, next_visit_date, notes, req.user.id]
    );
    
    const [newVisit] = await db.query('SELECT * FROM ortho_visits WHERE id = ?', [result.insertId]);
    res.status(201).json(newVisit[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== TREATMENT TEMPLATES ROUTES ====================

// Get all treatment templates
app.get('/api/treatment-templates', authenticateToken, async (req, res) => {
  try {
    const { category } = req.query;
    let query = 'SELECT * FROM treatment_templates WHERE is_active = TRUE';
    
    if (category) {
      query += ' AND category = ?';
      const [templates] = await db.query(query + ' ORDER BY category, name', [category]);
      return res.json(templates);
    }
    
    const [templates] = await db.query(query + ' ORDER BY category, name');
    res.json(templates);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== PRESCRIPTION PROTOCOLS ROUTES ====================

// Get all prescription protocols
app.get('/api/prescription-protocols', authenticateToken, async (req, res) => {
  try {
    const [protocols] = await db.query(
      'SELECT * FROM prescription_protocols WHERE is_active = TRUE ORDER BY protocol_name'
    );
    res.json(protocols);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== REPORTS & DASHBOARD ROUTES ====================

// Dashboard statistics
app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
  try {
    const today = new Date().toISOString().split('T')[0];
    const monthStart = new Date();
    monthStart.setDate(1);
    const monthStartDate = monthStart.toISOString().split('T')[0];
    
    // Today's appointments
    const [todayAppts] = await db.query(
      'SELECT COUNT(*) as count FROM appointments WHERE appointment_date = ? AND status != "cancelled"',
      [today]
    );
    
    // Total patients
    const [totalPatients] = await db.query('SELECT COUNT(*) as count FROM patients');
    
    // This month revenue
    const [monthRevenue] = await db.query(
      'SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE payment_date >= ?',
      [monthStartDate]
    );
    
    // Pending payments
    const [pendingPayments] = await db.query(
      'SELECT COALESCE(SUM(balance), 0) as total FROM treatments WHERE payment_status IN ("unpaid", "partial")'
    );
    
    // Recalls due
    const [recallsDue] = await db.query(
      'SELECT COUNT(*) as count FROM patients WHERE next_recall <= ?',
      [today]
    );
    
    // Active orthodontic cases
    const [activeCases] = await db.query(
      'SELECT COUNT(*) as count FROM orthodontics WHERE status = "active"'
    );
    
    // Pending lab work
    const [pendingLab] = await db.query(
      'SELECT COUNT(*) as count FROM lab_work WHERE status IN ("sent", "in-progress")'
    );
    
    // This month expenses
    const [monthExpenses] = await db.query(
      'SELECT COALESCE(SUM(amount), 0) as total FROM expenses WHERE expense_date >= ?',
      [monthStartDate]
    );
    
    // Recent treatments (last 10)
    const [recentTreatments] = await db.query(`
      SELECT t.*, p.full_name, p.mr_number 
      FROM treatments t
      JOIN patients p ON t.patient_id = p.id
      ORDER BY t.treatment_date DESC, t.created_at DESC
      LIMIT 10
    `);
    
    // Upcoming appointments (next 7 days)
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    const nextWeekDate = nextWeek.toISOString().split('T')[0];
    
    const [upcomingAppts] = await db.query(`
      SELECT a.*, p.full_name, p.phone, p.mr_number
      FROM appointments a
      JOIN patients p ON a.patient_id = p.id
      WHERE a.appointment_date BETWEEN ? AND ?
      AND a.status != 'cancelled'
      ORDER BY a.appointment_date ASC, a.appointment_time ASC
      LIMIT 10
    `, [today, nextWeekDate]);
    
    res.json({
      today_appointments: todayAppts[0].count,
      total_patients: totalPatients[0].count,
      month_revenue: monthRevenue[0].total,
      pending_payments: pendingPayments[0].total,
      recalls_due: recallsDue[0].count,
      active_ortho_cases: activeCases[0].count,
      pending_lab_work: pendingLab[0].count,
      month_expenses: monthExpenses[0].total,
      recent_treatments: recentTreatments,
      upcoming_appointments: upcomingAppts
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Revenue report
app.get('/api/reports/revenue', authenticateToken, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    
    const [revenue] = await db.query(`
      SELECT 
        DATE(payment_date) as date,
        payment_method,
        SUM(amount) as total
      FROM payments
      WHERE payment_date BETWEEN ? AND ?
      GROUP BY DATE(payment_date), payment_method
      ORDER BY date DESC
    `, [start_date, end_date]);
    
    const [summary] = await db.query(`
      SELECT 
        payment_method,
        COUNT(*) as count,
        SUM(amount) as total
      FROM payments
      WHERE payment_date BETWEEN ? AND ?
      GROUP BY payment_method
    `, [start_date, end_date]);
    
    const [grandTotal] = await db.query(`
      SELECT SUM(amount) as total FROM payments WHERE payment_date BETWEEN ? AND ?
    `, [start_date, end_date]);
    
    res.json({
      daily_breakdown: revenue,
      summary: summary,
      grand_total: grandTotal[0].total || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Expenses report
app.get('/api/reports/expenses', authenticateToken, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    
    const [expenses] = await db.query(`
      SELECT 
        category,
        COUNT(*) as count,
        SUM(amount) as total
      FROM expenses
      WHERE expense_date BETWEEN ? AND ?
      GROUP BY category
      ORDER BY total DESC
    `, [start_date, end_date]);
    
    const [grandTotal] = await db.query(`
      SELECT SUM(amount) as total FROM expenses WHERE expense_date BETWEEN ? AND ?
    `, [start_date, end_date]);
    
    res.json({
      by_category: expenses,
      grand_total: grandTotal[0].total || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Treatment report
app.get('/api/reports/treatments', authenticateToken, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    
    const [treatments] = await db.query(`
      SELECT 
        treatment_category,
        COUNT(*) as count,
        SUM(cost) as total_cost,
        SUM(amount_paid) as total_paid,
        SUM(balance) as total_balance
      FROM treatments
      WHERE treatment_date BETWEEN ? AND ?
      GROUP BY treatment_category
      ORDER BY count DESC
    `, [start_date, end_date]);
    
    res.json(treatments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== PAYMENTS ROUTES ====================

// Get all payments
app.get('/api/payments', authenticateToken, async (req, res) => {
  try {
    const { patient_id, start_date, end_date } = req.query;
    let query = `
      SELECT py.*, p.full_name, p.mr_number
      FROM payments py
      JOIN patients p ON py.patient_id = p.id
    `;
    const params = [];
    
    if (patient_id) {
      query += ' WHERE py.patient_id = ?';
      params.push(patient_id);
    }
    
    if (start_date && end_date) {
      query += params.length > 0 ? ' AND' : ' WHERE';
      query += ' py.payment_date BETWEEN ? AND ?';
      params.push(start_date, end_date);
    }
    
    query += ' ORDER BY py.payment_date DESC';
    
    const [payments] = await db.query(query, params);
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create payment
app.post('/api/payments', authenticateToken, async (req, res) => {
  try {
    const { patient_id, payment_date, amount, payment_method, payment_for, reference_id, transaction_id, notes } = req.body;
    
    const [result] = await db.query(
      `INSERT INTO payments (patient_id, payment_date, amount, payment_method, payment_for, reference_id, transaction_id, notes, received_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [patient_id, payment_date, amount, payment_method, payment_for, reference_id, transaction_id, notes, req.user.id]
    );
    
    // If payment is for a treatment, update treatment record
    if (payment_for === 'treatment' && reference_id) {
      const [treatment] = await db.query('SELECT * FROM treatments WHERE id = ?', [reference_id]);
      if (treatment.length > 0) {
        const newAmountPaid = treatment[0].amount_paid + amount;
        const newBalance = treatment[0].cost - treatment[0].discount - newAmountPaid;
        const newStatus = newBalance === 0 ? 'paid' : (newAmountPaid > 0 ? 'partial' : 'unpaid');
        
        await db.query(
          'UPDATE treatments SET amount_paid = ?, balance = ?, payment_status = ? WHERE id = ?',
          [newAmountPaid, newBalance, newStatus, reference_id]
        );
      }
    }
    
    const [newPayment] = await db.query(
      'SELECT py.*, p.full_name FROM payments py JOIN patients p ON py.patient_id = p.id WHERE py.id = ?',
      [result.insertId]
    );
    res.status(201).json(newPayment[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
  console.log(`🦷 Abdullah Dental Care Server running on port ${PORT}`);
});
