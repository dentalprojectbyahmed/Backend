-- Abdullah Dental Care Database Schema
-- Run this script to create all tables

CREATE DATABASE IF NOT EXISTS abdullah_dental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE abdullah_dental;

-- Users table (staff authentication)
CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role ENUM('admin', 'doctor', 'assistant') DEFAULT 'assistant',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
  id INT PRIMARY KEY AUTO_INCREMENT,
  mr_number VARCHAR(20) UNIQUE NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  father_name VARCHAR(100),
  age INT,
  gender ENUM('male', 'female', 'other') NOT NULL,
  phone VARCHAR(20) NOT NULL,
  cnic VARCHAR(20),
  address TEXT,
  medical_history TEXT,
  allergies TEXT,
  last_visit DATE,
  next_recall DATE,
  total_visits INT DEFAULT 0,
  points INT DEFAULT 0,
  badge VARCHAR(50) DEFAULT 'New Patient',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  duration INT DEFAULT 30,
  status ENUM('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show') DEFAULT 'scheduled',
  treatment_type VARCHAR(100),
  notes TEXT,
  reminder_sent BOOLEAN DEFAULT FALSE,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Treatments table
CREATE TABLE IF NOT EXISTS treatments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  treatment_date DATE NOT NULL,
  tooth_number VARCHAR(20),
  treatment_name VARCHAR(200) NOT NULL,
  treatment_category VARCHAR(50),
  chief_complaint TEXT,
  diagnosis TEXT,
  procedure_done TEXT,
  cost DECIMAL(10, 2) NOT NULL,
  discount DECIMAL(10, 2) DEFAULT 0,
  amount_paid DECIMAL(10, 2) DEFAULT 0,
  balance DECIMAL(10, 2) DEFAULT 0,
  payment_status ENUM('paid', 'partial', 'unpaid') DEFAULT 'unpaid',
  notes TEXT,
  performed_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (performed_by) REFERENCES users(id)
);

-- Prescriptions table
CREATE TABLE IF NOT EXISTS prescriptions (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  treatment_id INT,
  prescription_date DATE NOT NULL,
  protocol_name VARCHAR(100),
  medicines TEXT NOT NULL,
  instructions TEXT,
  duration_days INT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (treatment_id) REFERENCES treatments(id) ON DELETE SET NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Lab Work table
CREATE TABLE IF NOT EXISTS lab_work (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  lab_name VARCHAR(100) NOT NULL,
  work_type VARCHAR(100) NOT NULL,
  work_description TEXT,
  tooth_numbers VARCHAR(100),
  sent_date DATE NOT NULL,
  expected_date DATE,
  received_date DATE,
  status ENUM('sent', 'in-progress', 'received', 'fitted') DEFAULT 'sent',
  cost DECIMAL(10, 2) NOT NULL,
  paid_to_lab DECIMAL(10, 2) DEFAULT 0,
  charged_to_patient DECIMAL(10, 2) DEFAULT 0,
  lab_balance DECIMAL(10, 2) DEFAULT 0,
  notes TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Expenses table
CREATE TABLE IF NOT EXISTS expenses (
  id INT PRIMARY KEY AUTO_INCREMENT,
  expense_date DATE NOT NULL,
  category VARCHAR(50) NOT NULL,
  description TEXT NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method ENUM('cash', 'bank', 'jazzcash', 'easypaisa', 'card') NOT NULL,
  vendor_name VARCHAR(100),
  receipt_number VARCHAR(50),
  notes TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Orthodontics table
CREATE TABLE IF NOT EXISTS orthodontics (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  start_date DATE NOT NULL,
  expected_completion DATE,
  actual_completion DATE,
  case_type VARCHAR(100) NOT NULL,
  appliance_type VARCHAR(100),
  total_cost DECIMAL(10, 2) NOT NULL,
  deposit DECIMAL(10, 2) DEFAULT 0,
  balance DECIMAL(10, 2) NOT NULL,
  status ENUM('active', 'completed', 'discontinued') DEFAULT 'active',
  notes TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Orthodontic Payments table
CREATE TABLE IF NOT EXISTS ortho_payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  ortho_id INT NOT NULL,
  payment_date DATE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method ENUM('cash', 'bank', 'jazzcash', 'easypaisa', 'card') NOT NULL,
  installment_number INT,
  notes TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ortho_id) REFERENCES orthodontics(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Orthodontic Visits table
CREATE TABLE IF NOT EXISTS ortho_visits (
  id INT PRIMARY KEY AUTO_INCREMENT,
  ortho_id INT NOT NULL,
  visit_date DATE NOT NULL,
  visit_number INT,
  procedure_done TEXT,
  next_visit_date DATE,
  notes TEXT,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ortho_id) REFERENCES orthodontics(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Payments table (general billing)
CREATE TABLE IF NOT EXISTS payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  payment_date DATE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method ENUM('cash', 'bank', 'jazzcash', 'easypaisa', 'card') NOT NULL,
  payment_for VARCHAR(50) DEFAULT 'treatment',
  reference_id INT,
  transaction_id VARCHAR(100),
  notes TEXT,
  received_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  FOREIGN KEY (received_by) REFERENCES users(id)
);

-- Treatment Templates table (70 treatments)
CREATE TABLE IF NOT EXISTS treatment_templates (
  id INT PRIMARY KEY AUTO_INCREMENT,
  category VARCHAR(50) NOT NULL,
  name VARCHAR(200) NOT NULL,
  default_cost DECIMAL(10, 2) NOT NULL,
  description TEXT,
  duration_minutes INT DEFAULT 30,
  is_active BOOLEAN DEFAULT TRUE
);

-- Prescription Protocols table (35 protocols)
CREATE TABLE IF NOT EXISTS prescription_protocols (
  id INT PRIMARY KEY AUTO_INCREMENT,
  protocol_name VARCHAR(100) NOT NULL,
  indication VARCHAR(200),
  medicines TEXT NOT NULL,
  instructions TEXT,
  duration_days INT,
  is_active BOOLEAN DEFAULT TRUE
);

-- Insert default admin user (password: admin123)
INSERT INTO users (username, password, full_name, role) VALUES 
('admin', '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.q1lRps.9cGLcZEiGDMVr5yUP1KUOYTa', 'Dr. Ahmed Abdullah Khan', 'admin'),
('naveed', '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.q1lRps.9cGLcZEiGDMVr5yUP1KUOYTa', 'Naveed', 'assistant')
ON DUPLICATE KEY UPDATE id=id;

-- Insert 70 Treatment Templates
INSERT INTO treatment_templates (category, name, default_cost, duration_minutes) VALUES
-- Restorative (15 treatments)
('Restorative', 'Amalgam Filling - Single Surface', 1500, 30),
('Restorative', 'Amalgam Filling - Two Surfaces', 2000, 40),
('Restorative', 'Amalgam Filling - Three+ Surfaces', 2500, 50),
('Restorative', 'Composite Filling - Anterior Single Surface', 2000, 30),
('Restorative', 'Composite Filling - Anterior Multiple Surfaces', 3000, 45),
('Restorative', 'Composite Filling - Posterior Single Surface', 2500, 35),
('Restorative', 'Composite Filling - Posterior Multiple Surfaces', 3500, 50),
('Restorative', 'GIC Filling', 1500, 25),
('Restorative', 'Temporary Filling', 500, 15),
('Restorative', 'Core Build-up', 3000, 40),
('Restorative', 'Inlay/Onlay - Composite', 8000, 60),
('Restorative', 'Inlay/Onlay - Porcelain', 12000, 60),
('Restorative', 'Crown - Metal', 8000, 45),
('Restorative', 'Crown - PFM (Porcelain Fused to Metal)', 12000, 45),
('Restorative', 'Crown - Full Ceramic/Zirconia', 18000, 45),

-- Endodontics (8 treatments)
('Endodontics', 'Pulpotomy', 2500, 45),
('Endodontics', 'Pulpectomy', 3000, 60),
('Endodontics', 'Root Canal Treatment - Anterior', 8000, 90),
('Endodontics', 'Root Canal Treatment - Premolar', 10000, 90),
('Endodontics', 'Root Canal Treatment - Molar', 12000, 120),
('Endodontics', 'RCT Retreatment', 15000, 120),
('Endodontics', 'Apicectomy', 10000, 90),
('Endodontics', 'Post & Core', 3000, 40),

-- Periodontics (8 treatments)
('Periodontics', 'Scaling & Polishing', 3000, 45),
('Periodontics', 'Deep Scaling (Per Quadrant)', 2000, 30),
('Periodontics', 'Root Planing (Per Quadrant)', 3000, 45),
('Periodontics', 'Gingivectomy (Per Quadrant)', 8000, 60),
('Periodontics', 'Gingivoplasty', 10000, 60),
('Periodontics', 'Flap Surgery (Per Quadrant)', 15000, 90),
('Periodontics', 'Bone Grafting', 25000, 120),
('Periodontics', 'Crown Lengthening', 12000, 75),

-- Prosthodontics (10 treatments)
('Prosthodontics', 'Complete Denture - Upper or Lower', 18000, 90),
('Prosthodontics', 'Complete Denture - Both', 35000, 120),
('Prosthodontics', 'Partial Denture - Acrylic', 12000, 75),
('Prosthodontics', 'Partial Denture - Cast Metal', 20000, 90),
('Prosthodontics', 'Flexible Denture', 25000, 90),
('Prosthodontics', 'Denture Repair', 2000, 30),
('Prosthodontics', 'Denture Reline', 4000, 45),
('Prosthodontics', 'Bridge - 3 Unit PFM', 30000, 90),
('Prosthodontics', 'Bridge - 3 Unit Zirconia', 45000, 90),
('Prosthodontics', 'Implant Crown', 30000, 60),

-- Oral Surgery (12 treatments)
('Oral Surgery', 'Simple Extraction', 1500, 20),
('Oral Surgery', 'Surgical Extraction', 3000, 40),
('Oral Surgery', 'Wisdom Tooth Extraction - Simple', 3500, 45),
('Oral Surgery', 'Wisdom Tooth Extraction - Impacted', 8000, 75),
('Oral Surgery', 'Alveoplasty', 5000, 45),
('Oral Surgery', 'Frenectomy', 6000, 40),
('Oral Surgery', 'Incision & Drainage', 2500, 30),
('Oral Surgery', 'Cyst Enucleation', 15000, 90),
('Oral Surgery', 'Biopsy', 8000, 45),
('Oral Surgery', 'Implant Placement - Single', 35000, 90),
('Oral Surgery', 'Sinus Lift', 40000, 120),
('Oral Surgery', 'Socket Preservation', 10000, 45),

-- Orthodontics (5 treatments)
('Orthodontics', 'Orthodontic Consultation & Records', 3000, 60),
('Orthodontics', 'Metal Braces - Full Treatment', 80000, 45),
('Orthodontics', 'Ceramic Braces - Full Treatment', 100000, 45),
('Orthodontics', 'Lingual Braces - Full Treatment', 150000, 60),
('Orthodontics', 'Clear Aligners - Full Treatment', 120000, 45),

-- Pediatric (7 treatments)
('Pediatric', 'Fluoride Application', 1000, 20),
('Pediatric', 'Pit & Fissure Sealant - Per Tooth', 1500, 15),
('Pediatric', 'Space Maintainer', 6000, 40),
('Pediatric', 'Pulpotomy - Primary Tooth', 2000, 35),
('Pediatric', 'Stainless Steel Crown - Primary Tooth', 3000, 35),
('Pediatric', 'Extraction - Primary Tooth', 1000, 15),
('Pediatric', 'Habit Breaking Appliance', 8000, 45),

-- Cosmetic (5 treatments)
('Cosmetic', 'Teeth Whitening - In Office', 15000, 60),
('Cosmetic', 'Teeth Whitening - Take Home Kit', 8000, 30),
('Cosmetic', 'Veneer - Composite', 8000, 60),
('Cosmetic', 'Veneer - Porcelain', 25000, 60),
('Cosmetic', 'Smile Design - Full Mouth', 200000, 120)
ON DUPLICATE KEY UPDATE id=id;

-- Insert 35 Prescription Protocols
INSERT INTO prescription_protocols (protocol_name, indication, medicines, instructions, duration_days) VALUES
('Post-Extraction', 'After tooth extraction', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS', 'Take after meals. Avoid hot/spicy food. No smoking. Rinse with warm salt water after 24 hours.', 5),
('Post-RCT', 'After root canal treatment', 'Cap Amoxicillin 500mg TDS\nTab Ponstan 500mg TDS\nTab Flagyl 400mg TDS', 'Take after meals. Avoid chewing from treated side for 24 hours.', 5),
('Acute Pulpitis', 'Severe toothache', 'Tab Augmentin 625mg BD\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS', 'Take after meals. Emergency appointment needed.', 3),
('Periodontal Abscess', 'Gum infection', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS\nChlorhexidine Mouthwash BD', 'Take medicines after meals. Rinse mouth twice daily. Maintain oral hygiene.', 7),
('Pericoronitis', 'Wisdom tooth infection', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS\nChlorhexidine Mouthwash BD', 'Complete course. Rinse with mouthwash. Keep area clean.', 5),

('TMJ Pain', 'Jaw joint pain', 'Tab Myoril 4mg BD\nTab Brufen 400mg TDS\nTab Omeprazole 20mg OD', 'Take muscle relaxant at night. Apply warm compress. Avoid hard foods.', 7),
('Aphthous Ulcers', 'Mouth ulcers', 'Kenacort Oral Paste (apply locally TDS)\nTab B-Complex OD\nChlorhexidine Mouthwash BD', 'Apply gel after meals. Avoid spicy food. Rinse gently.', 7),
('Acute Gingivitis', 'Gum inflammation', 'Chlorhexidine Mouthwash BD\nTab Vitamin C 500mg OD\nTab Brufen 400mg if needed', 'Rinse twice daily. Gentle brushing. Professional cleaning needed.', 7),
('Dry Socket', 'Post-extraction pain', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg + Tab Paracetamol 500mg TDS\nChlorhexidine Mouthwash BD', 'Take painkillers regularly. Gentle rinses. Socket dressing may be needed.', 5),
('Dental Abscess', 'Tooth abscess', 'Tab Augmentin 625mg BD\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS', 'Complete antibiotic course. Emergency drainage may be needed.', 7),

('Herpetic Gingivostomatitis', 'Viral mouth infection', 'Acyclovir Cream (apply locally TDS)\nTab Paracetamol 500mg TDS\nChlorhexidine Mouthwash BD\nSoft diet', 'Apply antiviral cream. Rest. Plenty of fluids. Avoid contact.', 7),
('Angular Cheilitis', 'Corner of mouth infection', 'Miconazole Oral Gel (apply BD)\nTab B-Complex OD', 'Apply after cleaning area. Keep lips moisturized.', 10),
('Post-Scaling', 'After teeth cleaning', 'Chlorhexidine Mouthwash BD\nSensitive Toothpaste', 'Rinse twice daily for one week. Use sensitive toothpaste if needed.', 7),
('Orthodontic Placement', 'After braces placement', 'Tab Brufen 400mg SOS\nOral Wax (use as needed)\nChlorhexidine Mouthwash BD', 'Take painkiller if discomfort. Use wax on brackets. Soft diet for 2-3 days.', 3),
('Implant Placement', 'After implant surgery', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg TDS\nTab Flagyl 400mg TDS\nChlorhexidine Mouthwash BD', 'Take all medicines. No smoking. Soft diet. Ice packs for swelling.', 7),

('Sensitive Teeth', 'Tooth sensitivity', 'Sensodyne Toothpaste (use BD)\nFluoride Mouthwash OD', 'Use sensitive toothpaste regularly. Avoid hot/cold foods initially.', 30),
('Burning Mouth', 'Burning sensation', 'Tab B-Complex BD\nTab Clonazepam 0.5mg HS\nArtificial Saliva Spray', 'Take vitamins regularly. Use saliva spray as needed. Reduce stress.', 30),
('Candidiasis', 'Oral thrush', 'Nystatin Oral Suspension 5ml QID\nMiconazole Oral Gel BD', 'Rinse and swallow. Continue for 2 days after symptoms resolve.', 10),
('Allergic Reaction', 'Drug/material allergy', 'Tab Avil 50mg TDS\nTab Prednisolone 20mg OD tapering\nInjection Avil IM if severe', 'Take antihistamine. Seek emergency if swelling/breathing difficulty.', 5),
('Post-Surgery Major', 'After major oral surgery', 'Tab Augmentin 1gm BD\nTab Brufen 400mg + Tab Paracetamol 500mg TDS\nTab Flagyl 400mg TDS\nChlorhexidine Mouthwash BD', 'Complete antibiotics. Regular painkillers. Soft/liquid diet. Ice packs.', 7),

('Toothache - Mild', 'Mild dental pain', 'Tab Paracetamol 500mg TDS\nChlorhexidine Mouthwash BD', 'Take after meals. Appointment needed for examination.', 3),
('Toothache - Moderate', 'Moderate dental pain', 'Tab Brufen 400mg TDS\nTab Paracetamol 500mg TDS\nChlorhexidine Mouthwash BD', 'Take painkillers after meals. Urgent appointment needed.', 3),
('Sinusitis - Dental', 'Sinus infection from tooth', 'Tab Augmentin 625mg BD\nTab Brufen 400mg TDS\nNasal Decongestant Spray', 'Complete course. Steam inhalation. Dental cause needs treatment.', 7),
('Prophylaxis - Cardiac', 'Before procedure (heart condition)', 'Cap Amoxicillin 2gm single dose (1 hour before)', 'Take exactly 1 hour before dental procedure.', 1),
('Prophylaxis - Diabetic', 'Before procedure (diabetes)', 'Cap Amoxicillin 500mg BD (start 1 day before)', 'Start one day before procedure. Continue for 3 days after.', 5),

('Teething Pain', 'Child teething discomfort', 'Teething Gel (apply locally)\nSyrup Paracetamol as per weight', 'Apply gel gently. Give paracetamol if fever/pain.', 5),
('Trauma - Soft Tissue', 'Oral tissue injury', 'Cap Amoxicillin 500mg TDS\nTab Brufen 400mg TDS\nChlorhexidine Mouthwash BD', 'Take medicines. Soft diet. Keep area clean. Watch for infection.', 5),
('Stomatitis', 'Mouth inflammation', 'Chlorhexidine Mouthwash BD\nTab Vitamin B-Complex BD\nOral Protective Paste', 'Rinse twice daily. Apply protective paste. Soft/bland diet.', 10),
('Halitosis', 'Bad breath', 'Chlorhexidine Mouthwash BD\nTongue Cleaner\nTab Vitamin C 500mg OD', 'Rinse after brushing. Clean tongue daily. Maintain hygiene.', 14),
('Xerostomia', 'Dry mouth', 'Artificial Saliva Spray\nBiotene Mouthwash BD\nSugar-free gum', 'Use spray frequently. Sip water often. Avoid caffeine.', 30),

('Pre-Prosthetic', 'Before denture/bridge', 'Chlorhexidine Mouthwash BD\nOral Hygiene Instructions', 'Rinse twice daily. Keep tissues healthy before impressions.', 7),
('Denture Sore', 'Denture irritation', 'Kenacort Oral Paste (apply TDS)\nChlorhexidine Mouthwash BD', 'Apply on sore area. Remove denture at night. Denture adjustment needed.', 5),
('Post-Whitening', 'After teeth whitening', 'Sensitive Toothpaste\nFluoride Gel', 'Use sensitive toothpaste. Avoid staining foods for 48 hours.', 7),
('Lichen Planus', 'Oral lichen planus', 'Kenacort Oral Paste TDS\nChlorhexidine Mouthwash BD\nTab Prednisolone if severe', 'Apply after meals. Avoid spicy foods. Long-term monitoring needed.', 14),
('Leukoplakia', 'White patch management', 'Vitamin A capsule OD\nChlorhexidine Mouthwash BD\nStop smoking/tobacco', 'Take vitamin regularly. Stop all tobacco. Biopsy may be needed.', 30)
ON DUPLICATE KEY UPDATE id=id;
