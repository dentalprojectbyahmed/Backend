
# Dental Backend API – Core Endpoints (Stub)

This file is a stub. Use `openapi-core.yaml` as the base and extend schemas for:

- Patients
- Appointments
- Invoices
- Treatments
- Prescriptions
- Reports
- Settings
- Follow-ups
- Lab / Ortho
- Attachments
- Messaging / Notifications
- Payments / Outstanding

You can import `openapi-core.yaml` into Stoplight Studio / Postman / Swagger Editor and expand it.
