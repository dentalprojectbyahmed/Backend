
import { markItemDone, removeDoneItemsFromPlansForInvoice } from "../treatmentPlans/treatmentPlans.service";
import { createInvoice } from "../invoices/invoices.service";
import { add as addVisit } from "../visithistory/visithistory.service";
import { addBalance } from "../outstanding/outstanding.service";
import { recordEvent } from "../gamification/gamification.service";
import { add as addFollowup } from "../recall/recall.service";
import { GAMIFICATION_EVENT, FOLLOWUP_SOURCE } from "./constants";
import { emit } from "./events";

/**
 * Finalize selected treatment-plan items for a patient on a given date:
 * - Mark items DONE (multi-visit aware via existing service).
 * - Create a VisitHistory record.
 * - Create an Invoice with those items.
 * - Update Outstanding balances.
 * - Add Gamification events.
 * - Optionally create follow-ups (simple rule: recall for big invoices).
 */
export async function finalizeVisitFromPlan(params: {
  patientId: string;
  planId: string;
  itemIds: string[];
  dateIso: string;
}) {
  const { patientId, planId, itemIds, dateIso } = params;

  // 1) Mark each item done in its plan
  for (const itemId of itemIds) {
    await markItemDone(patientId, planId, itemId);
  }

  // 2) Collect all DONE items for this patient and strip them from plans
  const doneItems = removeDoneItemsFromPlansForInvoice(patientId);

  // 3) Persist VisitHistory
  const visit = await addVisit({
    patientId,
    items: doneItems,
    date: dateIso
  });

  // 4) Build and persist Invoice from done items
  const invoice = await createInvoice({
    patientId,
    date: dateIso,
    items: doneItems.map((i: any) => ({
      treatmentId: i.treatmentId,
      name: i.name,
      tooth: i.tooth,
      surfaces: i.surfaces,
      quantity: i.quantity || 1,
      unitPricePkr: i.pricePkr
    })),
    discountFlat: 0,
    discountPercent: 0,
    paymentMethod: "CASH"
  } as any);

  // 5) Update Outstanding balance with invoice total (simple sum)
  const total = invoice.items.reduce((sum, it: any) => sum + it.unitPricePkr * it.quantity, 0);
  addBalance(patientId, total);

  // 6) Gamification: treatment completed
  await recordEvent(GAMIFICATION_EVENT.TREATMENT_COMPLETED as any);

  // 7) Simple follow-up rule: if total > 0, create a routine recall entry in 6 months
  const due = new Date(dateIso);
  due.setMonth(due.getMonth() + 6);
  await addFollowup({
    patientId,
    reason: "Routine recall after completed treatment",
    source: FOLLOWUP_SOURCE.ROUTINE_RECALL as any,
    dueDate: due.toISOString(),
    done: false
  } as any);

  // 8) Emit events for optional listeners
  await emit("TREATMENT_COMPLETED", { patientId, invoiceId: invoice.id, visitId: visit.id });
  await emit("INVOICE_CREATED", { invoiceId: invoice.id });
  await emit("FOLLOWUP_CREATED", { patientId });

  return { visit, invoice, total };
}
