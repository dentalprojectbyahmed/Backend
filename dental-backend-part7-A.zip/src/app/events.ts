
export type AppEventType =
  | "TREATMENT_COMPLETED"
  | "INVOICE_CREATED"
  | "PAYMENT_RECORDED"
  | "APPOINTMENT_NO_SHOW"
  | "FOLLOWUP_CREATED";

export type AppEventPayload = any;

type Handler = (payload: AppEventPayload) : Promise<void> | void;

const handlers: Record<AppEventType, Handler[]> = {
  TREATMENT_COMPLETED: [],
  INVOICE_CREATED: [],
  PAYMENT_RECORDED: [],
  APPOINTMENT_NO_SHOW: [],
  FOLLOWUP_CREATED: []
};

export function on(event: AppEventType, handler: Handler) {
  handlers[event].push(handler);
}

export async function emit(event: AppEventType, payload: AppEventPayload) {
  const list = handlers[event] || [];
  for (const h of list) {
    await Promise.resolve(h(payload));
  }
}
