
import { Express } from "express";

// Core modules (Part 1)
import patientsRouter from "../patients/patients.routes";
import treatmentsRouter from "../treatments/treatments.routes";
import treatmentPlansRouter from "../treatmentPlans/treatmentPlans.routes";
import appointmentsRouter from "../appointments/appointments.routes";
import invoicesRouter from "../invoices/invoices.routes";
import prescriptionsRouter from "../prescriptions/prescriptions.routes";
import consentsRouter from "../consents/consents.routes";
import followupsRouter from "../followups/followups.routes";
import gamificationRouter from "../gamification/gamification.routes";
import usdPkrRouter from "../usdPkr/usdPkr.routes";
import syncRouter from "../sync/sync.routes";

// Part 2
import reportsRouter from "../reports/reports.routes";
import analyticsRouter from "../analytics/analytics.routes";
import settingsRouter from "../settings/settings.routes";

// Part 4
import labRouter from "../lab/lab.routes";
import orthoRouter from "../ortho/ortho.routes";
import expensesRouter from "../expenses/expenses.routes";
import attachmentsRouter from "../attachments/attachments.routes";
import messagingRouter from "../messaging/messaging.routes";
import recallRouter from "../recall/recall.routes";

// Part 5
import notifyRouter from "../notify/notify.routes";

// Part 6
import visitHistoryRouter from "../visithistory/visithistory.routes";
import paymentsRouter from "../payments/payments.routes";

export function registerRoutes(app: Express) {
  app.get("/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  // Core
  app.use("/api/patients", patientsRouter);
  app.use("/api/treatments", treatmentsRouter);
  app.use("/api/treatment-plans", treatmentPlansRouter);
  app.use("/api/appointments", appointmentsRouter);
  app.use("/api/invoices", invoicesRouter);
  app.use("/api/prescriptions", prescriptionsRouter);
  app.use("/api/consents", consentsRouter);
  app.use("/api/followups", followupsRouter);
  app.use("/api/gamification", gamificationRouter);
  app.use("/api/usd-pkr", usdPkrRouter);
  app.use("/api/sync", syncRouter);

  // Reporting & settings
  app.use("/api/reports", reportsRouter);
  app.use("/api/analytics", analyticsRouter);
  app.use("/api/settings", settingsRouter);

  // Clinical support
  app.use("/api/lab", labRouter);
  app.use("/api/ortho", orthoRouter);
  app.use("/api/expenses", expensesRouter);
  app.use("/api/attachments", attachmentsRouter);
  app.use("/api/messaging", messagingRouter);
  app.use("/api/recall", recallRouter);

  // Notifications
  app.use("/api/notify", notifyRouter);

  // Financial & history
  app.use("/api/visits", visitHistoryRouter);
  app.use("/api/payments", paymentsRouter);
}
