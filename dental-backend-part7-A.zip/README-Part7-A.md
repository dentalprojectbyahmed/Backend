
# Dental Backend – Part 7A (Integration Layer)

This package provides the **integration glue** for Parts 1–6:

- A master routes file wiring ALL routers in one place.
- An application event bus for cross-module workflows.
- A workflow service to coordinate:
  - Treatment-plan → Done Today → Visit History → Invoice → Outstanding → Gamification → Recall.
- Shared constants and enums.

Your developer should:
1. Merge the `src/` tree from all parts.
2. Replace the old `src/routes/index.ts` with the `src/routes/index.master.ts` from this part (or copy its content into your existing file).
3. Use `app/workflows.service.ts` from this part as the central place to orchestrate complex flows.
