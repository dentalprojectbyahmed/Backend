export type DailyKpi = {
  date: string; // YYYY-MM-DD
  visits: number;
  revenue: number;
  newPatients: number;
};
