import { DailyKpi } from "./analytics.types";
import { Invoice } from "../invoices/invoices.schema";

// Simple KPI builder; plug real DB logic later
export function buildDailyKpi(date: string, invoices: Invoice[]): DailyKpi {
  const dayInvoices = invoices.filter(i => i.date.slice(0, 10) === date);
  const revenue = dayInvoices.reduce((sum, inv) => {
    const gross = inv.items.reduce((s, it) => s + it.unitPricePkr * it.quantity, 0);
    const afterPercent = gross * (1 - inv.discountPercent / 100);
    return sum + (afterPercent - inv.discountFlat);
  }, 0);

  return {
    date,
    visits: dayInvoices.length,
    revenue,
    newPatients: 0
  };
}
