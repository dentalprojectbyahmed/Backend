import { Router } from "express";
import { z } from "zod";
import { buildDailyKpi } from "./analytics.service";
import { listInvoices } from "../invoices/invoices.service";

const router = Router();

router.get("/daily/:date", async (req, res, next) => {
  try {
    const date = req.params.date; // YYYY-MM-DD
    const schema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
    schema.parse(date);
    const invoices = await listInvoices();
    const kpi = buildDailyKpi(date, invoices);
    res.json({ success: true, data: kpi });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
