export type DriveFileMetadata = {
  id?: string;
  name: string;
  mimeType: string;
  folderId?: string;
};
