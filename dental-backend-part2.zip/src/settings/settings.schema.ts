import { z } from "zod";

export const DentistSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string(),
  order: z.number().int().nonnegative().default(0)
});

export type Dentist = z.infer<typeof DentistSchema>;

export const ClinicSettingsSchema = z.object({
  id: z.string().uuid().optional(),
  clinicName: z.string(),
  address: z.string(),
  phone: z.string(),
  inflationAutoAdjustEnabled: z.boolean().default(false)
});

export type ClinicSettings = z.infer<typeof ClinicSettingsSchema>;
