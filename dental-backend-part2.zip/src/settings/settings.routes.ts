import { Router } from "express";
import { z } from "zod";
import { DentistSchema, ClinicSettingsSchema } from "./settings.schema";
import { listDentists, addDentist, getClinicSettings, updateClinicSettings } from "./settings.service";
import { requireAdminPin } from "../shared/pinGuard";

const router = Router();

router.get("/dentists", async (_req, res, next) => {
  try {
    const list = await listDentists();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/dentists", requireAdminPin, async (req, res, next) => {
  try {
    const body = DentistSchema.parse(req.body);
    const created = await addDentist(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

router.get("/clinic", async (_req, res, next) => {
  try {
    const settings = await getClinicSettings();
    res.json({ success: true, data: settings });
  } catch (err) {
    next(err);
  }
});

router.post("/clinic", requireAdminPin, async (req, res, next) => {
  try {
    const body = ClinicSettingsSchema.parse(req.body);
    const updated = await updateClinicSettings(body);
    res.status(201).json({ success: true, data: updated });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
