import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { Prescription } from "../prescriptions/prescriptions.schema";

export async function renderPrescriptionPdf(
  ctx: PdfRenderContext,
  prescription: Prescription,
  patient: { id: string; name: string }
): Promise<PdfBuffer> {
  const header = `PRESCRIPTION\nClinic: ${ctx.clinic.name}\nPhone: ${ctx.clinic.phone}\n`;
  const items = prescription.items
    .map(i => `- ${i.drugName} ${i.dose}, ${i.frequency} for ${i.duration}`)
    .join("\n");
  const content = `${header}\nPatient: ${patient.name} (${patient.id})\nCondition: ${prescription.conditionCode}\n\n${items}`;
  return Buffer.from(content, "utf-8");
}
