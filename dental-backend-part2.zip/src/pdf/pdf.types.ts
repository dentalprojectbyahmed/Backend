export type PdfRenderContext = {
  clinic: {
    name: string;
    address: string;
    phone: string;
    logoUrl?: string;
  };
};

export type PdfBuffer = Buffer;
