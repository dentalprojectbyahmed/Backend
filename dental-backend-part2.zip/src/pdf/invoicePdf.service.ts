import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { Invoice } from "../invoices/invoices.schema";

export async function renderInvoicePdf(
  ctx: PdfRenderContext,
  invoice: Invoice,
  consents: { title: string; body: string }[]
): Promise<PdfBuffer> {
  // Placeholder: integrate real PDF library (pdfkit, puppeteer, etc.)
  const header = `INVOICE\nClinic: ${ctx.clinic.name}\nPhone: ${ctx.clinic.phone}\n`;
  const items = invoice.items
    .map(i => `- ${i.name} x${i.quantity} = ${i.unitPricePkr}`)
    .join("\n");
  const consentText = consents
    .map(c => `== ${c.title} ==\n${c.body}`)
    .join("\n\n");
  const content = `${header}\nInvoice #${invoice.number}\n\n${items}\n\nConsents:\n${consentText}`;
  return Buffer.from(content, "utf-8");
}
