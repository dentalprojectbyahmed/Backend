
# Tangerine Frontend Kit – Abdullah Dental Care

This package contains:
- Full page templates matching the Tangerine Figma UI kit
- Complete layout system (sidebar + header + content shell)
- Expanded Tangerine-themed UI component catalog (shadcn-style)
- Tailwind presets JSON file

All components are React + Tailwind based (JSX).
