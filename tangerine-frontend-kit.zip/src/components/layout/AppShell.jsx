
import { Sidebar } from "../ui/sidebar";
import { Navbar } from "../ui/navbar";

export function AppShell({ title, sidebar, children }) {
  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)] flex">
      <Sidebar>{sidebar}</Sidebar>
      <div className="flex-1 flex flex-col">
        <Navbar title={title} />
        <main className="flex-1 px-6 py-4 bg-[var(--background)]">{children}</main>
      </div>
    </div>
  );
}
