
import { Button } from "../ui/button";

const links = [
  { label: "Dashboard", key: "dashboard" },
  { label: "Patients", key: "patients" },
  { label: "Appointments", key: "appointments" },
  { label: "Invoices", key: "invoices" },
  { label: "Prescriptions", key: "prescriptions" },
  { label: "Reports", key: "reports" },
  { label: "Follow-ups", key: "followups" },
  { label: "Settings", key: "settings" },
];

export function SidebarNav({ active, onChange }) {
  return (
    <nav className="flex flex-col gap-1">
      {links.map((link) => (
        <Button
          key={link.key}
          variant={active === link.key ? "primary" : "ghost"}
          size="sm"
          className="justify-start w-full"
          onClick={() => onChange?.(link.key)}
        >
          {link.label}
        </Button>
      ))}
    </nav>
  );
}
