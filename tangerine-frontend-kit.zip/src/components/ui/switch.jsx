
export function Switch({ checked, onChange }) {
  return (
    <button
      type="button"
      onClick={() => onChange?.(!checked)}
      className={[
        "w-9 h-5 flex items-center rounded-full px-0.5 transition-colors",
        checked ? "bg-[var(--primary)]" : "bg-[var(--muted)]",
      ].join(" ")}
    >
      <div
        className={[
          "h-4 w-4 rounded-full bg-white shadow-sm transform transition-transform",
          checked ? "translate-x-4" : "translate-x-0",
        ].join(" ")}
      />
    </button>
  );
}
