
export function Card({ children, className = "" }) {
  return (
    <div
      className={[
        "bg-[var(--card)] text-[var(--card-foreground)] rounded-[var(--radius-lg)] p-4 shadow-sm border border-[var(--border)]",
        className,
      ].join(" ")}
    >
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle }) {
  return (
    <div className="mb-3">
      {title && <h2 className="text-base font-semibold text-[var(--foreground)]">{title}</h2>}
      {subtitle && <p className="text-xs text-[var(--muted-foreground)] mt-1">{subtitle}</p>}
    </div>
  );
}

export function CardBody({ children }) {
  return <div className="space-y-2">{children}</div>;
}
