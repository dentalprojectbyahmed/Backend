
import { useState } from "react";

export function Tabs({ tabs, defaultTab, onChange }) {
  const [active, setActive] = useState(defaultTab || (tabs && tabs[0]?.value));
  const handleClick = (value) => {
    setActive(value);
    onChange?.(value);
  };
  return (
    <div className="flex flex-col gap-3">
      <div className="inline-flex rounded-[var(--radius)] bg-[var(--muted)] p-0.5">
        {tabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => handleClick(tab.value)}
            className={[
              "px-3 py-1 text-xs rounded-[calc(var(--radius)-2px)]",
              active === tab.value
                ? "bg-[var(--background)] text-[var(--foreground)] shadow-xs"
                : "text-[var(--muted-foreground)]",
            ].join(" ")}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div>
        {tabs.map((tab) => (
          <div key={tab.value} className={active === tab.value ? "block" : "hidden"}>
            {tab.content}
          </div>
        ))}
      </div>
    </div>
  );
}
