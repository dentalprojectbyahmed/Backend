
export function Button({ children, variant = "primary", size = "md", className = "", ...props }) {
  const base =
    "inline-flex items-center justify-center font-medium rounded-[var(--radius)] transition-colors focus:outline-none focus:ring-2 focus:ring-[var(--ring)] focus:ring-offset-2 focus:ring-offset-[var(--background)] disabled:opacity-60 disabled:cursor-not-allowed";
  const variants = {
    primary:
      "bg-[var(--primary)] text-[var(--primary-foreground)] hover:bg-[color-mix(in_oklab,var(--primary),black_5%)]",
    secondary:
      "bg-[var(--secondary)] text-[var(--secondary-foreground)] hover:bg-[color-mix(in_oklab,var(--secondary),black_5%)]",
    outline:
      "border border-[var(--border)] text-[var(--foreground)] bg-[var(--background)] hover:bg-[var(--muted)]",
    ghost: "bg-transparent text-[var(--foreground)] hover:bg-[var(--muted)]",
    destructive:
      "bg-[var(--destructive)] text-[var(--destructive-foreground)] hover:bg-[color-mix(in_oklab,var(--destructive),black_5%)]",
  };
  const sizes = {
    sm: "h-8 px-3 text-xs",
    md: "h-9 px-4 text-sm",
    lg: "h-10 px-5 text-base",
  };
  const cls = [
    base,
    variants[variant] || variants.primary,
    sizes[size] || sizes.md,
    className,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <button className={cls} {...props}>
      {children}
    </button>
  );
}
