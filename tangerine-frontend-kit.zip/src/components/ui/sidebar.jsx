
export function Sidebar({ children }) {
  return (
    <aside className="hidden md:flex md:flex-col w-60 bg-[var(--sidebar)] text-[var(--sidebar-foreground)] border-r border-[var(--sidebar-border)] p-4 gap-4">
      {children}
    </aside>
  );
}
