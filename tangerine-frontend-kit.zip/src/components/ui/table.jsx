
export function Table({ children }) {
  return (
    <div className="w-full overflow-x-auto border border-[var(--border)] rounded-[var(--radius-lg)]">
      <table className="w-full text-xs text-left">{children}</table>
    </div>
  );
}
export function THead({ children }) {
  return <thead className="bg-[var(--muted)] text-[var(--muted-foreground)]">{children}</thead>;
}
export function TBody({ children }) {
  return <tbody className="divide-y divide-[var(--border)]">{children}</tbody>;
}
export function TR({ children }) {
  return <tr className="hover:bg-[var(--muted)]/40">{children}</tr>;
}
export function TH({ children }) {
  return <th className="px-3 py-2 font-medium">{children}</th>;
}
export function TD({ children }) {
  return <td className="px-3 py-2 align-middle">{children}</td>;
}
