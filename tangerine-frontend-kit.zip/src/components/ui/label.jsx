
export function Label({ children, className = "", ...props }) {
  return (
    <label
      className={["block text-xs font-medium text-[var(--muted-foreground)] mb-1", className].join(" ")}
      {...props}
    >
      {children}
    </label>
  );
}
