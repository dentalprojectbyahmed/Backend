
export function Alert({ title, description, variant = "info" }) {
  const variants = {
    info: "border-sky-400 bg-sky-50 text-sky-900",
    success: "border-emerald-400 bg-emerald-50 text-emerald-900",
    warning: "border-amber-400 bg-amber-50 text-amber-900",
    error: "border-red-400 bg-red-50 text-red-900",
  };
  return (
    <div
      className={[
        "border rounded-[var(--radius)] px-3 py-2 text-xs space-y-1",
        variants[variant] || variants.info,
      ].join(" ")}
    >
      {title && <div className="font-semibold">{title}</div>}
      {description && <div>{description}</div>}
    </div>
  );
}
