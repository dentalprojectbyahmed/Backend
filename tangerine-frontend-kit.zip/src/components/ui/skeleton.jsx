
export function Skeleton({ className = "" }) {
  return (
    <div
      className={[
        "animate-pulse rounded-[var(--radius-sm)] bg-[var(--muted)]",
        className,
      ].join(" ")}
    />
  );
}
