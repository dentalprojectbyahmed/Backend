
export function Textarea({ className = "", ...props }) {
  return (
    <textarea
      className={[
        "w-full min-h-[80px] border border-[var(--input)] rounded-[var(--radius)] px-3 py-2 text-sm",
        "bg-[var(--background)] text-[var(--foreground)] shadow-xs",
        "focus:outline-none focus:ring-2 focus:ring-[var(--ring)] focus:border-[var(--ring)]",
        className,
      ].join(" ")}
      {...props}
    />
  );
}
