
export function Checkbox({ checked, onChange, label }) {
  return (
    <label className="inline-flex items-center gap-2 text-xs text-[var(--foreground)]">
      <input
        type="checkbox"
        className="h-4 w-4 rounded border border-[var(--border)] text-[var(--primary)]"
        checked={checked}
        onChange={(e) => onChange?.(e.target.checked)}
      />
      {label && <span>{label}</span>}
    </label>
  );
}
