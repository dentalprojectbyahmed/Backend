
export function Navbar({ title }) {
  return (
    <header className="w-full bg-[var(--background)] border-b border-[var(--border)] px-6 py-3 flex items-center justify-between">
      <h1 className="text-lg font-semibold text-[var(--foreground)] truncate">{title}</h1>
    </header>
  );
}
