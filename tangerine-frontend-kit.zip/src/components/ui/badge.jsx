
export function Badge({ children, variant = "default" }) {
  const variants = {
    default: "bg-[var(--accent)] text-[var(--accent-foreground)]",
    outline: "border border-[var(--border)] text-[var(--foreground)]",
    success: "bg-emerald-500 text-white",
    warning: "bg-amber-500 text-white",
    critical: "bg-[var(--destructive)] text-[var(--destructive-foreground)]",
  };
  return (
    <span
      className={[
        "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium",
        variants[variant] || variants.default,
      ].join(" ")}
    >
      {children}
    </span>
  );
}
