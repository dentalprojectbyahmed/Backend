
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";

export function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--background)]">
      <Card className="w-full max-w-sm">
        <CardHeader title="Abdullah Dental Care" subtitle="Sign in to your clinic dashboard" />
        <CardBody>
          <div className="space-y-3">
            <div>
              <Label>Email</Label>
              <Input type="email" placeholder="you@clinic.com" />
            </div>
            <div>
              <Label>Password</Label>
              <Input type="password" placeholder="••••••••" />
            </div>
            <Button className="w-full mt-2">Sign In</Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
