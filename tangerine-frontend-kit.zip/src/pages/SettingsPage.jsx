
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";
import { Switch } from "../components/ui/switch";

export function SettingsPage({ activeSection = "settings", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Settings" sidebar={sidebar}>
      <div className="grid md:grid-cols-2 gap-4">
        <Card>
          <CardHeader title="Clinic Profile" />
          <CardBody>
            <div className="space-y-2 text-xs">
              <div>
                <Label>Clinic name</Label>
                <Input defaultValue="ABDULLAH DENTAL CARE" />
              </div>
              <div>
                <Label>Address</Label>
                <Input defaultValue="37-G4, QASIM AVE., PHASE 2, HAYATABAD, PESHAWAR, PAKISTAN" />
              </div>
              <div>
                <Label>Phone</Label>
                <Input defaultValue="0334-5822-622" />
              </div>
              <Button size="sm" className="mt-2">
                Save
              </Button>
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Pricing & Inflation" />
          <CardBody>
            <div className="flex items-center justify-between text-xs">
              <span>Auto inflation adjustment</span>
              <Switch checked={true} onChange={() => {}} />
            </div>
            <div className="mt-3">
              <Button size="sm" variant="outline">
                Edit treatment prices
              </Button>
            </div>
          </CardBody>
        </Card>
      </div>
    </AppShell>
  );
}
