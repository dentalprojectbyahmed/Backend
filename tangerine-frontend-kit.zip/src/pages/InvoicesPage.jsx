
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Table, THead, TBody, TR, TH, TD } from "../components/ui/table";

const mockInvoices = [
  { number: "20251125-0001", patient: "Ali Khan", total: "PKR 18,000", status: "Paid" },
  { number: "20251125-0002", patient: "Sara Ahmed", total: "PKR 6,000", status: "Unpaid" },
];

export function InvoicesPage({ activeSection = "invoices", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Invoices" sidebar={sidebar}>
      <Card>
        <CardHeader title="Invoices" subtitle="Filter by date and status" />
        <CardBody>
          <div className="flex justify-end mb-2">
            <Button size="sm">New Invoice</Button>
          </div>
          <Table>
            <THead>
              <TR>
                <TH>Invoice #</TH>
                <TH>Patient</TH>
                <TH>Total</TH>
                <TH>Status</TH>
              </TR>
            </THead>
            <TBody>
              {mockInvoices.map((inv, i) => (
                <TR key={i}>
                  <TD>{inv.number}</TD>
                  <TD>{inv.patient}</TD>
                  <TD>{inv.total}</TD>
                  <TD>{inv.status}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardBody>
      </Card>
    </AppShell>
  );
}
