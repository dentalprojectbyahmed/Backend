
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Table, THead, TBody, TR, TH, TD } from "../components/ui/table";

const mockAppointments = [
  { time: "10:00 AM", patient: "Ali Khan", reason: "RCT 16", status: "Waiting" },
  { time: "10:30 AM", patient: "Sara Ahmed", reason: "Checkup", status: "Confirmed" },
];

export function AppointmentsPage({ activeSection = "appointments", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Appointments" sidebar={sidebar}>
      <Card>
        <CardHeader title="Today’s Appointments" subtitle="Schedule in 30-minute slots" />
        <CardBody>
          <div className="flex justify-end mb-2">
            <Button size="sm">New Appointment</Button>
          </div>
          <Table>
            <THead>
              <TR>
                <TH>Time</TH>
                <TH>Patient</TH>
                <TH>Reason</TH>
                <TH>Status</TH>
              </TR>
            </THead>
            <TBody>
              {mockAppointments.map((a, i) => (
                <TR key={i}>
                  <TD>{a.time}</TD>
                  <TD>{a.patient}</TD>
                  <TD>{a.reason}</TD>
                  <TD>{a.status}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardBody>
      </Card>
    </AppShell>
  );
}
