
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Table, THead, TBody, TR, TH, TD } from "../components/ui/table";

const mockPatients = [
  { id: "P-001", name: "Ali Khan", phone: "0300-0000000", lastVisit: "12-Nov-25" },
  { id: "P-002", name: "Sara Ahmed", phone: "0311-1111111", lastVisit: "10-Nov-25" },
];

export function PatientsListPage({ activeSection = "patients", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Patients" sidebar={sidebar}>
      <div className="flex items-center justify-between mb-3 gap-2">
        <Input className="max-w-xs" placeholder="Search patients..." />
        <Button size="sm">Add Patient</Button>
      </div>
      <Table>
        <THead>
          <TR>
            <TH>ID</TH>
            <TH>Name</TH>
            <TH>Phone</TH>
            <TH>Last Visit</TH>
          </TR>
        </THead>
        <TBody>
          {mockPatients.map((p) => (
            <TR key={p.id}>
              <TD>{p.id}</TD>
              <TD>{p.name}</TD>
              <TD>{p.phone}</TD>
              <TD>{p.lastVisit}</TD>
            </TR>
          ))}
        </TBody>
      </Table>
    </AppShell>
  );
}
