
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "../components/ui/table";
import { Button } from "../components/ui/button";

const mockFollowups = [
  { patient: "Ali Khan", reason: "Suture removal", due: "27-Nov-25" },
  { patient: "Zainab", reason: "RCT review", due: "28-Nov-25" },
];

export function FollowupsPage({ activeSection = "followups", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Follow-ups" sidebar={sidebar}>
      <Card>
        <CardHeader title="Follow-up Queue" subtitle="Pending and overdue visits" />
        <CardBody>
          <Table>
            <THead>
              <TR>
                <TH>Patient</TH>
                <TH>Reason</TH>
                <TH>Due date</TH>
                <TH></TH>
              </TR>
            </THead>
            <TBody>
              {mockFollowups.map((f, i) => (
                <TR key={i}>
                  <TD>{f.patient}</TD>
                  <TD>{f.reason}</TD>
                  <TD>{f.due}</TD>
                  <TD className="text-right">
                    <Button size="sm" variant="outline">
                      Schedule
                    </Button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardBody>
      </Card>
    </AppShell>
  );
}
