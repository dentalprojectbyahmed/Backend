
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Badge } from "../components/ui/badge";

export function DashboardPage({ activeSection = "dashboard", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Dashboard" sidebar={sidebar}>
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader title="Today’s Visits" subtitle="Patients booked today" />
          <CardBody>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-semibold">12</span>
              <Badge variant="success">+3 vs yesterday</Badge>
            </div>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Outstanding Balance" subtitle="Unpaid invoices" />
          <CardBody>
            <div className="text-2xl font-semibold">PKR 142,000</div>
          </CardBody>
        </Card>
        <Card>
          <CardHeader title="Follow-ups Due" subtitle="Patients to recall" />
          <CardBody>
            <div className="text-2xl font-semibold">7</div>
          </CardBody>
        </Card>
      </div>
    </AppShell>
  );
}
