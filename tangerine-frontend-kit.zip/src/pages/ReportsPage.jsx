
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Select } from "../components/ui/select";
import { Button } from "../components/ui/button";

export function ReportsPage({ activeSection = "reports", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Reports" sidebar={sidebar}>
      <Card>
        <CardHeader title="Yearly Summary" subtitle="Revenue, visits, new patients, top treatments" />
        <CardBody>
          <div className="flex items-center gap-2 mb-3">
            <Select className="max-w-[120px]">
              <option>2024</option>
              <option>2025</option>
            </Select>
            <Button size="sm">Generate</Button>
          </div>
          <div className="grid md:grid-cols-3 gap-3 text-xs">
            <div>
              <div className="font-semibold text-[var(--foreground)]">Total Revenue</div>
              <div className="text-lg font-semibold mt-1">PKR 4,250,000</div>
            </div>
            <div>
              <div className="font-semibold text-[var(--foreground)]">Completed Visits</div>
              <div className="text-lg font-semibold mt-1">1,320</div>
            </div>
            <div>
              <div className="font-semibold text-[var(--foreground)]">New Patients</div>
              <div className="text-lg font-semibold mt-1">240</div>
            </div>
          </div>
        </CardBody>
      </Card>
    </AppShell>
  );
}
