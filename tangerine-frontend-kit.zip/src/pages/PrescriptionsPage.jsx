
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";
import { Textarea } from "../components/ui/textarea";

export function PrescriptionsPage({ activeSection = "prescriptions", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  return (
    <AppShell title="Prescriptions" sidebar={sidebar}>
      <Card>
        <CardHeader title="New Prescription" subtitle="Condition → Protocol → PDF" />
        <CardBody>
          <div className="grid md:grid-cols-2 gap-3 text-xs">
            <div className="space-y-2">
              <div>
                <Label>Patient</Label>
                <Input placeholder="Search or select patient" />
              </div>
              <div>
                <Label>Condition</Label>
                <Input placeholder="e.g. Acute pain, abscess" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Prescription details</Label>
              <Textarea placeholder="Medication, dose, frequency, duration, notes..." />
            </div>
          </div>
          <div className="flex justify-end mt-4 gap-2">
            <Button variant="outline" size="sm">
              Load protocol
            </Button>
            <Button size="sm">Generate PDF</Button>
          </div>
        </CardBody>
      </Card>
    </AppShell>
  );
}
