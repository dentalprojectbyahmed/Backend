
import { AppShell } from "../components/layout/AppShell";
import { SidebarNav } from "../components/layout/SidebarNav";
import { Card, CardHeader, CardBody } from "../components/ui/card";
import { Tabs } from "../components/ui/tabs";
import { Button } from "../components/ui/button";

function OverviewTab() {
  return (
    <div className="space-y-2 text-xs">
      <div>
        <span className="font-semibold">Name:</span> Ali Khan
      </div>
      <div>
        <span className="font-semibold">Phone:</span> 0300-0000000
      </div>
      <div>
        <span className="font-semibold">Age:</span> 32
      </div>
      <div>
        <span className="font-semibold">Alerts:</span> None
      </div>
    </div>
  );
}

function TreatmentPlanTab() {
  return (
    <div className="space-y-2 text-xs">
      <div>16 – RCT + Crown (PLANNED)</div>
      <div>36 – Composite Filling (PLANNED)</div>
      <Button size="sm" variant="outline" className="mt-2">
        Add Treatment
      </Button>
    </div>
  );
}

function HistoryTab() {
  return <div className="text-xs">Past visits will appear here.</div>;
}

export function PatientProfilePage({ activeSection = "patients", onNavChange }) {
  const sidebar = <SidebarNav active={activeSection} onChange={onNavChange} />;

  const tabs = [
    { label: "Overview", value: "overview", content: <OverviewTab /> },
    { label: "Treatment Plan", value: "plan", content: <TreatmentPlanTab /> },
    { label: "History", value: "history", content: <HistoryTab /> },
  ];

  return (
    <AppShell title="Patient Profile" sidebar={sidebar}>
      <Card>
        <CardHeader title="Ali Khan" subtitle="Profile, Plan, and History" />
        <CardBody>
          <Tabs tabs={tabs} defaultTab="overview" />
        </CardBody>
      </Card>
    </AppShell>
  );
}
