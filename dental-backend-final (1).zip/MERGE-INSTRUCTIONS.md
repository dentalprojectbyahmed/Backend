
1. Create a new backend folder.
2. Unzip Parts 1–7 into that folder (overwrite when prompted).
3. Replace src/routes/index.ts with index.master.ts from Part 7A.
4. Ensure tsconfig.json contains proper include paths (`src/**/*`).
5. Add dependencies:
   npm install express helmet cors morgan zod node-cron axios jszip
6. For PDF: add pdfkit or puppeteer (your choice).
7. Environment variables needed:
   PORT
   USD_PKR_API_URL
   ADMIN_PIN
8. Replace all dummy providers (SMS/email/Drive) with real implementations.
