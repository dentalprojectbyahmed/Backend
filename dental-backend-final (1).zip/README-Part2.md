# Dental Backend – Part 2

This part adds cross-cutting modules to be merged into Part 1:

- pdf/           → PDF generation facades (invoice, plan, prescription)
- drive/         → Google Drive integration interfaces (JSON snapshots, generic uploads)
- reports/       → Monthly + yearly summary scaffolding
- analytics/     → High-level analytics service scaffolding
- settings/      → Dentist list, clinic info, inflation flags

All files are designed to be dropped into the same `src/` tree as Part 1.
