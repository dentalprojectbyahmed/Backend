Part 5 modules:
- Notification engine (scheduled + manual)
- Appointment reminder system
- No‑show auto follow‑up generator
- Full backup module (ZIP export)
- Import module (CSV -> patients)
- Calendar/slot logic expansion
- Global search engine (patients, treatments, invoices)
