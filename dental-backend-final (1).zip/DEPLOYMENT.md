
## Deployment Checklist

- Node 18+
- Install dependencies
- Set env variables
- Ensure HTTPS reverse proxy (Nginx/Cloudflare)
- Enable rate limiting & CORS
- Connect DB (Prisma recommended)
- Enable health endpoint /api/health/deep
- Build then run: npm run build && npm start
