import { Dentist, ClinicSettings } from "./settings.schema";

const dentists: Dentist[] = [];
let clinicSettings: ClinicSettings | null = null;

export async function listDentists(): Promise<Dentist[]> {
  return dentists.sort((a, b) => a.order - b.order);
}

export async function addDentist(d: Dentist): Promise<Dentist> {
  const withId: Dentist = { ...d, id: crypto.randomUUID() };
  dentists.push(withId);
  return withId;
}

export async function updateClinicSettings(settings: ClinicSettings): Promise<ClinicSettings> {
  clinicSettings = { ...settings, id: clinicSettings?.id ?? crypto.randomUUID() };
  return clinicSettings;
}

export async function getClinicSettings(): Promise<ClinicSettings | null> {
  return clinicSettings;
}
