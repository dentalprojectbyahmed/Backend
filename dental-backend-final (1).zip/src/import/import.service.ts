export function importPatientsCSV(csv){
 const lines=csv.trim().split(/\r?\n/);const out=[];
 for(let i=1;i<lines.length;i++){
   const [id,name,phone]=lines[i].split(',');
   out.push({id,name,phone});
 }
 return out;
}