import { DriveFileMetadata } from "./drive.types";

/**
 * These are facades where you plug in Google Drive SDK logic.
 * For now they are simple placeholders returning mock data.
 */

export async function uploadJsonSnapshot(
  payload: unknown,
  opts: { name: string; folderId?: string }
): Promise<DriveFileMetadata> {
  const json = JSON.stringify(payload, null, 2);
  // integrate Drive upload here
  return {
    id: "mock-drive-id-json",
    name: opts.name,
    mimeType: "application/json",
    folderId: opts.folderId
  };
}

export async function uploadPdf(
  buffer: Buffer,
  opts: { name: string; folderId?: string }
): Promise<DriveFileMetadata> {
  // integrate Drive upload here
  void buffer;
  return {
    id: "mock-drive-id-pdf",
    name: opts.name,
    mimeType: "application/pdf",
    folderId: opts.folderId
  };
}
