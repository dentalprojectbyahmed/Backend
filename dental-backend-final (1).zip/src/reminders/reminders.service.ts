import {listAppointments} from '../appointments/appointments.service';import {schedule} from '../notify/notify.service';
export async function generateReminders(now){
 const ap=await listAppointments();
 for(const a of ap){
   const date=a.startTime.slice(0,10);
   const t=a.startTime;
   if(a.status==='SCHEDULED' && t>now){
     const body=`Reminder: appointment at ${t}`;
     await schedule({patientId:a.patientId,channel:'WHATSAPP',body,scheduledAt:t,sent:false});
   }
 }
}