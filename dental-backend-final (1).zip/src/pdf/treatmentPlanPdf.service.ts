import { PdfRenderContext, PdfBuffer } from "./pdf.types";
import { TreatmentPlan } from "../treatmentPlans/treatmentPlans.schema";

export async function renderTreatmentPlanPdf(
  ctx: PdfRenderContext,
  plan: TreatmentPlan
): Promise<PdfBuffer> {
  const header = `TREATMENT PLAN\nClinic: ${ctx.clinic.name}\nPhone: ${ctx.clinic.phone}\n`;
  const items = plan.items
    .map(i => `- ${i.name} tooth ${i.tooth || "-"} = ${i.pricePkr}`)
    .join("\n");
  const content = `${header}\nPatient: ${plan.patientId}\n\n${items}`;
  return Buffer.from(content, "utf-8");
}
