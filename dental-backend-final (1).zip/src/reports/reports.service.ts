import { MonthlyReport, YearlyReport } from "./reports.types";
import { Invoice } from "../invoices/invoices.schema";

// Replace this with real DB queries. For now we accept invoices arrays.

export function buildMonthlyReport(month: string, invoices: Invoice[]): MonthlyReport {
  const totalRevenue = invoices.reduce((sum, inv) => {
    const gross = inv.items.reduce((s, i) => s + i.unitPricePkr * i.quantity, 0);
    const afterPercent = gross * (1 - inv.discountPercent / 100);
    return sum + (afterPercent - inv.discountFlat);
  }, 0);

  const summary: MonthlyReport = {
    month,
    totalRevenue,
    totalOutstanding: 0,
    completedVisits: invoices.length,
    newPatients: 0,
    topTreatments: []
  };

  return summary;
}

export function buildYearlyReport(year: string, invoices: Invoice[]): YearlyReport {
  const totalRevenue = invoices.reduce((sum, inv) => {
    const invYear = inv.date.slice(0, 4);
    if (invYear !== year) return sum;
    const gross = inv.items.reduce((s, i) => s + i.unitPricePkr * i.quantity, 0);
    const afterPercent = gross * (1 - inv.discountPercent / 100);
    return sum + (afterPercent - inv.discountFlat);
  }, 0);

  const summary: YearlyReport = {
    year,
    totalRevenue,
    totalOutstanding: 0,
    completedVisits: invoices.filter(i => i.date.slice(0, 4) === year).length,
    newPatients: 0,
    topTreatments: []
  };

  return summary;
}
