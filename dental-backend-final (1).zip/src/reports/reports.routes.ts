import { Router } from "express";
import { z } from "zod";
import { buildMonthlyReport, buildYearlyReport } from "./reports.service";
import { listInvoices } from "../invoices/invoices.service";

const router = Router();

router.get("/month/:month", async (req, res, next) => {
  try {
    const month = req.params.month; // YYYY-MM
    const schema = z.string().regex(/^\d{4}-\d{2}$/);
    schema.parse(month);
    const invoices = await listInvoices();
    const report = buildMonthlyReport(month, invoices);
    res.json({ success: true, data: report });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

router.get("/year/:year", async (req, res, next) => {
  try {
    const year = req.params.year; // YYYY
    const schema = z.string().regex(/^\d{4}$/);
    schema.parse(year);
    const invoices = await listInvoices();
    const report = buildYearlyReport(year, invoices);
    res.json({ success: true, data: report });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
