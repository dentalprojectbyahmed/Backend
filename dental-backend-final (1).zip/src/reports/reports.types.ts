export type RevenueSummary = {
  totalRevenue: number;
  totalOutstanding: number;
  completedVisits: number;
  newPatients: number;
};

export type TopTreatment = {
  treatmentId: string;
  name: string;
  count: number;
  revenue: number;
};

export type MonthlyReport = RevenueSummary & {
  month: string; // YYYY-MM
  topTreatments: TopTreatment[];
};

export type YearlyReport = RevenueSummary & {
  year: string; // YYYY
  topTreatments: TopTreatment[];
};
