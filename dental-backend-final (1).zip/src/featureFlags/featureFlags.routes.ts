
import { Router } from "express";
import { setFlag, listFlags } from "./featureFlags.service";
import { requireAdminPin } from "../shared/pinGuard";

const router = Router();

router.get("/", (_req, res) => {
  res.json({ success: true, data: listFlags() });
});

router.post("/", requireAdminPin, (req, res) => {
  const { key, enabled, description } = req.body;
  const flag = setFlag(String(key), Boolean(enabled), description ? String(description) : undefined);
  res.status(201).json({ success: true, data: flag });
});

export default router;
