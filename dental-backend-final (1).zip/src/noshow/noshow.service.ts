import {listAppointments} from '../appointments/appointments.service';import {add as addRecall} from '../recall/recall.service';
export async function generateNoShowFollowups(){
 const ap=await listAppointments();
 for(const a of ap){
   if(a.status==='NO_SHOW'){
     await addRecall({patientId:a.patientId,reason:'NO_SHOW',dueDate:new Date().toISOString(),done:false});
   }
 }
}