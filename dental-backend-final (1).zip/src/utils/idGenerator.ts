
/**
 * Wraps crypto.randomUUID() so you can later swap implementation if needed.
 */
export function generateId(): string {
  return crypto.randomUUID();
}

export function generateHumanId(prefix: string): string {
  const d = new Date();
  const stamp = [
    d.getFullYear(),
    String(d.getMonth() + 1).padStart(2, "0"),
    String(d.getDate()).padStart(2, "0"),
    String(d.getHours()).padStart(2, "0"),
    String(d.getMinutes()).padStart(2, "0"),
    String(d.getSeconds()).padStart(2, "0")
  ].join("");
  const rnd = Math.floor(Math.random() * 10000)
    .toString()
    .padStart(4, "0");
  return `${prefix}-${stamp}-${rnd}`;
}
