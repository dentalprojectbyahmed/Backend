import JSZip from 'jszip';
export async function exportFull(data){
 const zip=new JSZip();zip.file('database.json',JSON.stringify(data,null,2));
 return await zip.generateAsync({type:'nodebuffer'});
}