Part 4 modules:
- Lab work tracking
- Ortho module
- Expenses
- Attachments module (per visit)
- Messaging (WhatsApp templates & deep-links)
- Recall engine (biannual, missed follow-ups, overdue planned tx)
- Backup/Export base (CSV + JSON shapes)
