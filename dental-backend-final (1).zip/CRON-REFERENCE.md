
Cron jobs to wire in src/server.ts:

1. Hourly USD→PKR refresh
2. Daily Drive JSON snapshot
3. Auto no-show detection at 23:00
4. Daily reminder generation
5. Cleanup tasks (optional)
