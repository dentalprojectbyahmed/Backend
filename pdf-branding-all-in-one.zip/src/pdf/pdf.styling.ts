
import PDFDocument from "pdfkit";

export function drawHeader(doc: PDFKit.PDFDocument, ctx: any) {
  const { clinic } = ctx;
  const y = 20;

  if (clinic.logoBuffer) {
    try {
      doc.image(clinic.logoBuffer, 40, y, { width: 60 });
    } catch {}
  }

  const left = 120;
  doc.fontSize(16).text(clinic.name, left, y);
  doc.fontSize(10).text(clinic.address, left, y+18);
  doc.text("Phone: " + clinic.phone, left, y+32);
  doc.moveTo(40, y+60).lineTo(550, y+60).stroke();
  doc.moveDown();
}

export function drawFooter(doc: PDFKit.PDFDocument, ctx: any) {
  const footerY = doc.page.height - 50;
  doc.fontSize(9).text(
    ctx.clinic.footer || 
    ("Thank you for choosing " + ctx.clinic.name + "."),
    40,
    footerY,
    { align: "center", width: doc.page.width-80 }
  );
}

export const styles = {
  title: (doc: PDFKit.PDFDocument, text: string) => {
    doc.fontSize(14).text(text, { align: "left", underline: true });
    doc.moveDown();
  },
  label: (doc: PDFKit.PDFDocument, text: string) => {
    doc.fontSize(11).text(text);
    doc.moveDown(0.3);
  },
  small: (doc: PDFKit.PDFDocument, text: string) => {
    doc.fontSize(9).text(text);
  }
};
