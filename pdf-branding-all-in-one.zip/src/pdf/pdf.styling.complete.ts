
import PDFDocument from "pdfkit";
import axios from "axios";

export async function loadLogo(url: string) {
  try {
    const res = await axios.get(url, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch {
    return null;
  }
}

export function drawHeader(doc, ctx) {
  const { clinic } = ctx;
  const y = 20;

  if (clinic.logoBuffer) {
    try { doc.image(clinic.logoBuffer, 40, y, { width: 60 }); } catch {}
  }

  const left = 120;
  doc.fillColor("#003366").fontSize(18).text(clinic.name, left, y);
  doc.fillColor("#444").fontSize(10).text(clinic.address, left, y+20);
  doc.text("Phone: " + clinic.phone, left, y+34);

  doc.moveTo(40, y+60).lineTo(550, y+60).stroke("#003366");
  doc.moveDown();
}

export function drawFooter(doc, ctx) {
  const footerY = doc.page.height - 50;
  doc.fillColor("#555").fontSize(9).text(
    ctx.clinic.footer || ("Thank you for choosing " + ctx.clinic.name),
    40,
    footerY,
    { align: "center", width: doc.page.width-80 }
  );
}

export const styles = {
  title: (doc, text) => {
    doc.fillColor("#003366").fontSize(14).text(text, { underline: true });
    doc.moveDown();
  },
  label: (doc, text) => {
    doc.fillColor("#222").fontSize(11).text(text);
    doc.moveDown(0.3);
  },
  small: (doc, text) => {
    doc.fillColor("#444").fontSize(9).text(text);
  },
  tableHeader: (doc, cols) => {
    doc.fillColor("#003366").fontSize(10);
    cols.forEach(c => doc.text(c.label, c.x, c.y));
    doc.moveDown(0.3);
    doc.strokeColor("#003366").moveTo(40, doc.y).lineTo(550, doc.y).stroke();
  }
};
