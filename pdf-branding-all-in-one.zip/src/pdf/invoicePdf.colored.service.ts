
import { renderToBuffer } from "./pdf.utils";
import { drawHeader, drawFooter, styles } from "./pdf.styling.complete";

export async function renderInvoicePdfColored(ctx, invoice, patient, consents) {
  return renderToBuffer((doc) => {
    drawHeader(doc, ctx);

    styles.title(doc, "Invoice");

    doc.fontSize(10).text("Invoice #: " + invoice.number);
    doc.text("Date: " + invoice.date);
    doc.moveDown();

    styles.label(doc, "Patient: " + patient.name + " (" + patient.id + ")");

    const cols = [
      { label: "Treatment", x:40, y:doc.y },
      { label: "Tooth", x:240, y:doc.y },
      { label: "Qty", x:330, y:doc.y },
      { label: "Amount", x:420, y:doc.y }
    ];

    styles.tableHeader(doc, cols);

    let y = doc.y + 5;
    let gross=0;
    const fmt = n => "PKR " + n.toFixed(0);

    for(const item of invoice.items){
      const sub = (item.unitPricePkr||0)*(item.quantity||1);
      gross += sub;
      doc.fontSize(10).fillColor("#000");
      doc.text(item.name, 40, y);
      doc.text(item.tooth||"-", 240, y);
      doc.text(String(item.quantity||1), 330, y);
      doc.text(fmt(sub), 420, y);
      y+=18;
    }

    doc.moveDown(2);
    doc.fontSize(11).fillColor("#003366").text("Gross: "+fmt(gross),{align:"right"});
    const total = gross*(1-(invoice.discountPercent||0)/100)-(invoice.discountFlat||0);
    doc.text("Total: "+fmt(total),{align:"right"});

    if(consents.length>0){
      doc.addPage();
      drawHeader(doc, ctx);
      styles.title(doc, "Consents");
      consents.forEach(c=>{
        doc.fontSize(12).text(c.title,{underline:true});
        doc.fontSize(10).text(c.body,{align:"justify"});
        doc.moveDown();
      });
      drawFooter(doc, ctx);
      return;
    }

    drawFooter(doc, ctx);
  });
}
