
Complete PDF Branding Package

Includes:
- Colored theme (blue accents)
- A4 + Letter auto-switch
- Urdu RTL support
- Bilingual prescription template (English + Urdu)
- Logo embedding from URL or buffer
- Unified header/footer
- Table borders and spacing system
