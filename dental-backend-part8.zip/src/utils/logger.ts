
export function logInfo(msg: string, meta?: any) {
  console.log(JSON.stringify({ level: "info", msg, meta, ts: new Date().toISOString() }));
}

export function logError(msg: string, meta?: any) {
  console.error(JSON.stringify({ level: "error", msg, meta, ts: new Date().toISOString() }));
}
