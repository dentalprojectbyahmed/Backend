const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

dotenv.config();

const authRoutes = require('./routes/auth');
const patientRoutes = require('./routes/patients');
const appointmentRoutes = require('./routes/appointments');
const treatmentRoutes = require('./routes/treatments');
const prescriptionRoutes = require('./routes/prescriptions');
const billingRoutes = require('./routes/billing');
const labWorkRoutes = require('./routes/labWork');
const inventoryRoutes = require('./routes/inventory');
const expenseRoutes = require('./routes/expenses');
const orthodonticsRoutes = require('./routes/orthodontics');
const reportsRoutes = require('./routes/reports');

const app = express();

// CORS configuration - allow frontend
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true
}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/patients', patientRoutes);
app.use('/api/appointments', appointmentRoutes);
app.use('/api/treatments', treatmentRoutes);
app.use('/api/prescriptions', prescriptionRoutes);
app.use('/api/billing', billingRoutes);
app.use('/api/lab-work', labWorkRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/orthodontics', orthodonticsRoutes);
app.use('/api/reports', reportsRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Abdullah Dental Care API is running' });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!', message: err.message });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🦷 Abdullah Dental Care API running on port ${PORT}`);
  console.log(`📍 Hayatabad, Peshawar, Pakistan`);
  console.log(`👨‍⚕️ Dr. Ahmed Abdullah Khan (BDS, MPH, PMC 7071-D)`);
  console.log(`🌐 CORS enabled for http://localhost:3000`);
});
