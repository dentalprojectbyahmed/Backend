-- Abdullah Dental Care Database Schema
CREATE DATABASE IF NOT EXISTS abdullah_dental CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE abdullah_dental;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role ENUM('admin', 'doctor', 'staff') DEFAULT 'staff',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL
) ENGINE=InnoDB;

CREATE TABLE patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(100),
  date_of_birth DATE,
  gender ENUM('male', 'female', 'other'),
  address TEXT,
  medical_history TEXT,
  allergies TEXT,
  emergency_contact VARCHAR(100),
  emergency_phone VARCHAR(20),
  points INT DEFAULT 0,
  badges TEXT,
  last_visit DATE,
  next_recall DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  treatment_type VARCHAR(100),
  status ENUM('scheduled', 'confirmed', 'completed', 'cancelled', 'no-show') DEFAULT 'scheduled',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE treatments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  treatment_date DATE NOT NULL,
  treatment_name VARCHAR(200) NOT NULL,
  tooth_number VARCHAR(50),
  amount DECIMAL(10,2) DEFAULT 0,
  payment_status ENUM('pending', 'partial', 'paid') DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE prescriptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  prescription_date DATE NOT NULL,
  diagnosis VARCHAR(200),
  medications JSON,
  instructions TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE billing (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  billing_date DATE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_method ENUM('cash', 'card', 'bank_transfer', 'jazzcash', 'easypaisa') DEFAULT 'cash',
  payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'paid',
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE lab_work (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  work_type VARCHAR(100) NOT NULL,
  lab_name VARCHAR(100),
  sent_date DATE NOT NULL,
  expected_date DATE,
  received_date DATE,
  cost DECIMAL(10,2) DEFAULT 0,
  status ENUM('pending', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE inventory (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  quantity INT DEFAULT 0,
  unit VARCHAR(20),
  reorder_level INT DEFAULT 10,
  unit_cost DECIMAL(10,2) DEFAULT 0,
  supplier VARCHAR(100),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE expenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  expense_date DATE NOT NULL,
  category VARCHAR(50) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  description TEXT,
  payment_method ENUM('cash', 'card', 'bank_transfer', 'jazzcash', 'easypaisa') DEFAULT 'cash',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE orthodontics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  total_cost DECIMAL(10,2) NOT NULL,
  paid_amount DECIMAL(10,2) DEFAULT 0,
  payment_plan VARCHAR(50),
  status ENUM('active', 'completed', 'discontinued') DEFAULT 'active',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Default users (passwords: admin123)
INSERT INTO users (username, email, password, full_name, role) VALUES 
('admin', 'ahmedakg@gmail.com', '$2a$10$Z3zJQQZ9X0QZ0QZ0QZ0QZuH8vN.8Q0QZ0QZ0QZ0QZ0QZ0QZ0QZ0Q', 'Dr. Ahmed Abdullah Khan', 'admin'),
('naveed', 'meetmrnaveed@gmail.com', '$2a$10$Z3zJQQZ9X0QZ0QZ0QZ0QZuH8vN.8Q0QZ0QZ0QZ0QZ0QZ0QZ0QZ0Q', 'Naveed', 'staff');
