const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const [items] = await db.query('SELECT * FROM inventory ORDER BY name');
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get inventory', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { name, category, quantity, unit, reorder_level, unit_cost, supplier, notes } = req.body;
    if (!name) return res.status(400).json({ error: 'Item name required' });
    const [result] = await db.query(
      'INSERT INTO inventory (name, category, quantity, unit, reorder_level, unit_cost, supplier, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [name, category, quantity || 0, unit, reorder_level, unit_cost, supplier, notes]
    );
    res.status(201).json({ message: 'Inventory item created', itemId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create inventory item', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, category, quantity, unit, reorder_level, unit_cost, supplier, notes } = req.body;
    const [result] = await db.query(
      'UPDATE inventory SET name=?, category=?, quantity=?, unit=?, reorder_level=?, unit_cost=?, supplier=?, notes=? WHERE id=?',
      [name, category, quantity, unit, reorder_level, unit_cost, supplier, notes, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Item not found' });
    res.json({ message: 'Inventory item updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update inventory item', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM inventory WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Item not found' });
    res.json({ message: 'Inventory item deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete inventory item', details: error.message });
  }
});

module.exports = router;
