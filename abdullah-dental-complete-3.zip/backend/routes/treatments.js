const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { patient_id, date_from, date_to } = req.query;
    let query = `SELECT t.*, p.name as patient_name FROM treatments t JOIN patients p ON t.patient_id = p.id WHERE 1=1`;
    const params = [];
    
    if (patient_id) { query += ' AND t.patient_id = ?'; params.push(patient_id); }
    if (date_from) { query += ' AND t.treatment_date >= ?'; params.push(date_from); }
    if (date_to) { query += ' AND t.treatment_date <= ?'; params.push(date_to); }
    
    query += ' ORDER BY t.treatment_date DESC';
    const [treatments] = await db.query(query, params);
    res.json(treatments);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get treatments', details: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const [treatments] = await db.query(
      'SELECT t.*, p.name as patient_name FROM treatments t JOIN patients p ON t.patient_id = p.id WHERE t.id = ?',
      [req.params.id]
    );
    if (treatments.length === 0) return res.status(404).json({ error: 'Treatment not found' });
    res.json(treatments[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get treatment', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patient_id, treatment_date, treatment_name, tooth_number, amount, payment_status, notes } = req.body;
    if (!patient_id || !treatment_name) return res.status(400).json({ error: 'Patient and treatment name required' });
    
    const [result] = await db.query(
      'INSERT INTO treatments (patient_id, treatment_date, treatment_name, tooth_number, amount, payment_status, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [patient_id, treatment_date || new Date(), treatment_name, tooth_number, amount, payment_status || 'pending', notes]
    );
    res.status(201).json({ message: 'Treatment created', treatmentId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create treatment', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { treatment_date, treatment_name, tooth_number, amount, payment_status, notes } = req.body;
    const [result] = await db.query(
      'UPDATE treatments SET treatment_date=?, treatment_name=?, tooth_number=?, amount=?, payment_status=?, notes=? WHERE id=?',
      [treatment_date, treatment_name, tooth_number, amount, payment_status, notes, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Treatment not found' });
    res.json({ message: 'Treatment updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update treatment', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM treatments WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Treatment not found' });
    res.json({ message: 'Treatment deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete treatment', details: error.message });
  }
});

module.exports = router;
