const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { patient_id, payment_status } = req.query;
    let query = 'SELECT b.*, p.name as patient_name FROM billing b JOIN patients p ON b.patient_id = p.id WHERE 1=1';
    const params = [];
    if (patient_id) { query += ' AND b.patient_id = ?'; params.push(patient_id); }
    if (payment_status) { query += ' AND b.payment_status = ?'; params.push(payment_status); }
    query += ' ORDER BY b.billing_date DESC';
    const [billings] = await db.query(query, params);
    res.json(billings);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get billing records', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patient_id, billing_date, amount, payment_method, payment_status, description } = req.body;
    if (!patient_id || !amount) return res.status(400).json({ error: 'Patient and amount required' });
    const [result] = await db.query(
      'INSERT INTO billing (patient_id, billing_date, amount, payment_method, payment_status, description) VALUES (?, ?, ?, ?, ?, ?)',
      [patient_id, billing_date || new Date(), amount, payment_method || 'cash', payment_status || 'paid', description]
    );
    res.status(201).json({ message: 'Billing record created', billingId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create billing record', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { amount, payment_method, payment_status, description } = req.body;
    const [result] = await db.query(
      'UPDATE billing SET amount=?, payment_method=?, payment_status=?, description=? WHERE id=?',
      [amount, payment_method, payment_status, description, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Billing record not found' });
    res.json({ message: 'Billing record updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update billing record', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM billing WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Billing record not found' });
    res.json({ message: 'Billing record deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete billing record', details: error.message });
  }
});

module.exports = router;
