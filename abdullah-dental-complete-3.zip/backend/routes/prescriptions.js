const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

router.get('/', async (req, res) => {
  try {
    const { patient_id } = req.query;
    let query = 'SELECT pr.*, p.name as patient_name FROM prescriptions pr JOIN patients p ON pr.patient_id = p.id WHERE 1=1';
    const params = [];
    if (patient_id) { query += ' AND pr.patient_id = ?'; params.push(patient_id); }
    query += ' ORDER BY pr.prescription_date DESC';
    const [prescriptions] = await db.query(query, params);
    res.json(prescriptions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get prescriptions', details: error.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const [prescriptions] = await db.query(
      'SELECT pr.*, p.name as patient_name FROM prescriptions pr JOIN patients p ON pr.patient_id = p.id WHERE pr.id = ?',
      [req.params.id]
    );
    if (prescriptions.length === 0) return res.status(404).json({ error: 'Prescription not found' });
    res.json(prescriptions[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get prescription', details: error.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const { patient_id, prescription_date, diagnosis, medications, instructions } = req.body;
    if (!patient_id || !diagnosis) return res.status(400).json({ error: 'Patient and diagnosis required' });
    
    const [result] = await db.query(
      'INSERT INTO prescriptions (patient_id, prescription_date, diagnosis, medications, instructions) VALUES (?, ?, ?, ?, ?)',
      [patient_id, prescription_date || new Date(), diagnosis, JSON.stringify(medications), instructions]
    );
    res.status(201).json({ message: 'Prescription created', prescriptionId: result.insertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create prescription', details: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { prescription_date, diagnosis, medications, instructions } = req.body;
    const [result] = await db.query(
      'UPDATE prescriptions SET prescription_date=?, diagnosis=?, medications=?, instructions=? WHERE id=?',
      [prescription_date, diagnosis, JSON.stringify(medications), instructions, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Prescription not found' });
    res.json({ message: 'Prescription updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update prescription', details: error.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM prescriptions WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Prescription not found' });
    res.json({ message: 'Prescription deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete prescription', details: error.message });
  }
});

module.exports = router;
