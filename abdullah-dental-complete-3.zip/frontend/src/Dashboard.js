import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from './api';
import './Dashboard.css';

function Dashboard() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      navigate('/login');
      return;
    }
    setUser(JSON.parse(userData));
    fetchStats();
  }, [navigate]);

  const fetchStats = async () => {
    try {
      const response = await api.get('/reports/dashboard-stats');
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  if (!user) return <div>Loading...</div>;

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <h1>🦷 Abdullah Dental Care</h1>
          <p>Welcome, {user.full_name}</p>
        </div>
        <button onClick={handleLogout} className="btn-logout">Logout</button>
      </header>

      <div className="dashboard-content">
        <h2>Dashboard</h2>
        
        {stats && (
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-icon">👥</div>
              <div className="stat-value">{stats.total_patients}</div>
              <div className="stat-label">Total Patients</div>
            </div>
            
            <div className="stat-card">
              <div className="stat-icon">📅</div>
              <div className="stat-value">{stats.today_appointments}</div>
              <div className="stat-label">Today's Appointments</div>
            </div>
            
            <div className="stat-card">
              <div className="stat-icon">💰</div>
              <div className="stat-value">PKR {stats.monthly_revenue?.toLocaleString()}</div>
              <div className="stat-label">Monthly Revenue</div>
            </div>
            
            <div className="stat-card">
              <div className="stat-icon">📊</div>
              <div className="stat-value">PKR {stats.monthly_expenses?.toLocaleString()}</div>
              <div className="stat-label">Monthly Expenses</div>
            </div>
          </div>
        )}

        <div className="modules-grid">
          <div className="module-card">📋 Patients</div>
          <div className="module-card">📅 Appointments</div>
          <div className="module-card">🦷 Treatments</div>
          <div className="module-card">💊 Prescriptions</div>
          <div className="module-card">💳 Billing</div>
          <div className="module-card">🔬 Lab Work</div>
          <div className="module-card">📦 Inventory</div>
          <div className="module-card">💸 Expenses</div>
          <div className="module-card">🦷 Orthodontics</div>
          <div className="module-card">📈 Reports</div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
