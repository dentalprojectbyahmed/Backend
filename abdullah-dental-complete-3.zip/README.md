# Abdullah Dental Care - Complete Management System

Full-stack dental clinic management with authentication, 10 modules, and Pakistani localization.

## Quick Start

### Backend Setup
```bash
cd backend
npm install
mysql -u root -p < database/schema.sql
# Edit .env with your MySQL password
npm start
```

Backend runs at: http://localhost:5000

### Frontend Setup
```bash
cd frontend
npm install
npm start
```

Frontend runs at: http://localhost:3000

## Default Login
- Username: `admin`
- Password: `admin123`

## Features
✅ Complete auth (login/register)
✅ 10 modules (patients, appointments, treatments, prescriptions, billing, lab work, inventory, expenses, orthodontics, reports)
✅ CORS configured
✅ JWT authentication
✅ Pakistani payment methods (PKR, JazzCash, EasyPaisa)

## Tech Stack
- Backend: Node.js + Express + MySQL2
- Frontend: React + Axios + React Router
- Auth: JWT + bcrypt

## Clinic Info
**Abdullah Dental Care**
Dr. Ahmed Abdullah Khan (BDS, MPH, PMC 7071-D)
Hayatabad, Peshawar, Pakistan

## Support
ahmedakg@gmail.com
