import { Router } from "express";

const router = Router();

router.post("/dexie", async (_req, res, _next) => {
  // Placeholder for Dexie delta sync handler
  res.json({ success: true, message: "Dexie sync placeholder" });
});

export default router;
