import { Request, Response, NextFunction } from "express";

export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  const status = err.status || 500;
  const code = err.code || "INTERNAL_ERROR";

  // eslint-disable-next-line no-console
  console.error("Error:", {
    status,
    code,
    message: err.message,
    stack: err.stack
  });

  res.status(status).json({
    success: false,
    error: {
      code,
      message: err.publicMessage || err.message || "Unexpected server error"
    }
  });
}
