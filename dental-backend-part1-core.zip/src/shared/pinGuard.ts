import { Request, Response, NextFunction } from "express";
import { loadEnv } from "./env";

export function requireAdminPin(req: Request, res: Response, next: NextFunction) {
  const { ADMIN_PIN } = loadEnv();
  const pin = req.headers["x-admin-pin"];
  if (!pin || pin !== ADMIN_PIN) {
    return res.status(403).json({
      success: false,
      error: { code: "PIN_REQUIRED", message: "Valid admin PIN is required for this action." }
    });
  }
  next();
}
