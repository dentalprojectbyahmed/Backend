import cron from "node-cron";
import { refreshUsdToPkrRate } from "../usdPkr/usdPkr.service";
import { createDailySnapshot } from "../sync/snapshot.service";
import { autoMarkNoShows } from "../appointments/appointments.autoNoShow";

export function initCronJobs() {
  // Hourly USD→PKR refresh
  cron.schedule("0 * * * *", async () => {
    try {
      await refreshUsdToPkrRate();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("USD→PKR cron failed", err);
    }
  });

  // Daily JSON snapshot to Drive (placeholder)
  cron.schedule("0 3 * * *", async () => {
    try {
      await createDailySnapshot();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("Daily snapshot cron failed", err);
    }
  });

  // Auto mark no-shows at 23:00 local
  cron.schedule("0 23 * * *", async () => {
    try {
      await autoMarkNoShows();
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("Auto no-show cron failed", err);
    }
  });
}
