import dotenv from "dotenv";

dotenv.config();

export function loadEnv() {
  const PORT = parseInt(process.env.PORT || "4000", 10);
  const NODE_ENV = process.env.NODE_ENV || "development";
  const CORS_ORIGIN = process.env.CORS_ORIGIN;
  const USD_PKR_API_URL = process.env.USD_PKR_API_URL || "https://api.exchangerate.host/latest?base=USD&symbols=PKR";
  const ADMIN_PIN = process.env.ADMIN_PIN || "1234";

  return {
    PORT,
    NODE_ENV,
    CORS_ORIGIN,
    USD_PKR_API_URL,
    ADMIN_PIN
  };
}
