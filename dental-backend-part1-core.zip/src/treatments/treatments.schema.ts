import { z } from "zod";

export const TreatmentSchema = z.object({
  id: z.string().uuid().optional(),
  code: z.string(),
  name: z.string(),
  category: z.string(),
  baseUsdPrice: z.number().nonnegative(),
  requiresTooth: z.boolean(),
  requiresSurface: z.boolean(),
  multiVisit: z.boolean(),
  consentTemplateId: z.string().optional()
});

export type Treatment = z.infer<typeof TreatmentSchema>;
