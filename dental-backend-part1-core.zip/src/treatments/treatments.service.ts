import { Treatment } from "./treatments.schema";

const treatments: Treatment[] = [];

// Placeholder: here you would seed the 70-item master list
export function seedTreatments(seed: Treatment[]) {
  treatments.splice(0, treatments.length, ...seed);
}

export async function listTreatments(): Promise<Treatment[]> {
  return treatments;
}

export async function createTreatment(t: Treatment): Promise<Treatment> {
  const withId: Treatment = { ...t, id: crypto.randomUUID() };
  treatments.push(withId);
  return withId;
}

export async function updateTreatment(id: string, patch: Partial<Treatment>): Promise<Treatment> {
  const idx = treatments.findIndex(t => t.id === id);
  if (idx === -1) {
    throw Object.assign(new Error("Treatment not found"), { status: 404 });
  }
  treatments[idx] = { ...treatments[idx], ...patch };
  return treatments[idx];
}
