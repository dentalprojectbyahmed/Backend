import { Prescription } from "./prescriptions.schema";

const prescriptions: Prescription[] = [];

export async function createPrescription(p: Prescription): Promise<Prescription> {
  const withId: Prescription = { ...p, id: crypto.randomUUID() };
  prescriptions.push(withId);
  return withId;
}

export async function listPrescriptionsForPatient(patientId: string): Promise<Prescription[]> {
  return prescriptions.filter(p => p.patientId === patientId);
}
