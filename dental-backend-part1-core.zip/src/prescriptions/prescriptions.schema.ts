import { z } from "zod";

export const PrescriptionItemSchema = z.object({
  drugName: z.string(),
  dose: z.string(),
  frequency: z.string(),
  duration: z.string(),
  notes: z.string().optional()
});

export const PrescriptionSchema = z.object({
  id: z.string().uuid().optional(),
  patientId: z.string(),
  conditionCode: z.string(),
  items: z.array(PrescriptionItemSchema),
  allergies: z.array(z.string()).default([]),
  flags: z.array(z.enum(["PREGNANT", "HYPERTENSION", "KIDNEY_DISEASE", "BLOOD_THINNERS"])).default([]),
  createdAt: z.string()
});

export type Prescription = z.infer<typeof PrescriptionSchema>;
export type PrescriptionItem = z.infer<typeof PrescriptionItemSchema>;
