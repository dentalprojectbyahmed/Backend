import { Router } from "express";
import { z } from "zod";
import { FollowupSchema } from "./followups.schema";
import { listFollowups, createFollowup } from "./followups.service";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const list = await listFollowups();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const body = FollowupSchema.parse(req.body);
    const created = await createFollowup(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
