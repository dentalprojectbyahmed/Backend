import { Followup } from "./followups.schema";

const followups: Followup[] = [];

export async function listFollowups(): Promise<Followup[]> {
  return followups;
}

export async function createFollowup(f: Followup): Promise<Followup> {
  const withId: Followup = { ...f, id: crypto.randomUUID() };
  followups.push(withId);
  return withId;
}
