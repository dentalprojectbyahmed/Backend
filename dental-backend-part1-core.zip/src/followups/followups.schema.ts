import { z } from "zod";

export const FollowupSchema = z.object({
  id: z.string().uuid().optional(),
  patientId: z.string(),
  dueDate: z.string(), // ISO
  reason: z.string(),
  source: z.enum(["PENDING_TREATMENT", "REVIEW", "SUTURE_REMOVAL", "PAIN_CHECK", "MEDICATION_REVIEW", "ROUTINE_RECALL", "NO_SHOW"]).default("PENDING_TREATMENT"),
  completed: z.boolean().default(false)
});

export type Followup = z.infer<typeof FollowupSchema>;
