import { GamificationEvent } from "./gamification.schema";

const events: GamificationEvent[] = [];

const pointsMap: Record<GamificationEvent["type"], number> = {
  CHECK_IN: 1,
  ON_TIME_APPOINTMENT: 2,
  TREATMENT_COMPLETED: 3,
  OUTSTANDING_PAID: 2,
  REFERRAL_ENTERED: 10
};

export async function recordEvent(type: GamificationEvent["type"]): Promise<GamificationEvent> {
  const evt: GamificationEvent = {
    id: crypto.randomUUID(),
    type,
    points: pointsMap[type],
    createdAt: new Date().toISOString()
  };
  events.push(evt);
  return evt;
}

export async function getTotalPoints(): Promise<number> {
  return events.reduce((sum, e) => sum + e.points, 0);
}
