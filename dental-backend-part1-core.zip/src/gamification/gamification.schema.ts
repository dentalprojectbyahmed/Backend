import { z } from "zod";

export const GamificationEventSchema = z.object({
  id: z.string().uuid().optional(),
  type: z.enum(["CHECK_IN", "ON_TIME_APPOINTMENT", "TREATMENT_COMPLETED", "OUTSTANDING_PAID", "REFERRAL_ENTERED"]),
  points: z.number().int(),
  createdAt: z.string()
});

export type GamificationEvent = z.infer<typeof GamificationEventSchema>;
