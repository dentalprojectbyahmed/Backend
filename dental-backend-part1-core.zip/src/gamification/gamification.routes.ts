import { Router } from "express";
import { z } from "zod";
import { recordEvent, getTotalPoints } from "./gamification.service";

const router = Router();

router.get("/total", async (_req, res, next) => {
  try {
    const total = await getTotalPoints();
    res.json({ success: true, data: { total } });
  } catch (err) {
    next(err);
  }
});

router.post("/event", async (req, res, next) => {
  try {
    const schema = z.object({
      type: z.enum(["CHECK_IN", "ON_TIME_APPOINTMENT", "TREATMENT_COMPLETED", "OUTSTANDING_PAID", "REFERRAL_ENTERED"])
    });
    const body = schema.parse(req.body);
    const evt = await recordEvent(body.type);
    res.status(201).json({ success: true, data: evt });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
