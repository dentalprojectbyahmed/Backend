import axios from "axios";
import { loadEnv } from "../shared/env";

let cachedRate: { rate: number; date: string } | null = null;

export async function refreshUsdToPkrRate() {
  const env = loadEnv();
  const today = new Date().toISOString().slice(0, 10);

  if (cachedRate && cachedRate.date === today) {
    return cachedRate;
  }

  const { data } = await axios.get(env.USD_PKR_API_URL);
  const rate = data?.rates?.PKR;
  if (!rate || typeof rate !== "number") {
    throw Object.assign(new Error("Invalid USD→PKR response"), { status: 502 });
  }

  cachedRate = { rate, date: today };
  return cachedRate;
}

export function convertUsdToPkr(usd: number): number {
  if (!cachedRate) {
    throw Object.assign(new Error("USD→PKR rate not loaded"), { status: 503 });
  }
  return Math.round(usd * cachedRate.rate);
}

export function getCachedRate() {
  return cachedRate;
}
