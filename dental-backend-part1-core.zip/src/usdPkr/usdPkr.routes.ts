import { Router } from "express";
import { refreshUsdToPkrRate, getCachedRate } from "./usdPkr.service";

const router = Router();

router.get("/current", async (_req, res, next) => {
  try {
    const rate = await refreshUsdToPkrRate();
    res.json({ success: true, rate });
  } catch (err) {
    next(err);
  }
});

router.get("/cached", (_req, res) => {
  res.json({ success: true, rate: getCachedRate() });
});

export default router;
