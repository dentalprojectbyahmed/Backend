import { Router } from "express";
import { z } from "zod";
import { AppointmentSchema } from "./appointments.schema";
import { createAppointment, listAppointments, updateAppointmentStatus } from "./appointments.service";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const list = await listAppointments();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const body = AppointmentSchema.parse(req.body);
    const created = await createAppointment(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

router.patch("/:id/status", async (req, res, next) => {
  try {
    const schema = z.object({ status: AppointmentSchema.shape.status });
    const body = schema.parse(req.body);
    const updated = await updateAppointmentStatus(req.params.id, body.status);
    res.json({ success: true, data: updated });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
