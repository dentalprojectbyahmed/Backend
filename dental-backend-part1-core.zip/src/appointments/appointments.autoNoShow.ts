import { autoMarkNoShows as mark } from "./appointments.service";

export async function autoMarkNoShows() {
  await mark();
}
