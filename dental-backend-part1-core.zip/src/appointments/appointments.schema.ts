import { z } from "zod";

export const AppointmentSchema = z.object({
  id: z.string().uuid().optional(),
  patientId: z.string(),
  startTime: z.string(), // ISO
  endTime: z.string(),   // ISO
  reason: z.string(),
  status: z.enum(["SCHEDULED", "CAME", "NO_SHOW", "RESCHEDULED", "NOT_ARRIVED"]).default("SCHEDULED"),
  linkedTreatmentPlanId: z.string().optional()
});

export type Appointment = z.infer<typeof AppointmentSchema>;
