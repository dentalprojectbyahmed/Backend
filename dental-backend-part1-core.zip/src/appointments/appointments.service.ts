import { Appointment } from "./appointments.schema";

const appointments: Appointment[] = [];

function overlaps(a: Appointment, b: Appointment) {
  return a.startTime < b.endTime && b.startTime < a.endTime;
}

export async function createAppointment(appt: Appointment): Promise<Appointment> {
  for (const existing of appointments) {
    if (existing.status !== "RESCHEDULED" && existing.status !== "NO_SHOW" && overlaps(existing, appt)) {
      const err = Object.assign(new Error("Time slot already booked"), { status: 409, code: "DOUBLE_BOOKING" });
      throw err;
    }
  }
  const withId: Appointment = { ...appt, id: crypto.randomUUID() };
  appointments.push(withId);
  return withId;
}

export async function listAppointments(): Promise<Appointment[]> {
  return appointments;
}

export async function updateAppointmentStatus(id: string, status: Appointment["status"]): Promise<Appointment> {
  const idx = appointments.findIndex(a => a.id === id);
  if (idx === -1) throw Object.assign(new Error("Appointment not found"), { status: 404 });
  appointments[idx].status = status;
  return appointments[idx];
}

export async function autoMarkNoShows() {
  const now = new Date().toISOString();
  for (const appt of appointments) {
    if (appt.status === "SCHEDULED" && appt.endTime < now) {
      appt.status = "NO_SHOW";
    }
  }
}
