import { Express } from "express";
import treatmentsRouter from "../treatments/treatments.routes";
import appointmentsRouter from "../appointments/appointments.routes";
import invoicesRouter from "../invoices/invoices.routes";
import prescriptionsRouter from "../prescriptions/prescriptions.routes";
import treatmentPlansRouter from "../treatmentPlans/treatmentPlans.routes";
import patientsRouter from "../patients/patients.routes";
import consentsRouter from "../consents/consents.routes";
import followupsRouter from "../followups/followups.routes";
import gamificationRouter from "../gamification/gamification.routes";
import usdPkrRouter from "../usdPkr/usdPkr.routes";
import syncRouter from "../sync/sync.routes";

export function registerRoutes(app: Express) {
  app.get("/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  app.use("/api/patients", patientsRouter);
  app.use("/api/treatments", treatmentsRouter);
  app.use("/api/treatment-plans", treatmentPlansRouter);
  app.use("/api/appointments", appointmentsRouter);
  app.use("/api/invoices", invoicesRouter);
  app.use("/api/prescriptions", prescriptionsRouter);
  app.use("/api/consents", consentsRouter);
  app.use("/api/followups", followupsRouter);
  app.use("/api/gamification", gamificationRouter);
  app.use("/api/usd-pkr", usdPkrRouter);
  app.use("/api/sync", syncRouter);
}
