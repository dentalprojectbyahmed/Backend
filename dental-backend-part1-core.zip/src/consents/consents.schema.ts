import { z } from "zod";

export const ConsentTemplateSchema = z.object({
  id: z.string().uuid().optional(),
  treatmentCode: z.string(), // map per treatment
  title: z.string(),
  body: z.string(), // text or markdown
  version: z.string()
});

export type ConsentTemplate = z.infer<typeof ConsentTemplateSchema>;
