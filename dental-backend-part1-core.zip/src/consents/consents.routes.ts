import { Router } from "express";
import { z } from "zod";
import { ConsentTemplateSchema } from "./consents.schema";
import { listConsents, createConsent } from "./consents.service";
import { requireAdminPin } from "../shared/pinGuard";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const list = await listConsents();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/", requireAdminPin, async (req, res, next) => {
  try {
    const body = ConsentTemplateSchema.parse(req.body);
    const created = await createConsent(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
