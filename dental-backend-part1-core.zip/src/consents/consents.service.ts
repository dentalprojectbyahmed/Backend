import { ConsentTemplate } from "./consents.schema";

const consents: ConsentTemplate[] = [];

export async function listConsents(): Promise<ConsentTemplate[]> {
  return consents;
}

export async function createConsent(c: ConsentTemplate): Promise<ConsentTemplate> {
  const withId: ConsentTemplate = { ...c, id: crypto.randomUUID() };
  consents.push(withId);
  return withId;
}

export async function getConsentsForTreatmentCodes(codes: string[]): Promise<ConsentTemplate[]> {
  return consents.filter(c => codes.includes(c.treatmentCode));
}
