import { Patient } from "./patients.schema";

const patients: Patient[] = [];

export async function listPatients(): Promise<Patient[]> {
  return patients;
}

export async function createPatient(input: Patient): Promise<Patient> {
  const withId: Patient = { ...input, id: crypto.randomUUID() };
  patients.push(withId);
  return withId;
}

export async function updatePatient(id: string, patch: Partial<Patient>): Promise<Patient> {
  const idx = patients.findIndex(p => p.id === id);
  if (idx === -1) {
    throw Object.assign(new Error("Patient not found"), { status: 404 });
  }
  patients[idx] = { ...patients[idx], ...patch };
  return patients[idx];
}
