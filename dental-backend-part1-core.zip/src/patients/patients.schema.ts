import { z } from "zod";

export const PatientSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string(),
  phone: z.string(),
  age: z.number().int().nonnegative().optional(),
  gender: z.enum(["M", "F", "O"]).optional(),
  occupation: z.string().optional(),
  address: z.string().optional(),
  medicalAlerts: z.string().optional(),
  internalNotes: z.string().optional()
});

export type Patient = z.infer<typeof PatientSchema>;
