import { Router } from "express";
import { z } from "zod";
import { PatientSchema } from "./patients.schema";
import { listPatients, createPatient, updatePatient } from "./patients.service";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const list = await listPatients();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const body = PatientSchema.parse(req.body);
    const created = await createPatient(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const patch = req.body;
    const updated = await updatePatient(req.params.id, patch);
    res.json({ success: true, data: updated });
  } catch (err) {
    next(err);
  }
});

export default router;
