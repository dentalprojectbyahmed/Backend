import { z } from "zod";

export const TreatmentPlanItemSchema = z.object({
  id: z.string().uuid().optional(),
  treatmentId: z.string(),
  name: z.string(),
  tooth: z.string().optional(),
  surfaces: z.array(z.string()).optional(),
  quantity: z.number().int().positive().default(1),
  pricePkr: z.number().nonnegative(),
  status: z.enum(["PLANNED", "IN_PROGRESS", "DONE"]).default("PLANNED"),
  notes: z.string().optional(),
  multiVisitTotalVisits: z.number().int().positive().optional(),
  multiVisitCompletedVisits: z.number().int().nonnegative().optional()
});

export const TreatmentPlanSchema = z.object({
  id: z.string().uuid().optional(),
  patientId: z.string(),
  createdAt: z.string(), // ISO
  items: z.array(TreatmentPlanItemSchema)
});

export type TreatmentPlan = z.infer<typeof TreatmentPlanSchema>;
export type TreatmentPlanItem = z.infer<typeof TreatmentPlanItemSchema>;
