import { TreatmentPlan, TreatmentPlanItem } from "./treatmentPlans.schema";

const plans: TreatmentPlan[] = [];

export async function listPlansForPatient(patientId: string): Promise<TreatmentPlan[]> {
  return plans.filter(p => p.patientId === patientId);
}

export async function createTreatmentPlan(plan: TreatmentPlan): Promise<TreatmentPlan> {
  const withId: TreatmentPlan = { ...plan, id: crypto.randomUUID() };
  withId.items = withId.items.map(i => ({ ...i, id: crypto.randomUUID() } as TreatmentPlanItem));
  plans.push(withId);
  return withId;
}

export async function markItemDone(patientId: string, planId: string, itemId: string): Promise<TreatmentPlanItem> {
  const plan = plans.find(p => p.id === planId && p.patientId === patientId);
  if (!plan) throw Object.assign(new Error("Plan not found"), { status: 404 });
  const item = plan.items.find(i => i.id === itemId);
  if (!item) throw Object.assign(new Error("Item not found"), { status: 404 });

  if (item.multiVisitTotalVisits && item.multiVisitTotalVisits > 1) {
    const completed = (item.multiVisitCompletedVisits || 0) + 1;
    item.multiVisitCompletedVisits = completed;
    item.status = completed >= item.multiVisitTotalVisits ? "DONE" : "IN_PROGRESS";
  } else {
    item.status = "DONE";
  }

  return item;
}

export function removeDoneItemsFromPlansForInvoice(patientId: string) {
  // You would integrate with invoices here; for now we just expose helper
  const doneItems: TreatmentPlanItem[] = [];
  for (const plan of plans.filter(p => p.patientId === patientId)) {
    const remaining: TreatmentPlanItem[] = [];
    for (const item of plan.items) {
      if (item.status === "DONE") {
        doneItems.push(item);
      } else {
        remaining.push(item);
      }
    }
    plan.items = remaining;
  }
  return doneItems;
}
