import { z } from "zod";

export const InvoiceItemSchema = z.object({
  id: z.string().uuid().optional(),
  treatmentId: z.string(),
  name: z.string(),
  tooth: z.string().optional(),
  surfaces: z.array(z.string()).optional(),
  quantity: z.number().int().positive().default(1),
  unitPricePkr: z.number().nonnegative()
});

export const InvoiceSchema = z.object({
  id: z.string().uuid().optional(),
  number: z.string().optional(),
  patientId: z.string(),
  date: z.string(), // ISO
  items: z.array(InvoiceItemSchema),
  discountFlat: z.number().nonnegative().default(0),
  discountPercent: z.number().min(0).max(100).default(0),
  paymentMethod: z.enum(["CASH", "CARD", "JAZZCASH", "EASYPAISA", "BANK", "OTHER"]).default("CASH")
});

export type Invoice = z.infer<typeof InvoiceSchema>;
export type InvoiceItem = z.infer<typeof InvoiceItemSchema>;
