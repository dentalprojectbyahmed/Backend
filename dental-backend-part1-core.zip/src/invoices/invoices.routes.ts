import { Router } from "express";
import { z } from "zod";
import { InvoiceSchema } from "./invoices.schema";
import { createInvoice, listInvoices, listInvoicesForPatient } from "./invoices.service";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const list = await listInvoices();
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.get("/patient/:patientId", async (req, res, next) => {
  try {
    const list = await listInvoicesForPatient(req.params.patientId);
    res.json({ success: true, data: list });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const body = InvoiceSchema.parse(req.body);
    const created = await createInvoice(body);
    res.status(201).json({ success: true, data: created });
  } catch (err: any) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ success: false, error: { code: "VALIDATION_ERROR", issues: err.issues } });
    }
    next(err);
  }
});

export default router;
