import { Invoice, InvoiceItem } from "./invoices.schema";

const invoices: Invoice[] = [];

function generateInvoiceNumber(dateIso: string, seq: number) {
  const d = dateIso.slice(0, 10).replace(/-/g, "");
  return `${d}-${seq.toString().padStart(4, "0")}`;
}

export async function createInvoice(inv: Invoice): Promise<Invoice> {
  const seq = invoices.length + 1;
  const number = generateInvoiceNumber(inv.date, seq);
  const withNumber: Invoice = {
    ...inv,
    id: crypto.randomUUID(),
    number,
    items: inv.items.map(i => ({ ...i, id: crypto.randomUUID() } as InvoiceItem))
  };
  invoices.push(withNumber);
  return withNumber;
}

export async function listInvoicesForPatient(patientId: string): Promise<Invoice[]> {
  return invoices.filter(i => i.patientId === patientId);
}

export async function listInvoices(): Promise<Invoice[]> {
  return invoices;
}
