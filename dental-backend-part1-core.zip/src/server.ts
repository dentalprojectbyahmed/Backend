import express from "express";
import helmet from "helmet";
import cors from "cors";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { json } from "express";
import { registerRoutes } from "./routes";
import { errorHandler } from "./shared/errorHandler";
import { initCronJobs } from "./shared/cron";
import { loadEnv } from "./shared/env";

export async function startServer() {
  const env = loadEnv();
  const app = express();

  app.use(helmet());
  app.use(cors({ origin: env.CORS_ORIGIN ?? "*" }));
  app.use(json({ limit: "10mb" }));
  app.use(morgan("combined"));

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 1000
  });
  app.use(limiter);

  registerRoutes(app);
  app.use(errorHandler);

  const server = app.listen(env.PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`Server listening on port ${env.PORT}`);
  });

  initCronJobs();

  const shutdown = () => {
    // eslint-disable-next-line no-console
    console.log("Graceful shutdown initiated");
    server.close(() => {
      // eslint-disable-next-line no-console
      console.log("HTTP server closed");
      process.exit(0);
    });
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}
