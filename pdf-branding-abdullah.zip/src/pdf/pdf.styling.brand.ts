
import PDFDocument from "pdfkit";
import fs from "fs";

export function loadLocalLogo(path: string) {
  try {
    return fs.readFileSync(path);
  } catch {
    return null;
  }
}

export function drawHeader(doc, ctx) {
  const { clinic } = ctx;
  const y=20;

  if (clinic.logoBuffer) {
    try { doc.image(clinic.logoBuffer,40,y,{width:60}); } catch {}
  }

  const left=120;
  doc.fillColor("#000").fontSize(18).text(clinic.name,left,y);
  doc.fillColor("#444").fontSize(10).text(clinic.address,left,y+20);
  doc.text("Phone: "+clinic.phone,left,y+34);

  doc.moveTo(40,y+60).lineTo(550,y+60).stroke("#000");
  doc.moveDown();
}

export function drawFooter(doc,ctx){
  const y=doc.page.height-50;
  doc.fillColor("#555").fontSize(9).text(
    ctx.clinic.footer || ("Thank you for choosing "+ctx.clinic.name),
    40,y,{align:"center",width:doc.page.width-80}
  );
}

export const styles={
  title:(doc,text)=>{doc.fillColor("#000").fontSize(14).text(text,{underline:true});doc.moveDown();},
  label:(doc,text)=>{doc.fillColor("#222").fontSize(11).text(text);doc.moveDown(0.3);},
  small:(doc,text)=>{doc.fillColor("#444").fontSize(9).text(text);}
};
