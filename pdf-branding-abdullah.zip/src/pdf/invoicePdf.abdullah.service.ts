
import { renderToBuffer } from "./pdf.utils";
import { drawHeader, drawFooter, styles } from "./pdf.styling.brand";

export async function renderInvoicePdfAbdullah(ctx, invoice, patient, consents){
  return renderToBuffer(doc=>{
    drawHeader(doc,ctx);

    styles.title(doc,"Invoice");

    doc.fontSize(10).text("Invoice #: "+invoice.number);
    doc.text("Date: "+invoice.date);
    doc.moveDown();

    styles.label(doc,"Patient: "+patient.name+" ("+patient.id+")");

    const col={t:40,tooth:240,qty:330,amt:420};

    doc.fontSize(10).fillColor("#000");
    doc.text("Treatment",col.t);
    doc.text("Tooth",col.tooth);
    doc.text("Qty",col.qty);
    doc.text("Amount",col.amt);
    doc.moveDown();

    let y=doc.y+5;
    let gross=0;
    const fmt=n=>"PKR "+n.toFixed(0);

    for(const it of invoice.items){
      const sub=(it.unitPricePkr||0)*(it.quantity||1);
      gross+=sub;
      doc.text(it.name,col.t,y);
      doc.text(it.tooth||"-",col.tooth,y);
      doc.text(String(it.quantity||1),col.qty,y);
      doc.text(fmt(sub),col.amt,y);
      y+=18;
    }

    doc.moveDown(2);
    const total=gross*(1-(invoice.discountPercent||0)/100)-(invoice.discountFlat||0);

    doc.text("Gross: "+fmt(gross),{align:"right"});
    doc.text("Total: "+fmt(total),{align:"right"});

    if(consents.length>0){
      doc.addPage();
      drawHeader(doc,ctx);
      styles.title(doc,"Consents");
      for(const c of consents){
        doc.fontSize(12).text(c.title,{underline:true});
        doc.fontSize(10).text(c.body,{align:"justify"});
        doc.moveDown();
      }
      drawFooter(doc,ctx);
      return;
    }

    drawFooter(doc,ctx);
  });
}
